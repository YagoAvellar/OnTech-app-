### Descrição
ONTCH - APP

Aplicativo mobile para executar as ordens de serviço, é utilizado pelo técnico.
- Executa OS
- Consulta dados dos clientes
- Fotos
- Localização


## Tecnologia
- Ionic + Cordova

## Informações
- Responsável : Julio Nascimento <<julio.nascimento@onclick.com.br>>
- Desenvolvido por: Pedro
- Servidor: PlayStore
- SO: Android