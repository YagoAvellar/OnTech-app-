angular.module("starter.controllers").constant("config", {
    'SASAZAKI' : {
        nome : 'Sasazaki',
        baseUrl: "https://ontech-api.sasazaki.com.br/v2",
	documentacaoUrl: "https://ontech.sasazaki.com.br",
	imageUrl: "https://ontech-api.sasazaki.com.br", 
	baseUrlOauth: "https://ontech-api.sasazaki.com.br"
    },
    'ONCLICK' : {
        nome : 'ONCLICK',
	baseUrl: "http://ontech-api.onclick.com.br/v2",
	documentacaoUrl: "http://ontech.onclick.com.br",
	imageUrl: "http://ontech-api.onclick.com.br", 
	baseUrlOauth: "http://ontech-api.onclick.com.br"
    },
    'DEV' : {
        nome : 'Desenvolvimento',
	baseUrl: "http://192.168.1.20/v2",
	documentacaoUrl: "http://webonassistencia.ddns.net:3377",
	baseUrlOauth: "http://192.168.1.20",
	imageUrl: "http://192.168.1.20"
    },
    'DEV_TESTE' : {
        nome : 'Desenvolvimento com arquivos de produção',
	baseUrl: "http://192.168.1.20/v2",
	documentacaoUrl: "https://ontech.sasazaki.com.br",
	baseUrlOauth: "http://192.168.1.20",
	imageUrl: "https://ontech-api.sasazaki.com.br"
    },
//    'DEV_CASA' : {
//        nome : 'Desenvolvimento Casa',
//	baseUrl: "http://192.168.15.27/v2",
//	documentacaoUrl: "http://webonassistencia.ddns.net:3377",
//	baseUrlOauth: "http://192.168.15.27",
//	imageUrl: "http://192.168.15.27"
//    },
    'DEV_EXTERNO' : {
        nome : 'Desenvolvimento Externo',
	baseUrl: "http://apionassistencia.ddns.net:3377/v2",
	documentacaoUrl: "http://webonassistencia.ddns.net:3377",
	imageUrl: "http://apionassistencia.ddns.net:3377",
	baseUrlOauth: "http://apionassistencia.ddns.net:3377"
    }
    
});
