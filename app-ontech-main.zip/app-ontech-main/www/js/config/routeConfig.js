angular.module("starter").config(function($stateProvider, $httpProvider, $urlRouterProvider) {
    
//        $httpProvider.defaults.useXDomain = true;
//        $httpProvider.defaults.headers.common = 'Content-Type: application/json';
//        delete $httpProvider.defaults.headers.common['X-Requested-With'];
//    $httpProvider.defaults.useXDomain = true;
//    $httpProvider.defaults.withCredentials = true;
//    delete $httpProvider.defaults.headers.common['X-Requested-With'];

//$httpProvider.defaults.useXDomain = true;
//
//  // Remove the header used to identify ajax call  that would prevent CORS from working
//  delete $httpProvider.defaults.headers.common['X-Requested-With'];
//
//  // Set api token
//  if(typeof API_TOKEN !== 'undefined') {
//    $httpProvider.defaults.headers.common['Authentication-Token'] = API_TOKEN;
//  }
    
    $stateProvider.state('tabs', {
        url: '/tab',
        abstract: true,
        templateUrl: 'templates/tabs.html'
    });

    $stateProvider.state('tabs.ordem', {
        url: '/ordem/:id',
        views: {
            'tab-cronograma': {
                templateUrl: 'templates/ordem.html',
                controller: "OrdemCtrl"
            }
        }
    });
    
    $stateProvider.state('tabs.cronograma', {
        cache: false,
        url: '/cronograma',
        views: {
            'tab-cronograma': {
                templateUrl: 'templates/tab-cronograma.html',
                controller: "CronogramaCtrl"
            }
        }
    });

    $stateProvider.state('tabs.atendimento', {
        url: '/atendimento/:id',
        views: {
            'tab-cronograma': {
                templateUrl: 'templates/atendimento.html',
                controller: "AtendimentoCtrl"
            }
        }
    });
    

    $stateProvider.state('tabs.atendimentoatual', {
        cache: false,
        url: '/atendimentoatual',
        views: {
            'atendimentoatual-tab': {
                templateUrl: 'templates/atendimento.html',
                controller: "AtendimentoCtrl"
            }
        }
    });
    

    $stateProvider.state('tabs.create', {
        url: '/create',
        views: {
            'create-tab': {
                templateUrl: 'templates/create.html'
            }
        }
    });
    $stateProvider.state('tabs.configuracoes', {
        cache: false,
        url: '/configuracoes',
        views: {
            'configuracoes-tab': {
                templateUrl: 'templates/configuracoes.html',
                controller: "ConfiguracoesCtrl"
            }
        }
    });
    
    $stateProvider.state('tabs.imagens', {
        cache: false,
        url: '/imagens',
        views: {
            'imagens-tab': {
                templateUrl: 'templates/imagens.html',
                controller: "ImagensCtrl"
            }
        }
    });

    $stateProvider.state('login', {
        cache: false,
        url: '/login',
        templateUrl: 'templates/login.html',
        controller: 'loginCtrl'
    });

    $stateProvider.state('tabs.orders', {
        url: '/orders',
        views: {
            'orders-tab': {
                templateUrl: 'templates/orders.html',
                controller: "ordersCtrl"
            }
        }
    });

    $stateProvider.state('tabs.show', {
        url: '/orders/:id',
        views: {
            'orders-tab': {
                templateUrl: 'templates/orders-show.html',
                controller: "orderCtrl"
            }
        }
    });

    $stateProvider.state('tabs.estoque', {
        url: '/estoque',
        views: {
            'estoque-tab': {
                templateUrl: 'templates/estoque.html',
                controller: "EstoqueCtrl"
            }
        }
    });
    
    $stateProvider.state('tabs.estoquepeca', {
        cache: false,
        url: '/estoquepeca/:id',
        views: {
            'estoque-tab': {
                templateUrl: 'templates/estoque-peca.html',
                controller: "EstoquePecaCtrl"
            }
        }
    });

    $urlRouterProvider.otherwise('/tab/atendimentoatual');
})