//angular.module("starter").config(function ($ionicConfigProvider) {
//	$ionicConfigProvider.tabs.position('bottom');
//});
