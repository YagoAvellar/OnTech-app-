angular.module("starter").config(function ( OAuthProvider, $httpProvider, $provide, config) {

    $httpProvider.interceptors.push('oauthFixInterceptor');
    $httpProvider.interceptors.splice(0, 1);
    
    var configOAuthProvider = {
        baseUrl: config.ONCLICK.baseUrlOauth,
        clientId: 'clientpedro',
        clientSecret: 'testpass',
        grantPath: '/oauth',
        revokePath: '/oauth'
    };
    
    var configuracaoOauth = OAuthProvider.configure(configOAuthProvider);
    
    $provide.decorator('OAuthToken', ['$delegate', '$localStorage', function($delegate, $localStorage){
        var configTemp = $localStorage.getObject('configOAuthProvider');
        if(angular.isObject(configTemp)){
            configOAuthProvider = configTemp;
            configuracaoOauth = OAuthProvider.configure(configOAuthProvider);
        }else{
            $localStorage.setObject('configOAuthProvider', configOAuthProvider);
        }
        Object.defineProperties($delegate, {
            setToken:{
                value: function(data){
                    return $localStorage.setObject('token', data);
                },
                enumerable: true,
                configurable: true,
                writable: true
            },
            getToken:{
                value: function(){
                    return $localStorage.getObject('token');
                },
                enumerable: true,
                configurable: true,
                writable: true
            },
            removeToken:{
                value: function(){
                    $localStorage.setObject('token', null);
                },
                enumerable: true,
                configurable: true,
                writable: true
            },
            alteraUrlOauth:{
                value: function(url){
                    configuracaoOauth.baseUrl = url;
                    var configOAuthProvider = $localStorage.getObject('configOAuthProvider');
                    configOAuthProvider.baseUrl = url;                    
                    $localStorage.setObject('configOAuthProvider', configOAuthProvider);
//                    
//                    OAuthProvider.configure(configOAuthProvider);
                },
                enumerable: true,
                configurable: true,
                writable: true
            }
        });
        return $delegate;
    }]);
//    // catch exceptions in angular
//    $provide.decorator('$exceptionHandler', ['$delegate', function ($delegate) {
//        return function (exception, cause) {
//            $delegate(exception, cause);
//
//            var data = {
//                type: 'angular',
//                url: window.location.hash,
//                localtime: Date.now()
//            };
//            if (cause) {
//                data.cause = cause;
//            }
//            if (exception) {
//                if (exception.message) {
//                    data.message = exception.message;
//                }
//                if (exception.name) {
//                    data.name = exception.name;
//                }
//                if (exception.stack) {
//                    data.stack = exception.stack;
//                }
//            }
//
//            if (debug) {
//                console.log('exception', data);
//                window.alert('Error: ' + data.message);
//            } else {
//                track('exception', data);
//            }
//        };
//    }]);
});