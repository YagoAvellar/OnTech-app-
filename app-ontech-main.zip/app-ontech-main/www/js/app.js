// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
//var db = null;
//var $rootScope.appVersion = "0.0.0";
angular.module("starter.controllers", []);
//angular.module('starter', ['ionic', 'starter.controllers', 'angular-oauth2', 'ngCordova'])
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services', 'angular-oauth2', 'ngCordova', 'http-auth-interceptor','nl2br','cordova.file.media'])
//.factory('$exceptionHandler', function ($window) {
//  return function (exception) {
//    if ($window.atatus) {
//      $window.atatus.notify(exception);
//    }
//  }
//})
.factory('$exceptionHandler', function($injector) {
    return function(exception, cause) {
        var $rootScope = $injector.get('$rootScope');
        var data = {
                    type: 'angularJs',
                    url: window.location.hash
                };
//        data.name = exception.name;
//        data.message = exception.message;
        data.stack = exception.stack;
        $rootScope.geraLog(data);
//        console.error('angular exception: ' + exception.message + ' (caused by ' + cause + ')');
    };
})
//.run(function($ionicPlatform, $cordovaSQLite) {
        .run(function ($ionicPlatform, $rootScope, $filter, $ionicLoading, $cordovaGeolocation, OAuth, $state, httpBuffer, $ionicModal, logout, $ionicPopup, $cordovaSQLite, $cordovaDevice, 
            SQLiteAPIAbstract, SQLiteOrdemServico, SQLiteAPIatdcOcorrenciaProduto,  $cordovaNetwork, $localStorage, $timeout, $cordovaFileTransfer, SQLiteAPIatdcOcorrenciaAnexo, Media,
            SQLiteAPIatdcOcorrenciaExpositor, config, SQLiteAPIProdutoAjuda, $q, $window, $cordovaFile, SQLiteAPIatosImagem, $ionicHistory, NotificationPush, authService, manipularArquivos ) {
            
            
            $rootScope.getAlturaLargura = function (){
                var elementoIonContent = document.querySelector("ion-content");
                if(elementoIonContent && elementoIonContent.querySelector("div")){
                    var elementoIonContentDiv = elementoIonContent.querySelector("div");
                    $rootScope.alturaTela = elementoIonContentDiv.offsetHeight;
                    $rootScope.larguraTela = elementoIonContentDiv.offsetWidth;
                }else{
                    $rootScope.alturaTela = screen.height;
                    $rootScope.larguraTela = screen.width;
                }
            };
            window.addEventListener("orientationchange", function(){
                $rootScope.getAlturaLargura();
            });
            $rootScope.gravandoLog = false;
            // catch exceptions out of angular
            window.onerror = function (message, url, line, col, error) {
                var debug = false;
                var stopPropagation = debug ? false : true;
                var data = {
                    type: 'javascript',
                    url: window.location.hash
                }; 
//                if (message) {
//                    data.message = message;
//                }
//                if (url) {
//                    data.fileName = url;
//                }
//                if (line) {
//                    data.lineNumber = line;
//                }
                if (col && col > 100) {
                    data.columnNumber = col;
                }
                if (error) {
//                    if (error.name) {
//                        data.name = error.name;
//                    }
                    if (error.stack) {
                        data.stack = error.stack;
                    }
                }
                console.log('Erro Javascript');
                console.log(data);
                $rootScope.geraLog(data);
                return stopPropagation;
            };

            $rootScope.geraLog = function (data, error) {
                if(data == null){
                    data = {};
                }
                var timeNow = new Date();
                var nome = $filter('date')(timeNow, 'yyyy-MM-dd');
                var arquivo = nome+".log";
                var texto = "Data: "+$filter('date')(timeNow, 'dd/MM/yyyy HH:mm:ss')+"\n";
//                var modelo = _getModelo();
                 _getInfoAparelho().then(function (modelo) {
                     console.log(modelo);
                    angular.forEach(modelo, function (valor,indice) {
                        texto += indice+": "+valor+"\n";
                    });


                    data.url = $ionicHistory.currentView().url;
                    data.stateParams = $ionicHistory.currentView().stateParams;

                    if(error !== undefined){
                        var stack = error.stack;
                        var line = stack.split('\n')[1];
                        data.linha = line;
                    }

                    if(angular.isObject(data)){
                        if(data.type == undefined){
                            data.type = Object.getPrototypeOf(data).constructor.name;
                        }
                        angular.forEach(data, function (valor,indice) {
                            if(angular.isObject(valor)){
                                texto += indice+": [ ";
                                angular.forEach(valor, function (valor2,indice2) {
                                    texto += indice2+": "+valor2+" | ";
                                });
                                texto += "]\n";
                            }else{
                                texto += indice+": "+valor+"\n";
                            }
                        });
                    }else{
                        texto += data+"\n";
                    }
                    texto += "\n\n";
                    console.error(data);
                    if($rootScope.gravandoLog){
                        return true;
                    }
                    $rootScope.gravandoLog = true;
                    $cordovaFile.checkFile($rootScope.caminhoLog,arquivo).then(function (success) {
                        $cordovaFile.writeExistingFile($rootScope.caminhoLog,arquivo, texto, true)
                        .then(function (success) {
    //                    teste2.teste2; 
                        $rootScope.gravandoLog = false;
                        }, function (error) {
                            $rootScope.gravandoLog = false;
                        });
                    }, function (error) { 
                        $cordovaFile.writeFile($rootScope.caminhoLog,arquivo, texto, true)
                        .then(function (success) {
                            $rootScope.gravandoLog = false;
                        }, function (error) {
                            $rootScope.gravandoLog = false;
                        });
                    });
                });
                
//                $rootScope.showAlert(data.message);
            };
                
            $rootScope.salvaLog = function (error) {
                var data = {
                            type: 'angularJs Tratado',
                            url: window.location.hash
                        };
        //        data.name = exception.name;
        //        data.message = exception.message;
                data.stack = error.stack;
                $rootScope.geraLog(data);
            };
            
            
            $rootScope.appVersion = "0.0.0";
    
            $rootScope.abrirCarregando = function (mensagem) {
                $ionicLoading.show({
                    template: (mensagem === undefined) ? 'Carregando...' : mensagem
                });
            };
            $rootScope.fecharCarregando = function () {
                $ionicLoading.hide();
            };
            $rootScope.tamanhoObjeto = function (objeto) {
                if(angular.isObject(objeto)){
                    return Object.keys(objeto).length;
                    
                }else
                if(objeto === null || objeto === undefined ){
                    return 0;
                }
            };
            $rootScope.tamanhoString = function (string) {
                if(string === undefined || string === null){
                    return 0;
                }else{
                    return string.length;
                }
            };
            $rootScope.tamanhoString2 = function (string) {
                console.log(string);
                if(string === undefined){
                    return 0;
                }else{
                    return string.length;
                }
            };
            $rootScope.tamanhoArquivo = function (bytes,decimals,tipo) {
                if(bytes == 0) return '0 Byte';
                var k = 1024; // or 1000 
                var dm = decimals + 1 || 3;
                var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
                if(tipo !== undefined && tipo === 'KB'){
                    bytes = bytes*k;
                }
                var i = Math.floor(Math.log(bytes) / Math.log(k));
                return $filter('number')(parseFloat((bytes / Math.pow(k, i)).toFixed(dm)),decimals) + ' ' + sizes[i];
             };
            $rootScope.showAlert = function(mensagem) {
                var alertPopup = $ionicPopup.alert({
//                  title: 'Don\'t eat that!',
                  template: (mensagem === undefined) ? 'Atenção' : mensagem
                });

                alertPopup.then(function(res) {
                    
                });
            };
            $rootScope.showAlertTitulo = function(titulo, mensagem) {
                var alertPopup = $ionicPopup.alert({
                  title: titulo,
                  template: (mensagem === undefined) ? 'Atenção' : mensagem
                });

                alertPopup.then(function(res) {
                    
                });
            };
            $rootScope.toCamelCase = function( string ){
              return string.toLowerCase().replace(/(_|-)([a-z])/g, toUpperCase );
            };

            function toUpperCase( string ){
              return string[1].toUpperCase();
            }
            
            $rootScope.sendEmail = function (assunto, conteudo, anexos) {
//                console.log(anexos);
                cordova.plugins.email.open({
                    to:          ["fabricadesoftware@onclicksistemas.com.br"], // email addresses for TO field
                    cc:          null,        // email addresses for CC field
                    bcc:         null,        // email addresses for BCC field
                    attachments: anexos,    // file paths or base64 data streams
                    subject:     assunto,   // subject of the email
                    body:        conteudo,  // email body (for HTML, set isHtml to true)
                    isHtml:      false     // indicats if the body is HTML or plain text
                });
                
//                console.log("teste Email"); 
//                console.log('window.plugins');
//                console.log(window.plugins);
                /*
                if(window.plugins && window.plugins.emailComposer) {
                    window.plugins.emailComposer.showEmailComposerWithCallback(function(result) {
                        console.log("Response -> " + result);
                    }, 
                    assunto, // Subject
                    conteudo,                      // Body
                    ["fabricadesoftware@onclicksistemas.com.br"],    // To
                    null,                    // CC
                    null,                    // BCC
                    false,                   // isHTML
                    anexos,                    // Attachments
                    null);                   // Attachment Data
                }else{
                    console.log('window.plugins');
                    console.log(window.plugins);
                }
                */
            };
            
            $rootScope.paraEmail = function (email) {
//                console.log(anexos);
                cordova.plugins.email.open({
                    to:          [email], // email addresses for TO field
                    cc:          null,        // email addresses for CC field
                    bcc:         null,        // email addresses for BCC field
                    attachments: null,    // file paths or base64 data streams
                    subject:     null,   // subject of the email
                    body:        null,  // email body (for HTML, set isHtml to true)
                    isHtml:      false     // indicats if the body is HTML or plain text
                });
            };
                            
//            var options = {timeout: 10000, enableHighAccuracy: false};
//            $cordovaGeolocation.getCurrentPosition(options).then(function (position) {
//                $rootScope.localizacaoUsuario = position.coords.latitude+" | "+position.coords.longitude; 
//            });
            
            $rootScope.getLocalizacao = function (posOptions) {
                return _getLocalizacao(posOptions);
            };
            
            _getLocalizacao = function (posOptions) {
                var defered = $q.defer();
                var promise = defered.promise;
                if(posOptions === undefined){
                    posOptions = {timeout: 10000, enableHighAccuracy: false};
                }
                $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
                    var localizacaoUsuario = {
                        posicao : position.coords.latitude+" | "+position.coords.longitude,
                        dataAtualizacao : new Date()
                    };
                    $localStorage.setObject('localizacaoUsuario', localizacaoUsuario);
                    $rootScope.localizacaoUsuario = localizacaoUsuario.posicao;
                    defered.resolve(position);
                }, function (err) {
                    defered.reject(err);
                });
                return promise;
            };
            
//            $rootScope.calculaDistancia = function (origem, destino) {
//                var temp1 = origem.split("|");
//                var temp2 = destino.split("|");
//                var lat1 = temp1[0];
//                var lon1 = temp1[1];
//                var lat2 = temp2[0];
//                var lon2 = temp2[1];
//                var RADIUSMILES = 3961,
//                    RADIUSKILOMETERS = 6373,
//                    latR1 = this.deg2rad(lat1),
//                    lonR1 = this.deg2rad(lon1),
//                    latR2 = this.deg2rad(lat2),
//                    lonR2 = this.deg2rad(lon2),
//                    latDifference = latR2 - latR1,
//                    lonDifference = lonR2 - lonR1,
//                    a  = Math.pow(Math.sin(latDifference / 2), 2) + Math.cos(latR1) * Math.cos(latR2) * Math.pow(Math.sin(lonDifference / 2), 2),
//                    c  = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)),
//                    dm = c * RADIUSMILES,
//                    dk = c * RADIUSKILOMETERS;
//                    this.mi = this.round(dm);
//                    this.km = this.round(dk);
//            };
            deg2rad = function (deg) {
                var rad = deg * Math.PI / 180;
                return rad;
            };
            round = function (x) {
                return Math.round(x * 10) / 10;
            };
            $rootScope.calculaDistancia = function (origem, destino) {
                var temp1 = origem.split("|");
                var temp2 = destino.split("|");
                var lat1 = temp1[0];
                var lon1 = temp1[1];
                var lat2 = temp2[0];
                var lon2 = temp2[1];
                
                var R = 6371; // raio da terra
                var Lati = Math.PI/180*(lat2-lat1);  //Graus  - > Radianos
                var Long = Math.PI/180*(lon2-lon1); 
                var a = 
                  Math.sin(Lati/2) * Math.sin(Lati/2) +
                  Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
                  Math.sin(Long/2) * Math.sin(Long/2); 
                var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
                var d = R * c; // distância en km
                return d;
                
            };
            
            $rootScope.geraAleatorio = function (min, max, elemento) {
                var retorno = Math.floor(Math.random() * (max - min)) + min;
//                console.log('retorno');
//                console.log(retorno);
                if(elemento !== undefined && retorno in elemento){
                    return $rootScope.geraAleatorio(min, max, elemento);
                }
                return retorno;
            };
            
            
                $rootScope.converteObjetoData = function (input,tipo) {
                    var objData;
                    if (typeof input !== "object" && input != undefined && input.length > 0) {
                        objData = new Date(input.replace(" ", "T"));
                    }else
                    if(input == undefined || input.length == 0){
                        return input;                        
                    }else{
                        objData = input;
                    }

                    if (input && input.hasOwnProperty('date') &&
                            input.hasOwnProperty('timezone') &&
                            input.hasOwnProperty('timezone_type')) {
                        objData = new Date(input.date.replace(" ", "T"));
                    }
//                            console.log(objData); 
                    if(tipo === 1){
                        return $filter('date')(objData, 'dd/MM/yyyy HH:mm');
                    }
                        return $filter('date')(objData, 'dd/MM/yyyy');
                };
                $rootScope.converteDataObjeto = function (input,tipo) {
                    // Ignore things that aren't objects.
                    if (typeof input !== "object") {
                        return input;
                    }
                    
                    if (input && input.hasOwnProperty('date') &&
                            input.hasOwnProperty('timezone') &&
                            input.hasOwnProperty('timezone_type')) {
                        var objData = new Date(input.date.replace(" ", "T").replace("00:00:00", "12:00:00"));
                        return objData;
                    }
                };
                $rootScope.trataDataNull = function (input) {
                    if (typeof input !== "object") {
                        return input;
                    }
                    if (input && input.hasOwnProperty('date') &&
                            input.hasOwnProperty('timezone') &&
                            input.hasOwnProperty('timezone_type')) {
                        return input.date;
                    }else{
                        return input;
                    }
                };
                $rootScope.converteDistanciaKm = function (input) {
                    if(parseFloat(input) > 0){
                        if(parseInt(input) > 2){
                            return $filter('number')(input, 2) + " Km";
                        }else{
                            return $filter('number')(input*1000, 0) + " m";
                        }
                    }else{
                        return '-'; 
                    }
                };
                $rootScope.converteObjetoDataPost = function (input) {
                    // Ignore things that aren't objects.
                    if (typeof input !== "object") {
                        return input;
                    } else {
                        return $filter('date')(input, 'yyyy-MM-dd HH:mm:ss');
                    }
                };
                $rootScope.converteDataLog = function (input) {
                    if (typeof input !== "object") {
                        return input;
                    } else {
                        return $filter('date')(input, 'yyyy-MM-dd_HH_mm_ss');
                    }
                };
                $rootScope.converteDataString = function (input,tipo) {
                    // Ignore things that aren't objects.
                    var data = new Date(input);
                    if(tipo === undefined || tipo === 1){
                        return $filter('date')(data, 'dd/MM/yyyy HH:mm:ss');
                    }else
                    if(tipo === 2){
                        return $filter('date')(data, 'dd/MM/yyyy');
                    }
                };
                $rootScope.logout = function () {
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'Logout',
                        template: 'Deseja realmente fazer Logout?'
                    });

                    confirmPopup.then(function (res) {
                        if (res) {
                            logout.logout();
                            $state.go('login');
                        }
                    });
                };
            _getModelo = function(){
                var dispositivo = ionic.Platform.device();
                return {
                    'Plataforma' : dispositivo.platform,
                    'Versão' : dispositivo.version,
                    'Marca' : dispositivo.manufacturer,
                    'Modelo' : dispositivo.model,
                    'Versão App' : $rootScope.appVersion,
                    'cordova' : dispositivo.cordova
                };
            };
            
            _getVersaoApp = function () {
                var defered = $q.defer();
                var promise = defered.promise;
                if (window.cordova) {
                    cordova.getAppVersion(function(version) {
                        console.log(version);
                        $rootScope.appVersion = version;
                        defered.resolve($rootScope.appVersion);
                    }, function (err) {
                        defered.resolve($rootScope.appVersion);
                    });
                }else{
                    defered.resolve($rootScope.appVersion);
                }
                return promise;
            };
            
            _getInfoAparelho = function(){
                
                
                
                var defered = $q.defer();
                var promise = defered.promise;
                var dispositivo = ionic.Platform.device();
                var modelo = {
                    'Plataforma' : dispositivo.platform,
                    'Versão' : dispositivo.version,
                    'Marca' : dispositivo.manufacturer,
                    'Modelo' : dispositivo.model,
                    'Versão App' : $rootScope.appVersion,
                    'freeDiskSpace' : 0,
                    'Espaço Livre' : 0,
                    'utilizadoApp' : 0,
                    'cordova' : dispositivo.cordova
                };
                
                $cordovaFile.getFreeDiskSpace().then(function (data) {
                    modelo['freeDiskSpace'] = data;
                    modelo['Espaço Livre'] = $rootScope.tamanhoArquivo(data,1,'KB');
                    return Media.excluiAntigos(cordova.file.externalCacheDirectory);
                }).then(function (data) {
//                    console.log('exclusão');
//                    console.log(data); 
                    
                    return Media.folderSize(cordova.file.externalApplicationStorageDirectory);
                }).then(function (data) {
//                    console.log('testeeeeeeeeeeeeeeeeee');
//                    console.log(data);
                    modelo['utilizadoApp'] = data;
                    return _getVersaoApp();
                }).then(function (data) {
                    modelo['Versão App'] = data;
                    defered.resolve(modelo);
                }, function (error) {
                    modelo['freeDiskSpace'] = 0;
                    modelo['Espaço Livre'] = error;
                    console.error(error);
                    defered.resolve(modelo);
                });
                return promise;
            };
            $rootScope.getInfoAparelho = _getInfoAparelho;
            
            $ionicPlatform.ready(function () {
                
                $rootScope.configEmpresa = $localStorage.getObject('configEmpresa');
                
                if($rootScope.configEmpresa === null){
                    $rootScope.configEmpresa = {
                        nome: "",
                        baseUrl: "",
                        documentacaoUrl: "",
                        imageUrl: "", 
                        baseUrlOauth: ""
                    };
                    $rootScope.fecharCarregando();
                    $state.go('login');   
                }
                screen.unlockOrientation();
                $rootScope.getAlturaLargura();
                var localizacaoTemp = $localStorage.getObject('localizacaoUsuario');
                if(localizacaoTemp === null){
                    var localizacaoUsuario = {
                        posicao : "-22.16579 | -49.96497",//Coordenadas Sasazaki
                        dataAtualizacao : null
                    };
                    $localStorage.setObject('localizacaoUsuario', localizacaoUsuario);
                }


                // Configura a notificação, altere o senderID
                var push = PushNotification.init({
                  "android": {"senderID": "737470586169", "icon":"xhdpi", "iconColor":"grey"},
                  "ios": {"alert": "true", "badge": "true", "sound": "true"},
                  "windows": {}
                });

                // veja a explicação seguir
                push.on('registration', function(data) {
                   console.log(data.registrationId);
                    NotificationPush.atualizaRegistro(data);
                });

                // O que fazer quando clicar em uma notificação
                push.on('notification', function(data) {
                    NotificationPush.nova(data);
//                  alert('Notificação acionada, agora deve-se implementar a navegação no app de acordo com os dados: ' + JSON.stringify(data));
                });

                // erro caso não possa registrar (veja a explicação seguir)
                push.on('error', function(e) {
                    console.error(e);
                  alert('registration error: ' + e.message);
                });



//                var push = new Ionic.Push({
//                    "onNotification": function (notification) {
//                        console.log(notification);
////                        alert('Receved a Notification!');
//                    },
//                    "pluginConfig": {
//                        "android": {
//                            "iconColor": "0000FF"
//                        }
//                    },
//                    "debug": true
//                });
//
//                push.register(function(token) {
//                  console.log("Device token:",token.token);      
//                  push.saveToken(token);  // persist the token in the Ionic Platform
//                });
                
                var criaCamninhoLocal = function(path, directory) {
                    $cordovaFile.checkDir(path, directory).then(function (success) {
                    }, function (error) {
                        console.log('error');
                        console.log(error);
                        $cordovaFile.createDir(path, directory, true).then(function (success) {
                        }, function (error) {
                            console.log('error');
                            console.log(error);
                        });
                    });
                    return path + directory;
                };
                
                
                $rootScope.urlAnexo                 = $rootScope.configEmpresa ? $rootScope.configEmpresa.documentacaoUrl + '/anexo/' : null;
                $rootScope.caminhoLog               = criaCamninhoLocal(cordova.file.externalCacheDirectory, 'log/');
                $rootScope.caminhoAnexo             = criaCamninhoLocal(cordova.file.externalCacheDirectory, 'anexo/');
                $rootScope.caminhoFotos             = criaCamninhoLocal(cordova.file.externalCacheDirectory, 'fotos/');
                $rootScope.urlFotos                 = $rootScope.configEmpresa ? $rootScope.configEmpresa.imageUrl + '/img/os/' : null;
                $rootScope.urlLayoutProposto        = $rootScope.configEmpresa ? $rootScope.configEmpresa.imageUrl + '/img/layoutproposto/' : null;
                $rootScope.urlArquivoNaoEncontrado  = $rootScope.configEmpresa ? $rootScope.configEmpresa.imageUrl + '/img/arquivo_nao_encontrado.png' : null;
                $rootScope.arquivoNaoEncontrado     = cordova.file.applicationDirectory + 'www/img/arquivo_nao_encontrado.png';
                $rootScope.caminhoLayoutProposto    = criaCamninhoLocal(cordova.file.externalCacheDirectory, 'layoutproposto/');
                $rootScope.urlDocumentacao          = $rootScope.configEmpresa ? $rootScope.configEmpresa.documentacaoUrl + '/documentacao/' : null;
                $rootScope.caminhoDocumentacao      = criaCamninhoLocal(cordova.file.externalDataDirectory, 'documentacao/');
//                console.log(cordova.file.externalCacheDirectory);
                
//                manipularArquivos.listarDiretorio(cordova.file.externalCacheDirectory).then(function (data) {
//                    console.log('fileTypeCollection');
//                    console.log(data);
//                }, function(err){
//                    console.error(err);
//                });
//                manipularArquivos.listarDiretorio($rootScope.caminhoLog);
                
//                var file = Media.folderSize(cordova.file.externalCacheDirectory);

//                Media.folderSize(cordova.file.applicationStorageDirectory).then(function(resp)
//                {
//                    console.log('tamanho final');
//                    console.log(resp);
//                });
                
                
                $rootScope.enviando = false;
                $rootScope.dataEnviando = null;
                $rootScope.buscando = false;
                if (!OAuth.isAuthenticated()) {
                    $rootScope.fecharCarregando();
                    $state.go('login');
                }
                
                // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
                // for form inputs)
                if (window.cordova && window.cordova.plugins.Keyboard) {
                    cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
                }
                if (window.StatusBar) {
                    StatusBar.styleDefault();
                }
                if (window.cordova) {
                    cordova.getAppVersion(function(version) {
    //                    console.log(appVersion);
    //                    appVersion = version;
                        $rootScope.appVersion = version;
    //                    console.log(appVersion);
                    });
                }                
                $rootScope.usuarioLogado = $localStorage.getObject('usuarioLogado'); 
//                $rootScope.usuarioLogado.assinaturaDigital = "data:image\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkIAAAC0CAYAAAB480MtAAAgAElEQVR4Xu2dC\/h8W1nXEQQBDQUpEk0G8ZIikZZYSTl4RQxRwTToMic1LwUcTFMpbU72gD4iHMUbmDpeQxQhBB81y9GiNCVRUUlTxtTQslC8QgK9n3P2G+9Z\/31Za8\/ee\/ae\/V3Ps57f\/GbW5V3fdfuud71rrbe6k5wQEAJCQAgIASEgBFaKwFuttNwqthAQAkJACAgBISAE7iQipEYgBISAEBACQkAIrBYBEaHVVr0KLgSEgBAQAkJACIgIqQ0IASEgBISAEBACq0VARGi1Va+CCwEhIASEgBAQAiJCagNCQAgIASEgBITAahEQEVpt1avgQkAICAEhIASEgIiQ2oAQEAJCQAgIASGwWgREhFZb9Sq4EBACQkAICAEhICKkNiAEhIAQEAJCQAisFgERodVWvQouBISAEBACQkAIiAipDQgBISAEhIAQEAKrRUBEaLVVr4ILASEgBISAEBACIkJqA0JACAgBISAEhMBqERARWm3Vq+BCQAgIASEgBISAiJDagBAQAkJACAgBIbBaBESErqvq38GK81Dzf74q1sn+\/pR5\/soJASEgBISAEBACCQIiQsttEpCex5jfmt+Yf3\/z92oozg\/Z959l\/hXLLa4kFwJCQAgIASEwPAIiQsNjOnaKaHuebP5jzUOGct3JAj7CPH\/lhIAQEAJCQAgIAUNARGg5zQDS89XmP6qFAP2O\/far5l9eFevx9veuoYhPsc+3LqfIklQICAEhIASEwLgIiAiNi+8QqUOA0ADtk8QgPS+q\/NH+\/nZNZmiPfjJ8\/zL7\/PAhhFIaQkAICAEhIASuAQERoXnXIttf32g+boH9vv3\/DPMH86cM8d9gYVwr9Mv2+UEZcRRECAgBISAEhMAqEBARmmc1Q3wgQBAhd2iA9uZLtrZI57UhjVfa54fMs8iSSggIASEgBITA9AiICE2PeVeOGwvwQvN+BJ7wt1QkqCtu3e9vDl\/+sH3e9klEcYSAEBACQkAIXCMCIkLzqlXIDyQIMoTjDiC0QqeeYqYaIRGhnkAqmhAQAkJACFwnAiJC86nXnYnCdpi7b7IPN5uvM4LOlVpEKBcphRMCQkAICIFVIiAiNI9q\/zYTg6PuOGyBIECHAUTbWhpcpujuX9uHaHc0QBZKQggIASEgBITAchEQEbps3W0s+2cFcvIr9nln\/jiQWKQVtUxfXpGsgZJXMkJACAgBISAElo2AiNDl6g8SFI2iX2L\/P9H8aUCRXmxpPTqk9372Wc9sDAiwkhICQkAICIFlIyAidJn6wyiaLSu\/H+icU2FtJXi9\/Xi3KsBr7O\/9L1Nc5SoEhIAQEAJCYJ4IiAhNXy\/xkkTsgfj\/OIIYO0szbos92\/5\/0gj5KEkhIASEgBAQAotFQERo2qrbWnZsh6EJOvdofJfkkKsPrgJBuDbmzzmB1pWffhcCQkAICAEhsDgERISmq7K4HQYJihcmDi1F+sYYR\/F3Q2ei9ISAEBACQkAILB0BEaFpahAN0KsrTRCXGrIdNqZ2hsdYHxOKJiPpaepZuQgBISAEhMDCEBARGr\/CIEG8AL8xz\/F4\/o7pUm3Q2NqnMcuitIWAEBACQkAIjIqAiNCo8N6W+M+Yf9+JSBD5pdqgj6u+G7+kykEICAEhIASEwMIQEBEat8KclLzOsnmA+TG3wygJW24YY7uTNmjc+lXqQkAICAEhsHAERITGq8C9Jf3PquTvPQEJinZIXirZBo1Xv0pZCAgBISAErgABEaFxKpG3wng6g2PrW\/NT3OacbonpOY1x6lapCgEhIASEwBUhICI0fGXGY\/JT2ed8phXjq0JR9Ljq8PWqFIWAEBACQuAKERARGrZS4\/bUUyzpW4dNvja19JTYFMfzJyiWshACQkAICAEhMD4CIkLDYny05LjNeaoLDOPRfEry8+YfZf40bLGUmhAQAkJACAiB60RARGi4et1bUhhHc1Jra37sE2JIju3RQ6sikO+u+m64UiklISAEhIAQEAJXjICI0DCV68fWpzKORhPEg6rkiyNfSBAG03JCQAgIASEgBIRAJgIiQplAtQTb2G8\/ZJ6\/UxlHHyyvvxtkusk+852cEBACQkAICAEhUICAiFABWA1B\/dj6VMfVdUz+\/DpTCkJACAgBISAEbkNAROi8hsCpsCeb56TW9rykOmOzHcbdRLsQkmPy\/D+FPVKngAogBISAEBACQmBpCIgI9a8xtwviIVVI0Kl\/Up0xU5sgIkxBvjoFUwAhIASEgBAQAktGQESof+292aJipAwhOvZPpjMmJAgbJO4LcjfV8fxO4RRACAgBISAEhMCSERAR6ld7bEW9vfmxjZTjLdUu6VS2SP2QUSwhIASEgBAQAgtCQESovLIwVn6Y+eeb502xsRyaJmyCNlUGaJ\/I7zBWhkpXCAgBISAEhMDaEBARKqtxN44e+y2vnYnF22H3rMTDDonvjmXiKrQQEAJCQAgIASHQhoCIUH778BflISWb\/GjFIcmHG6qxDcJhFA0JOhWnpAhCQAgIASEgBIRAKwIiQnkNJJKg7YikxDVOLtX324dH5omoUEJACAgBISAEhEApAiJC3YjF5zPGPCGWXpR4i4m27xZPIYSAEBACQkAICIG+CIgItSMH8eFNL7apHmH+2Bfolnik\/ULz2yoMRtEQILRDckJACAgBISAEhMCICIgINYMLMeH+HtxYb4htKhIU7wgaK68Rm5GSHhEBiPISbg5\/gsn5KPPvav4HzXOg4BUj4qKkhYAQEAKDICAiVA9jJEFj3RUECfLHWl0KkaBBmvVVJLK3UvB8C0ToYJ52ODdHG+bx3515PqdOF3\/OrcYkjxAQAjcgICJ0Y6OI22FjkaCYh0sw1tabmv3yEHiAiXxKxH5gzXeXKhnkjJONXfdoocm696WEVL5CQAgIgRwERITuiBKr2p80z0A\/hrFy3QSCTdDWvLYRclrsOsJ8thXzS5OizkVbSBumj9BXutzvWoB7dQXS70JACAiBSyIgIvQW9OMAP8YzFjvLilV0nEB+yv5HO3S6ZCNQ3rND4AdMog9PpBqDmPcp+G9YpPs1RHytfX8P83cPv2uM6YOy4ggBITAZAhqk3gL10T5+sPmh7RowhIYAQXiig2ztzS\/BEHayBqmMbkPgleYfnGDBxZrbC+KzsbxfZv7+NTJgGM0pR\/rQr4cw0ghdsMKUtRAQAnkIiAjdjpNfmIiGhslmCHLSZEfBzdTkx71BckKgDoGTfYmdUHSXtLehT3DFA206OsgZbdm3dSH9bJu5e4F9eJyqWAgIASEwZwSuhQihbXk\/868zz+DLRJLrNhbw1eax1WEgL4nblAeTQ3wmw8NJC5RbK+sO9+aG4mN4PARJL0F3a4HrSNCn2ffPTRLiFCTh3c3JwLukzAorBITAihBYOhFi0OVx0vdJ6qzEsJTV7EPNl8RpaiK7igBtkgCnKn0ZRK+oc\/UsKm3a769Kk4DsT9mGUg0P8qDR5PuUkKVyj\/0wcU94FU0ICAEhcEcElkyEPt+K8rSGCmWyYNLocr4ldq5dEJMAGiD+RqdtsK4a0O8pAmg30cDUuamvWPBFgsvSZtyfhpU2SG1bCAiBRSCwRCKEncL3mH94B8Jdq+eNxWdLDLICgTn1qDFWxs+qIUAkxSmfQ890e4iiKFeCwN7KAanGvcn8nUO5piRCvkjw7Nv6yc4C8RSNO2mDrqQxqhhCYA0ILI0Iba1SMDJ++4zK6TpufLQ0IDIM+IeM9GKQjf0DAWL1njomAdI8Faap4EIABGjfj6mg+C37e98Ay1REiPaNhsf7WdtdV4T1u7dcVGmD1JaFgBBYDAJLIkIMuOmTFAD9evPfav69zEct0Uvs\/0c31AQE5nnmf9T8tqC2kIGVb10cCNC+mkAKklRQIXAHBOIW08l+oc25+xz78IwJ8IpkjOxuMn9oyPf77PuPDL91LUAmEF9ZCAEhIATyEVgSEaq7ZO4PraiPN8\/ADbH5xFD059jnT6+Bgq01CBXaoNxTOFsLW2cDRPLpEeJ89OcXEoLI21FuDMukBrZy0yEQT4z9uGX7ASHrp9rnp48sSrol9u2WHw+q1jn6RTTsxoaItiMnBISAEFgMAkshQjtDNNogADDqeibuY4V2GqZpZXqrhecxy5yVKwM9W2B1gzsEaB\/yX0ylNwhKWb7AfLRJOdn\/bHPITYNAPKUFqYCEur0QEjzFPO13LBfzJ4+2e7UICwliYYH7JfPvPpZgSlcICAEhMBYCSyFCTMjpBXOpvcTOwkSyVEd0NhYGA+muixNJK30OgzqAfDE5MRmxhXEtLsUulmspbeQa6iJqY7hzCgdpd5dD3s\/BIW7LkU7TgQP6Udwi7upP58ikuEJACAiBURFYwiS3NwTiqhhAnm3+SQkyqUq\/7r2wo8XhGY2mlTWEoI4AMdBDfiBBvz1qjUyfOJNaauzqUvxf+3C36UVabY6urQQA7rVC6xLb\/phEKOZN\/k15oQHieP+2qqW2I\/WrrUgVXAgIgeUgMHciVDdJNx3NhcREjdA32f98546BG1U+x4BJNzrCpQQI7c+h8tek\/UlbZ0og4++\/YP9ghC43DQJHywaijsN+jbqJRCht00NJlbsllpIg3hV7l6GEUDpCQAgIgUsgMHciBBHBeNdd2+ozndDTFa2r\/eOW2tYShjxtQh5MNmh+8GtwaLiariNoMjhfAy6XKKMbSjtZT9v0WEQod0uMPuFH+8En97DBJbBUnkJACAiBLATmTIQgKfFESttdJhS2jQjtKsKDgTPpfqx5bC\/4jOP7g\/lr3PpqawgpxmnYIZ4dyWqICnTbNpg\/WOqEZwoi1LWA8KqJJKirL6o6hYAQEAKLQWDORChdpd5UkZUmcPf2Q9xGiOE9rU+1MBwFvp\/5N1TEhwH+mre+2hoj5C9q3P7I\/r97FeEP7O\/bLqYlL1\/QnRXBt3bdhi1+Rwnr7N7OKTlbXRwe4C+uyeg5JUvpQYVzZFBcISAEhMBFEZgrEUJjE99bypkA9hYnEiGOfZ\/MQ3y4cPH3zP+xeWyMnmn+py+K\/OUz31STYJMkOZhfvhTXI0E0VnaikfaDoY2lU4JTd0osDdO1ILmeGlFJhIAQWAUCcyVCURuEvQTbBtiytLmD\/ejaDeLwP4an2yoSN01zT85atT8pdukE90YLcJcq0OvsL9cVdGG+ik4yUSFp4\/sK812VZ0qEhiYh0T6sjvim+Y99j9FEUCsbISAEhMBbEJgjEYoTdHppYlvdvcp+9BNOXPv\/SPNc8vYg8680\/xBV\/B0QSLce449jGeWqCsoQSInIkFtSsZ\/VLTYeZaK+NIg7tDaqDAmFFgJCQAiMhMDciFBqs1CyPfP7htE9K5xYuR7Ms92AlmjolfRI1TFZsuD82obcIJ9uMzKZQMqoFoGUCPl27xBwRW1Q2j+2lkE8qCBN0BCIzzcN+ru0v\/OtH0k2MgJzI0KQF9\/ewnCT7YIct7FAGH2641gvju8oI7+ro78Fn3SCjRiLNOa0uGnCRK3MkJdbRm2Qn6T0EtHn4tMZ32D\/f\/I0xVUuF0Bgb3liW4mGGBsxOSGwOgTmRIQYgP34MBVRsg0QJ3bU\/BAfH+y1zXNjs0ZTFp9u8BAl5HN1neUCBd5WpISs0Xi+3QAysPpny\/g+VVpRy0S\/ibeMc7BgZ16LiAGAn2kSR5MrXuKpup5pRUms8RCYCxFicI7X9peSl73F9xNjfvO028DUnYQZD9FlpPwbJiZXCET3JvvnseZftIwirEJKSIgfqU81N30BiNqg+FQNfRASBBnCiRT3RXhZ8bYmLuPnsfq7LOklrRAYAIG5EKHUQJrBuGRlQif2VQ1GnUzmDOoazG9sJGAbtxE9xFAT7QDNUklUCOzs75BEKNrgoTllEjyZ53u2w3wrOv6myhACQkAIXDUCcyBCqeFun9uM\/WkCKostNSYQbI1k5Hlj842kEy3Qnasg0pzNr6vvTaRU03mOlHFL1PvGpiJbkCIcxvIQIgiSnBAQAkLg6hGYAxE6GsquzfFtrRLgGcDjCRcMpf22XD6XaJZK8l1qWN8yjPL3wX2p5V+S3HsTdigiFBccfjJwY+k\/z\/wHVqCgCcLejjYiJwSEgBBYBQJzIEIQFR797KuOj5MF2zsH82wnlNoZraHCmfjqtsVKDNPXgNNcykhb9lOUJVdJ1Mkf0+Jk4NE8dnnaDptLbUsOISAELoLAHIgQWzWsQlHb9zHUjRoO1P078w81r8n9xiYVt8X8V2mDLtL1sjKlP\/hr79i+7bNi3RhoY1\/5aTDX+rBYcBLEbx9v\/tQzfUUTAnNHAI2odgfmXksXkm8OROicoqf2RZ9kiaHql5F0PapH+9q3IT2Etg\/PaYHjxo311cd2zqWLtkFstaERghzh0KKyENEkMW5dKvVpEKBdsxCG5H9Y9devneCFgR8z\/ynTiKJcloLA0okQA7g\/zspKl4lDN0k3t75oVE6o7zAPeZSbJwK+bYx0fTWc8aTYb1o6b2Oe73DaPp5nvUuqMgRoz9yLxnzgWs62FIa6k6tMSoWeLQJLJ0KHivgA8NdWk7qfetEK947Nbmv\/RqNynQ6abbf8\/4JF4tpXc1e3HUoG59oczR89SXjtCECAnmj+qebvXlhYLQIKAbvm4EsnQnHF\/AyrqM\/WAN\/YXHkqgS0Rd5oI592z47Yv2s5NT3GjDZ0ncc42W08xFE0IDIoABB8tUN9+Ia3QoNWx7MSWTIRQgfqTHEwUkCL2hh9o\/rTsahlF+tdZqn+iSvn19vfPCqdRcB4q0di+sePZ9kg4pkF0+snO\/LFHWooiBOaAAG0ac4g2AsT4\/yfNv22LwP\/HfnvHORRIMlwegSUToajyf7FB+THmpeWob1MMGvHYvHC6fN\/rkgDi41uZfU+MxadUXm7pPc48k4ScEFgiAjsT2m9aj\/LzIPFrzbPQu0dmwX7dwr1LZlgFu3IElkyEjlY3fgLqNfb5ncxLG1TfYP+Dff1B1U9vsL8YzMrNG4FPNPE4AYkr3craWBwWBw+p4mv1O++6dunYDv1k8+9rnvGNqy1k63g7Op9v\/mkDVuMQfQLj7GeZp79x1QWmB6qvAStpqqSWTITcPuhUNUQdma9vNen2yPdbsEdO1cCUT28E9hbTb5Uuef6EQTlelIgADNCH3pIoYikCEBruf2JMwkary1FnzzH\/oebvEgKr3m4H44vNf24XiA2\/\/6597yYBMQiL5\/v3TJNokCD6FJcBu1trfXl7f38D4q7muaJgUSR+qURoa0D7tsH\/qBq03hWr79Un+\/oB6qxnDHmXicog67dK5\/ZTSO8PmMc+wt3\/tg\/vbl4r1WnqcWPZxG1oNA9fZP5\/msdAF\/fe5tHWvav5v2C+aTtn7ZedcrXHrebvl1l12MBxRcTPm6f\/UA8\/Z\/6eDfFz+1Ua\/Wvsi0+vSbPvFnZm8WYZbGtSsV25SaRb1HzctyFcukb2JoCvll2WvseLL12WMfOvUyeXaBfGlE1ptyOAqt21Cjl3ozAgoQlidRad7MGmbWlDbuFw0pOtsrW5nRX4c8y\/T0PBf9W+\/z3z\/9k8Gjf3KdmvmydikqXz38YiY2t3nwa51kZcGZeO5qNWzKHpe8DjIm29tCFcRMiaTL\/Lvnus+T80z2pKd0LcCBKdFq0Zf935Y5tzqUfJ0YzAyX5Ck5czoMSDA6T4PeYfXSUt4jttK\/sKy467bYZwX2KJfN4QCS0kjZ3JyQI3jlku+h\/bhy8zzzZZjnaTBYE\/vk0abFNyqtgd2qO6fJqgIuzLzLdtp61t0YG2De1mnVsUiV8qEYqnYaiER5g\/LqSzTyUmKmXu2YhuihWL7xc\/2DKGqKI2PU1V6CvJBww5BYPrGlxjPUN0\/5b5bzFPGrKbm75BfKllyX1mJY7rLH7L\/DsnkdYwrtFOGacg86k20+FAA8Sp4Bx7K4+ztw++awDp+Urz1I27nAWGh0Uuttv+dEelkt8\/L6n4lrBsC3JgYmveDbEHSnqQZHaWSt0JPk\/8H9iHrx4kpwkSWSIR2hguMP03msewsJTZTwDrxbNIDaRdoK5J9RzByRNjQTrwn0oSklaiDFkGv5yj8wcL53ZEkCAGJwZtH6DWarxZhvawof++JYfhc517k33576s6+u\/2F492+2ge264PD5GG0t7SHtCEQIpzNCnDolGfmi+WaK+09TaH3BgmnwoE21jYaKdFPyB+vFn\/Jfa\/a03bkka+l5pP7Yx+2r77c0lEFiHfViBnXVDyYyGTHu3HABm7pBIyeKYojdHB1x9xbgq0KFOVJRKhnSEfmeiijLLGaplJukf7368W4CLFe1W\/D40VAxqdE7sIz6OuiGMSsIkgnTSbveXmq9kmrUCsY4TzcG5bxHeLGowmRXi8zJ5gSX9rSB6yQ1+kr7RNYn9gv0ej6SG2+7eWZpz8mUxZqJzGK35rysgDcYfYpNofCA\/2N38vpMAilzil8kZS6ZqfdHGIAfsXduCQbjl7cDTr9LNUI3JOf6PdoLVq0oqR99E8\/fzS7lDVY5McU+w8DIrBEolQHOhZNW3Mz2WlM2jl9EyMQcYfoiUJsPHO9VftM3cKnesebgk83vzf7Oi4ng8TAFohuTwE4kCT9lHqkvrdhqScBPGbb6ktbjDKg2b2oaiXSD5+1v7nXqA2F+vNw527LcbETxvgZFp0vMv19AlRpGyQH0jFpiZfCBC\/ncxHLQ7G0IxXpRqQFP8HVmmn37ctCpH5u83XkQ7HLz051ncbGkwgVMiX4+ag5WVOiQbSbOveNwi\/uB2AJRIhOohfnT7Eqimn8S0pDAOHGwUyENLBvNGes2Khw3KKaWeeQbbEsRL9SyURBgzLoAYerAyX4k4mKIbSddu+6UKA+uA7XCTBcxgwl4L3kHLS3yIR+l77\/6M7MqAOo3bh3P7CA9ScNnvrhnydHAxZ7jQtcIAAUbY6x9h9MH+sfozjFl99nHlv1yVyxnSiJjqtl6b+wdhW94SHEzaXN93KLNV6My5hs8SCsu54\/5vtewhGvAoDHP6reZ5HupT7FMv460LmaDKj\/IsykvZyLI0IperNc1dNl2pMY+W7t4TjtQIMwOxv40ptDuioqPQZQHbm21S2pM8q4d+a5+ZqLoaLdkI\/bv8\/bKxCN6TLFsAzzXPjuJefspSuMCcW+7ZVs6+MI9EHfyZLyI67dLK41X5wA\/kpJrupsVlCfo8yIb3PIe+\/Mf8RHYLv7ffYb2+x\/\/mu1NF22F7pIl5Db5G7nF3aH8agg3na6SkULi1\/3wXuztJ0Qpluq8VFAlnXGTYThvjpWMcpTIy1o8MWCBLj7tPsw3MzKow6Im\/yqhtTGT+pHzc0PtpnN3MgeZ4TuVtGPmMFSTVh0fQCzJmjmQsW5ZZGhLDI\/4IK4b6qyEVVUI2wdCQ0M97Y0PrwmU7l2yJEY4XCispXp3XaBcKRHtoH3F8z\/17m0bjFCbcNs3RlR1gujourhClus6YDcrQVHDh2XPeO0I\/Y93FQaSvXpX6LKy6fsCgTV\/nvKqGYUPicrph9NdxU15cq05ryvbmqKy9zjqbgZyxw3D7rs8Cj\/X+neS7P7HL\/ywKkBxq64rT9zlgBAd82BKI9HsxDgNJJkrYN8XdS0HcyJf7JvGu\/ucYgnpr96\/Y\/hMZdvJpgY18Svs54uomU7S18CXnFsJo82271Jy\/aT8SI7UHGrej6assaqqfoa2SruzeIRBa3JeYlXxoRwvDwz1TCj6n6p1NBNn7ZPFe0M8Fc0tFRkQd1t78fFeVh9c8gQxicDya+wuE7toa2IZKHJ+1SR\/qcjPn2Kq80Pmrd6PqucLvkojwMLkwCOaskVi9Nnbgrr6l+p158AIeYMkky4DJAuqubKCMR7ruinqqM15zPvqovL2OO9uVVFpgFiLvSLWyO67NArDuwwEKJcT7VaJyrMaTP+daXk5i0XmmHkPWUsMdwKV59J\/l0q4o8YlrpQpFHVyGfad+KsrWRWMbWaIvZpHHfVnnwt8lxNB\/tUtM8A34+tpNGDrluya73T2mZPSHKzvh06J3yhSMuiQjRkHku4M7m\/8g8Wx7p6uJcOMmDzpsOGif7DrY7dH458jLgdK30IGzvFhJzZr6373zVwoBIQ8aRJscfSx22BxCgNmK4sd+j0SN5sE31HaWZtYSnHM8w\/6DCNLEvq3t3qDCZUYODLTZNDC7UE6rouIps0hbsLJxvC3yqff6Xo0qpxJsQwL4nbgPnaHe8zj3N3HGZ8SpqClOZ\/Dg3\/e9fJT8yiX98YTXSt7vsBFkkQeYP5nPGSxaab1fJkS7WcsRjK\/KrzCNb6tIFATY375iRKOMEl2JShjbHdQixrtAoUR76LZrnDzDf9sI9YzJYHTvygWRQz+5oL4zxU7u9ZRi1YJ7\/WAvdycqX2+EmE6glI1Y9fiHWGFstDCq\/aD5av0dxuPKdyXcqR2fiWDqk7O4FmcbVQmy48fudpReNM9uS93190soZ2OrSHqqdoV5m4GBy6ePmrimJq9ZfsgL6oOplbZtUwWUu9kHcpfMPzaO9ZTWLViSn7fSp0z5xkA\/tqj\/hwARM3z72SSyJw7ZTHENytDvxAAjJ5fQXCABaoLpDCK+075mUT0E2ypZuC3cRZtojcT7TPAvPOm20Z4GpAuNzyT066XMkJVsrjI+MYfxtcukE\/QIL2EX+MC\/g8dCIXVP6nMD9oMI2A3ninqB9Zh4kvzGfLi5z2lWhaJ3B4xjjgS+lneoUtiRATocrSW\/MsKgy\/Xrzc9W6qZw5GhIGl7aBYIiyM\/Cgbv6n5psIWVs+PPCIlsQnHTqbM\/g4KMQJN02Pjgr5ebF5JjF8iSNe3GtngGwbrHLTjmXJjePheJj3s8wPqZUqlSEnPJquqG6Pcbq0alGTRP1eyqXaDeS4yfzhUgKFfLmpl6PjjB+pO1VyHs+UM24LYyvn2o62ZHkJPd5a3Da+bSws2gHaSuq4yZ0tlro+u7Pv6xY\/lKy7sDoAABXHSURBVPf55jE7YMyh7dBf3XfBkavVSNMhn2gbVKINouyQiS5s03aXnnhKZUIG0s4l7d9nYT+yC6DwO+nfbJ4+UurS1xRytlxL8+gKTzv5hBAIYoQci3dLIUJbQ9qNfofe3qBD\/oL59JhiXeWWrFhKGocToL1FOmcSS\/fXeZfncytBUuPAuMLgHR+\/1fZYInhNWB5CRCXs7tzjlFw0hiFj00OHEC2IIyQ5vdG3r73BmRD0jo7NFXczpa5r1RWJbdwC7S1Iz4hMwNGWwZMZQ4NbKmKTbDEdJqhzthzSBVXu5P4Tli+v0Lur09TQxiFyTXcS0Q+YxE8twPgbjaXYpeHJ62AeTNvya8uH+Cz6cCy8tuZzCMLXW7h46WJbHqnWpGkBSHmY1JGpxFEfz+uIgF0iixvSPpYknoRFK8cWoDvIGoQ5l7SdkfVtUTfm07fWcrZ9z813kvhLIUI0Iu807HXHY4vnAgVDj\/uvpId6m4GHU2r3CxmMsbXC4MVEl158VlquugkwDnxtRGjII5mp0WLusdK0vNuqXphcUlenXj5aoKj6H0oTVVoPfcNzcu+\/mU\/vfslZpdKGXJPUd7+ePgaJOZlnJZ0zKcWycskmz0fUOTSVObYZHpe6Z9LiKDFaFTDo62g\/\/8l87vbyOYM7p5I4neQud9XOIo8yu\/sV+8BYAynDpi3+luLAU0P\/wvw+E6D0BuvMaHdCI8\/24Tnkx\/NKCUkX0ScebZxxepMpcFP\/B0u2RhlvaZdcnEiZ+hKKQyUbhzAYlzB8ph+THn0IgjWEA7OT+XjYg7G2RCPVVw4wQ5uenjQcYz7sK+NZ8ZZAhNJOM7RWhgYbGxerEwZPGl16dDF3hZdTKRsL1KTirovP2zhu4Awm8YVrbEmwn0Hm6Pb2j2+NRe1IunIlzlBtIT0BU0qEKFubASidj3LFshLn18z7RZuUJ6edbC0cBJtBlnYAATjWgT\/Bd2gl3yPJhwlxk5F3JPN9JvK69lD6blK82iIVGULzNi3lQHPJqSnun2K7I22LbDehCeZ+ns+o6ioDltu2IdJFjsfjokNez04fSKX+wbCPY2sqEq62La6Yft8X6\/tstdBXMKR\/bEYBaX+QBCbzU0b43CCpbVAbTm12gRAPDs\/Uuam1wfSh0sVDLl4ejnqIVwLwfZ\/+XpJvXGQRL71AkfllqIdmS+QaNOxQk9+gQiWJxcGMV5pzV3Y5MqWVTBwmw0OIzIrLOxuvIJ+ruSFpBl9e590kQkJouAQQLRRveLmL9klb+9K3Cf33ppUn5XBNWixXSi6H3G5M70QpudI\/HSAjPKzwdubrBhu+j\/YPfG5Sn1N2BhPipPjnrEyTKhvkXyabdEupZLtgb\/Gd8OYQwFToOiJUetVAXRk8n6Z7a+h\/32y+9CRfDsGomzSQJyXS6QVxhOnzFE2sA9L4TfNdr5U7PrRJxpYumxcPj\/b3YB7M+zryBH88NxWjFeZCVBYEJ\/P0s7Em9mhQfrR86ognbZI2jXx1Lj7rwNZ+1KQuTRucW4fUGXUTF+6M3diu8v2QjrzSBSnk0usl5nWwf5iDaDuLdEsgQlQw2wY4rP4fNyDSVKATBZJNV+Bb+y6SjnOvNyc9GheNKTomPQgfAxuNiQGII9TufHWzqeThr7u2yftogXy7qE0jxAmlnIvYErFr\/00nxJyVGXiwtRPL5YlTJ45NU\/4n+8HbCGFS2wC+25qHADUNrIRJSXBOec8NUzdhQ4i5Qyh3Iopp1JU9R8Y6IlNCqqKRcJof7ZuB1R118GzzbUeL22QGF2Src9QzthR+IiyGqdNOIhcnhaIrHWc2FhltbSxj7raY50sbb9JeEQYMqSMWSrx8vmQX2wpE2Mdg8KP+XEtbV0bGg6eZZ6s\/4h3DXqIfT1UfjJW+M+B5oonERnIoIkL\/TLchXfME5rTDaIaAHEfztPncMYs4lIVxG2J\/UTd3IkSniEQkZ1ItATTdm08Hr0PVKT3N0sHN49F40FLUTcJ1acaBgkmRi9JIA7IAJu5QjZNmUwegcXqDjYNDiisNsY0glGCaaoS6rh1IMY55ITOdrq2Dp2Vhxb+rEsFegyPc\/9j8pqUQTkSRZUqXyk7eaCA\/zDx1l+viSb0cbUlTuv\/FfogEI1ftXkcmYh4M1Nw0Tr2wym+rCzQTdzXPViHtnpNMdW9mcQowEgdkgOhCKNIJEg0B7fvUUPA6I\/USEvjvLN1Uq9GnHmivYMSihMMBaD2wA8Egt2SCyW03lwi3tUzjmI6WnzGDOmZibHJoPrgu4NbK+xYRxCgugq5VGxRxAYN0i4wxkvnx2LNS6TNopffm2fXwXRDw3CXtj7CYaqRXByDDwTx14nLwHZ44m6qutvYXz\/+4tsV8z+KURZs7EQLUqLHpM7i0IYImJF5EGFfTVNKrk8h98mdgZvBPB2cGA7ZvTkkeDNhu+MpP\/k5XaohJY2PgaCMJR\/u9jgil7yHRqOuuly9rTbeHZhvvwSFi3dYYcnOPC0aLdTdCUy9\/saNsnsXBPsQ2woTEpJHaDDWVBRJIHaX10KfsJXGwfWCQSR3EjwGtxMWJuE8b9bzSI7q5RIj6jKtUyNxdQgFIl4G17VkH2vk\/Ml9ncM2xZ97QinZG1LGTNvpWukjw7Knfnfm2fkJ86j9uOeRMqE353mJp7UsqcGVh27SHdVCwuAFP6mhj3sdltm8hUPE5n3Pa\/1KqgXb3cvNx7nLZmSf+Tkd7j+Wk7zJ+0kfiHMWlxdjjHVpAqSNkfTAcciHeJ\/\/BDGR7Zd4RiUqJKuucgalUjqi94Nj3B4YE0mOapZVFA2PFuk2EgsDQ6I4NwqaNi0mR8NGGhDRI99RR4HjhFzZJ\/pDf3j67TQlJdGltSnBN02Ylh3Em1xNgDIwKt21LhNUBabRNXFEewvkE5m0kJZN18hOWfCAeU7uNZQhhjMbdLkOfgTxi3ie+593X2DfFm4kud5HFwP0k86eOSqi7s4W+gdYEjck718SveyyzKZuIoYdpI4LUIXfZcFouuiG3madul1Plh9E7i7Eux5h7MB\/7KP\/7woc+HE0I+th2dckw199pf2CRblG5vPzGiwT\/0byPpa6V+cv23UeZx7aIdFKXO78Qb2eeOSsuIkowow5ZiB5LIg0dNnewGjrfnPRSQjCG+iyuTOIqjgZDY4hv95SoypEdNp1qO8iD33K1OODEXrjfBeS4MQHkTOAc4\/RnKLDJYMLBpfeJlJStq+7oGGwDljrwpkPklMvT3tiHqLXzbcb0+yjLj1aYluRTWpau8OSdGkcTh+0gTk+VuthXcrU4aR515DF3fKh7wqGtDGz30hbBIZfw1tUpL7v7\/VdpfqVaGdJnYRQNlrlkkIk2lXFn3zEepW97DW2rUdoOlhKe8fVYYZvKzDNKbAeiST4lP7K4dM0jl1By27W7MeaHueNJm6UPRTJ4rsxo3xiHc\/sl+SEHcRhD4jZlkyyQn0Mle1rH58rfK37uQNcr8TMiAWy6LTXkZO2VF\/OIA2dKwo4WgQmmy9EQUiMz4pQ0Lu62YIuurRExIOS4uPLy8jEIRU2b22\/kpJcThvRLTsCgguW0GJiXuqdbhM8LkeLWZtPFa2xJfkhpRgOGj4N5miw2ENwJU+oYhNxe5mCfbypNwMKntl05GtiNxcNWgW3O3JNf51yumJ7wSrfgKPbvmAcPcCh1EUePi90UBr2cAqOMnObkCYbUkS\/9\/1ia6YrDo8FBK8GRbNwrKt8ECdcdvHf1I5f7RRuVczShS68CLq3t0+djudG+MQYP0X43VcL8ZT7AObEaIv3B62uuRChdMaMtcHCHAoH0IhGCrOzM101UOavsg8WNtirIyeDJajm38lOSUndPRgkhJF9XnfqKKSV5PNha+nhpVx3UaRdiHCYNZKOewa2vi0SPi8zSk0Jb+44L0yKxZDCNNkx98+4bL8Xf0wGTjfmSlZjHTdts6RbBzhJKtXiuXYvlRD7aE7ji+T\/XUb69+T6E1\/Ogf3BqqmnQZ0JlcmRC7etSu8GcdE4WiIlYbjwE4pjCkzn+3BI5+tg9Xu7zT5m+SN+q0zTXSc8C9IfN85D20XyfcWf+qGRKOEciVEdExlJ7cmLBt69oDBCe1GC0zTaIgZmGRwN05uvQ95E5JUJpNZZ2+EgUftYS41RKqmmrm\/Aym09rMOqRi\/LooNhxcNcHpIttOS6zG8LReX1vuqkcdds2UXM0hBy5aVC\/4J+2FeIzuR9yE6oJR7pgjWva0kmjUUc8kpkSSLYdmGj4HeLDJMTnOrm7RGYxQDs4hwDFPNqeWMjdMm6TmXL+oPncm7DRTKR2Ql2Y6PcyBNJ+gz3nw0ISl+rPZaWYJjRjAP2VwxicPGRRwHfuTvbhWPlpJFpALnMkQgfDLdWsjKX2jNsBMGTU9pFR8909knqkUzI58PYLxtWpkdjQqnnPHq3Y1jwNOdfB+LmPBsexZEgex8mjW+ogkhLmNk0ZJCyeYhpiwsytgxhuZ\/\/U2U8N8WwMl3Ty+rc7to24Fv+f1LQZBkq2tLYNhcAOAzxzHdtoR\/O0US4Dpd9AUvnuHO1MXf4Qt7onds4lkjGvrgUJYdn+RTt1qMqai5XClSOwtyh+uAPNr2+PkVKfBWe5BIpx1QjMjQhtDO1UYzHmq++sUtP7GGKFY3XPW0cMjHjkwzc5tEc3mz\/1bDVHi9d0CqAPGezaOx7y2HzPIveOtrOYkVS0teV4eo4M50SEKAN34pyrmqZ90n5Sw0mIOXZRP2YeksJR9KYbjNNJJq0cCA9tG3KD98+9K7FHxLTeSYJJcuhr\/sGTvCCN2ASxkODIMttvaDSf20N2RSlHYGNRIOaujYzaINo2CyLaoZwQ6I3A3IjQwUqSaoPG2roBNDoZb2O1vYPUBS6d8UXmIVXnrn5Jp26Ptw8JQu69+XhMPi0L2qKmhzK7yn3p32PZmKAZEJscW0VREzak9qAEBwbzk3nXIpZudXbltbUAbIfGe1W64vjv3OPzN6o2jHzermnTxwHadq4cXeHAkL4GQQFL2gH9Ru46EThYsXxO4FTle4Zi3lLV\/3WWXKWaDIE5EaF0H9hBwKYErRCDHo6\/bPkM4WInK02PI8DPN88pH5etNI00\/Na+YJBnVc\/Kh606tDp900+3j2J+XeTh3LKMHT\/eBkx7ALs6t7Ev0zt7uDwSbdilHLJSp33rtU1u+lHdra9NcdjOos3hca75PJfUXwpb5Xs9CNB34w4BY5ZrPJc+fl1PLV1BSeZEhHaGZ2o\/UXc8NsJ+DBMKAzfbCwzscZuBgR3PKvdvV3+55I8Vpatbc6synnZiFRrzyU1j6nC8jxZXUZ4\/huHgt1SHuty1QD9in5u2FOsu4luqXVRJXdGfIDd1F51xSID3qnh6ZMltoAQPhV0eAlFDHkkQ4\/DWvMj68up0lhLPiQjRqFP7hpN9t5kQObZMkAOCxPYCxzT5DOFBliUQnxQu5If04bgThWvZmfyWWJZYtngirsnYeGcReIAzbhWtzbiSU3OcCuMqBhzteCkkPm3L+n89CKTa7J+wovPsDu455rnPSU4IDILAXIjQxkqTGklTQFbudAjX3PDZ\/2\/SAPQFRvvNfZG7TLyjZZvekRQlgfxh7B4f7HyD\/c\/NzafLiKxchYAQyETgYOHcNoi7nfyuMzT+zBdyQmAwBOZChG62EvnNuF44rs\/\/iI6SQoroFNvwt\/TNE1Sue\/OskuWWg8DRRHUixGk913pRAq42QBOUujEN75eDnCQVAvNGgIVvvP0+SnupE5\/zRkzSnYXAXIhQ3bZY35M9dCInSJAkd3zPY3Mcg0XNejLPZKp95rOa0MUiR\/sBjjTzgClkiMv76t7rwrj6CReTVhkLASGQiwCP5XL5Kw57Tr\/uYehTlrnyKNyVIzAHItTE\/vseGb\/yKlPxKgS+wv4+MaBR9xyJ\/6zbf9VshMAyENiamNx7lToMpDfml27buIxaWJmUcyBCO8M8PS32a\/ZdegPyyqpGxe1AIDWmbArOKpKtVw2galJCYP4I1O0OILW2xOZfd4uVcA5EKG5xOJAyXF5sk5pUcO4P8idE0ox55uGp5lPbs0kFVGZCQAhkI1C3KCaytsSyIVTAPgjMgQjxGnh8O4ZyaFusT22uLw5aIYj0A0LRuYjya6rvpQVaX5tQiZeJACYSdQ8Sc0qMfq6+vMx6XYTUcyBC8YZgQHPD10UAKCFngcDGpMCjVteAOYsqkRBCoAiBnYWue5C47THlogwUWAg0ITAHIsRJnxcGAdOj0Ko9ISAEhIAQuG4ETla8qNmltE0XpV43Eird5AjMgQhR6IN5CBGdAcPW4+RIKEMhIASEgBC4BALpYhgZXmP+r1RzwiVkUp4rQmAuRGhFkKuoQkAICAEhEBBg4Zu+FND3HjkBKwSKERARKoZMEYSAEBACQmAgBDaWTvq8ErdK32eg9JWMEOhEQESoEyIFEAJCQAgIgZEQuNXSfXKS9hfZ\/184Un5KVgjcgICIkBqFEBACQkAIXAoBTnnG9yHfaP\/f17xOf16qRlaYr4jQCitdRRYCQkAIzAABHkF+ZiLHS+z\/R89ANomwIgREhFZU2SqqEBACQmBGCLzKZIkPJKMNeusZySdRVoKAiNBKKlrFFAJCQAjMCIGNyZIaSb\/UvvNX52ckqkS5dgREhK69hlU+ISAEhMD8EKgzkr63iSnboPnV1dVLJCJ09VWsAgoBISAEZodA+tj2C0zCx81OSgm0CgREhFZRzSqkEBACQmBWCOxMmvi2mN4Um1X1rEsYEaF11bdKKwSEgBCYCwIbE4SX5Y\/mtSU2l1pZoRwiQiusdBVZCAgBISAEhIAQuB0BESG1BCEgBISAEBACQmC1CIgIrbbqVXAhIASEgBAQAkJAREhtQAgIASEgBISAEFgtAiJCq616FVwICAEhIASEgBAQEVIbEAJCQAgIASEgBFaLgIjQaqteBRcCQkAICAEhIAREhNQGhIAQEAJCQAgIgdUiICK02qpXwYWAEBACQkAICAERIbUBISAEhIAQEAJCYLUIiAittupVcCEgBISAEBACQkBESG1ACAgBISAEhIAQWC0CIkKrrXoVXAgIASEgBISAEBARUhsQAkJACAgBISAEVouAiNBqq14FFwJCQAgIASEgBESE1AaEgBAQAkJACAiB1SIgIrTaqlfBhYAQEAJCQAgIAREhtQEhIASEgBAQAkJgtQiICK226lVwISAEhIAQEAJCQERIbUAICAEhIASEgBBYLQIiQqutehVcCAgBISAEhIAQEBFSGxACQkAICAEhIARWi4CI0GqrXgUXAkJACAgBISAERITUBoSAEBACQkAICIHVIiAitNqqV8GFgBAQAkJACAgBESG1ASEgBISAEBACQmC1CIgIrbbqVXAhIASEgBAQAkJAREhtQAgIASEgBISAEFgtAiJCq616FVwICAEhIASEgBD4f00dUzy6qpmMAAAAAElFTkSuQmCC";
                
                $rootScope.$on('$stateChangeStart',
                        function (event, toState, toParams, fromState, fromParams) {
//                            console.log(OAuth.isAuthenticated());
//                            console.log(toState);
                            if (toState.name != 'login') {
                                if (!OAuth.isAuthenticated()) {
                                    $rootScope.fecharCarregando();
                                    $state.go('login');
                                }
                            }
                        });

                $rootScope.$on('response:error', function (event, data) {
                    httpBuffer.append(data.rejection.config, data.deffered);
                    authService.loginConfirmed();
                    return; 
                });
                $rootScope.$on('oauth:error', function (event, data) {
                    if (data.rejection.statusText == "invalid_grant") {
                        $rootScope.errorLogin = "Usuário e / ou senha inválido(s)";
//                        console.log("invalido...");
                        $rootScope.fecharCarregando();
                        return;
                    }
                    if (data.rejection.status == 401) {
                        httpBuffer.append(data.rejection.config, data.deffered);
                        if (!$rootScope.modal) {
                            $ionicModal.fromTemplateUrl('my-modal.html', {
                                scope: $rootScope.$new(),
                                animation: 'slide-in-up'
                            }).then(function (modal) {
                                $rootScope.modal = modal;
                                $rootScope.modal.show();
                            });
                        }
//                        $rootScope.fecharCarregando();
                        return;
                    }
                    $rootScope.fecharCarregando();
                    $state.go('login');
                });
                if (window.cordova) {
//                    var model = $cordovaDevice.getModel();
                    var UUID = $cordovaDevice.getUUID();
//                    console.log(model);
//                    console.log(UUID);
                    if(UUID == 'b455469bdecaa9b2'/* model == "XT1033"*/){
                        $rootScope.db = $cordovaSQLite.openDB("/storage/sdcard0/assistenciaOCS.db");
                    }else{
                        $rootScope.db = $cordovaSQLite.openDB("assistenciaOCS.db");
                    }
                    SQLiteOrdemServico.iniciaTabelas();
                }
                
                
                var watch;
                var watchOptions = {
                timeout : 5000,
                maximumAge: 3000,
                enableHighAccuracy: false // may cause errors if true
                };

                var pollCurrentLocation = function() {
//                    console.log('teste');
                _getLocalizacao(watchOptions)
                  .then(function (position) {
//                    console.log('teste2');
                    $rootScope.localizacaoUsuario = position.coords.latitude+" | "+position.coords.longitude; 
                    
                        var geocoder = new google.maps.Geocoder();
                        var latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                        
                            geocoder.geocode({'latLng': latLng}, function (results, status) {
                                if (status == google.maps.GeocoderStatus.OK) {
//                                    console.log(results);
//                                    console.log(results[5].formatted_address);
                                    var arrAddress = results;
                                    angular.forEach(arrAddress, function(address_component, i) {
                                        if (address_component.types[0] == "locality") {
//                                          console.log("Cidade: " + address_component.address_components[0].long_name);
//                                          console.log("UF: " + address_component.address_components[2].short_name);
                                        }
                                    });
                                } else {
                                    console.log(status);
                    //                alert("Request failed.");
                                }
                            });
//                    var lat  = position.coords.latitude;
//                    var long = position.coords.longitude;
//
//                    console.log('polling lat long', lat, long);
//                    $rootScope.lastPollingLocation.lat = $rootScope.currentPollingLocation.lat;
//                    $rootScope.lastPollingLocation.long = $rootScope.currentPollingLocation.long;
//
//                    $rootScope.currentPollingLocation.lat = lat;
//                    $rootScope.currentPollingLocation.long = long;
                    
                  }, function(err) {
                    // error
                    console.log("polling error", err);
                  });

                  setTimeout(pollCurrentLocation, 50000);
                };

                
//                var watch;
//                var watchOptions = {
//                timeout : 5000,
//                maximumAge: 3000,
//                enableHighAccuracy: false // may cause errors if true
//                };

                var salvaLocalizacao = function() {
                    let observacao = '';
                    _getInfoAparelho().then(function (modelo) {
                        angular.forEach(modelo, function (valor,indice) {
                            observacao += indice+": "+valor+"\n";
                        });
                        _getLocalizacao(watchOptions)
                          .then(function (position) {
                            $rootScope.localizacaoUsuario = position.coords.latitude+" | "+position.coords.longitude; 
        //                    console.log('google');
        //                    console.log(google);
                            if(typeof google !== 'undefined'){
                                var geocoder = new google.maps.Geocoder();
                                var cidade = null, estado = null;
                                var continua = true;
        //                        var cordenadas = {
        //                            latitude : '-25.328064',
        //                            longitude : '-49.159748'
        ////                            latitude : '-15.605359',
        ////                            longitude : '-56.065748'
        //                        };
        //                        var latLng = new google.maps.LatLng(cordenadas.latitude, cordenadas.longitude);

                                var latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude); 

                                    geocoder.geocode({'latLng': latLng}, function (results, status) {
        //                                console.log(results);
        //                                console.log(status);
                                        if (status == google.maps.GeocoderStatus.OK) {
                                            var arrAddress = results;
                                            angular.forEach(arrAddress, function(address_component, i) {
                                                if (continua) {
                                                    angular.forEach(address_component.address_components, function(componente, i) {
                                                        if(componente.types[0] === 'administrative_area_level_1' ){
                                                            estado = componente.short_name;
                                                        }
                                                        if(componente.types[0] === 'administrative_area_level_2' ){
                                                            cidade = componente.long_name;
                                                        }
                                                    });
                                                    if(cidade !== null && estado !== null && $rootScope.usuarioLogado){
                                                        var localizacao = cidade + " - " + estado;
            //                                            console.log(localizacao); 
                                                        var timeNow = new Date();
                                                        var dataInicio = $rootScope.converteObjetoDataPost(timeNow);
                                                        var registro = {
                                                            'id' : $rootScope.usuarioLogado.id,
                                                            'idAPI' : $rootScope.usuarioLogado.id,
                                                            'itadauUsuario' : $rootScope.usuarioLogado.id,
                                                            'data' : dataInicio,
                                                            'localizacao' : localizacao,
                                                            'dataAlteracao' : dataInicio,
                                                            'observacao' : observacao,
                                                            'sincronizado' : 0,
                                                        };
        //                                                console.log('registro');
        //                                                console.log(registro);
                                                        
                                                        SQLiteAPIAbstract.insertOrUpdate('itadau_usuario_localizacao', registro.id, registro, false).then(function (data) {
                                                        }, function(err){
                                                            console.error(err);
                                                        });
                                                        continua = false;
                                                    }
                                                }
                                            });
                                        } else {
                                            console.log(status);
                            //                alert("Request failed.");
                                        }
                                    }, function(err){
                                        console.error(err);
                                    });                        
                            }

                          }, function(err) {
                            // error
                            console.log("polling error", err);
                          });
                    });


                  setTimeout(salvaLocalizacao, 300000);
                };
                
                var sincronizaAlteracoes = function() {
                     
//                    console.log('sincronizaAlteracoes');
//                    console.log('$rootScope.enviando');
//                    console.log($rootScope.enviando);
                     if($cordovaNetwork.isOnline() && $rootScope.enviando === false){
//                        console.log('sincronizaAlteracoesOnLine');
                        SQLiteOrdemServico.verificaRegistrosParaAtualizar().then(function (data) {
                            var registrosSincronizar = data;
                            enviaAlteracoes(registrosSincronizar);
//                            console.log(data);
                        }, function (err) {
                            $rootScope.enviando = false;
                            $rootScope.dataEnviando = null;
                            console.error(err);
                            
                            $timeout(function() {
                                sincronizaAlteracoes();
                            }, 60000);
                            
                        });
                     }else
                     if($rootScope.enviando === false){
                        $timeout(function() {
                            sincronizaAlteracoes();
                        }, 60000);
                     }
                    
                };
                
                $rootScope.buscaRegistros = function(loop) {
                     
//                  console.log('loop');
//                  console.log(loop);
//                  console.log('$rootScope.buscando');
//                  console.log($rootScope.buscando);
                  var loop2 = loop || loop == undefined;
                    
                    if($cordovaNetwork.isOnline()){
                        if($rootScope.buscando && loop2){
//                            setTimeout(function() {
//                                $rootScope.buscaRegistros(loop);
//                            }, 60000);
                        }else{
                            $rootScope.buscando = true;
    //                        console.log('sincronizaAlteracoesOnLine');
                            SQLiteOrdemServico.buscaRegistrosBackground().then(function (data) {
    //                            console.log(data);
                                $rootScope.buscando = false;
                                if(loop2){
                                    setTimeout($rootScope.buscaRegistros, 600000);
                                }
                            }, function (err) {
                                $rootScope.buscando = false;
                                if(loop2){
                                    setTimeout($rootScope.buscaRegistros, 60000);
                                }
                                $rootScope.geraLog(err, new Error());
//                                console.error(err);
                            });
                        }
                    }else{
                        if((loop || loop == undefined) && $rootScope.buscando === false){
                            setTimeout( function() {
                                $rootScope.buscaRegistros(loop);
                            }, 60000);
                        }
                        $rootScope.buscando = false;
                    }
                    
                };
                
//                var porcentagem = function(valor1, valor2){
//                    return "Atualizando: "+$filter('number')(parseFloat(valor1/valor2)*100, 2)+'%';
//                };

                
                
                var enviaAlteracoes = function (registrosSincronizar) {
                    var timeNow = new Date();
                    
//                    console.log('$rootScope.enviando');
//                    console.log($rootScope.enviando);
                    $rootScope.enviando = true;
                    $rootScope.dataEnviando = $rootScope.converteObjetoDataPost(timeNow);
//                    var total = 8;
//                    var concluido = 0;
                    var retornoProduto = {'atividade' : [], 'servico' : []};
//
//                    $rootScope.abrirCarregando(porcentagem(concluido,total));
//                    concluido++;
                    SQLiteAPIAbstract.enviaRegistros(registrosSincronizar.atos_atendimentos,'atos_atendimento').then(function (data) {
                        return SQLiteAPIAbstract.enviaRegistros(registrosSincronizar.atos,'atos');
                    }).then(function () {
                        return SQLiteAPIAbstract.enviaRegistros(registrosSincronizar.atdc_ocorrencias,'atdc_ocorrencia');
                    }).then(function () {
                        return SQLiteAPIAbstract.enviaRegistros(registrosSincronizar.atdc_ocorrencia_encerramentos,'atdc_ocorrencia_encerramento');
                    }).then(function () {
                        return SQLiteAPIatdcOcorrenciaProduto.enviaAtdcOcorrenciaProdutos(registrosSincronizar.atdc_ocorrencia_produtos);
                    }).then(function (data) {
                        if('erro' in data && data.erro){
                            return data;
                        }else{
                            retornoProduto = data;
                            var atos_atividades = retornoProduto.atividade.length > 0 ? retornoProduto.atividade : registrosSincronizar.atos_atividades;
                            return SQLiteAPIAbstract.enviaRegistros(atos_atividades,'atos_atividade');
                        }
                    }).then(function (data) {
                        if('erro' in data && data.erro){
                            return data;
                        }else{
                            var atos_servicos = retornoProduto.servico.length > 0 ? retornoProduto.servico : registrosSincronizar.atos_servicos;
                            return SQLiteAPIAbstract.enviaRegistros(atos_servicos,'atos_servico');
                        }
                    }).then(function () {
                        return SQLiteAPIAbstract.enviaRegistros(registrosSincronizar.atdc_ocorrencia_logs,'atdc_ocorrencia_log');
                    }).then(function () {
                        return SQLiteAPIAbstract.enviaRegistros(registrosSincronizar.atdc_ocorrencia_interacoes,'atdc_ocorrencia_interacao');
                    }).then(function () {
                        return SQLiteAPIAbstract.enviaRegistros(registrosSincronizar.atos_imagens,'atos_imagem');
                    }).then(function () {
                        return SQLiteAPIAbstract.enviaRegistros(registrosSincronizar.itadau_usuario,'itadau_usuario');
                    }).then(function () {
                        return SQLiteAPIAbstract.enviaRegistros(registrosSincronizar.itadau_usuario_localizacao,'itadau_usuario_localizacao');
                    }).then(function () {
                        $rootScope.enviando = false;
                        $rootScope.dataEnviando = null;
                        
                        $timeout(function() {
                            sincronizaAlteracoes();
                        }, 60000);
//                        $rootScope.fecharCarregando();
                    }, function (err) {
                        $rootScope.geraLog(err);
                        console.log(err.stack);
                        console.error(err);
                        $rootScope.enviando = false;
                        $rootScope.dataEnviando = null;
                        
                        $timeout(function() {
                            sincronizaAlteracoes();
                        }, 60000);
//                        $rootScope.fecharCarregando();
                    });
                };
                
//                var watchCurrentLocation = function() {
//                watch = $cordovaGeolocation.watchPosition(watchOptions);
//                watch.then(
//                  null,
//                  function(err) {
//                    // error
//                    console.log("watch error", err);
//                  },
//                  function(position) {
//                    var lat  = position.coords.latitude
//                    var long = position.coords.longitude
//
//                    console.log('lat long', lat, long);
//                    $rootScope.lastLocation.lat = $rootScope.currentLocation.lat;
//                    $rootScope.lastLocation.long = $rootScope.currentLocation.long;
//
//                    $rootScope.currentLocation.lat = lat;
//                    $rootScope.currentLocation.long = long;
//                });
//                };

                $rootScope.lastLocation = {
                lat: null,
                long: null
                };

                $rootScope.currentLocation = {
                lat: null,
                long: null
                };

                $rootScope.lastPollingLocation = {
                lat: null,
                long: null
                };

                $rootScope.currentPollingLocation = {
                lat: null,
                long: null
                };

                $ionicPlatform.ready(function() {
                    
//                    console.log($ionicHistory.currentView());
//                    console.log($ionicHistory);
//                    teste.teste;
                    $rootScope.excluindoAntigos = true;
                    SQLiteOrdemServico.excluiAntigos(20);
                    SQLiteOrdemServico.carregaOpcoesAvaliacao();
                    
                    SQLiteAPIatdcOcorrenciaAnexo.downloadArquivos();
                    SQLiteAPIatdcOcorrenciaExpositor.downloadArquivos();
                    SQLiteAPIatosImagem.downloadArquivos();
                    SQLiteAPIProdutoAjuda.downloadArquivos();
//                    watchCurrentLocation();
                    salvaLocalizacao();
//
//                    pollCurrentLocation(); 
//                    console.log('sincronizaAlteracoes');
                    sincronizaAlteracoes();
                    $timeout(function() {
                        $rootScope.buscaRegistros();
                    }, 10000);
                    var tempo1 = $rootScope.tempoBusca($window.localStorage['atosStatusAtualizado']);
                    var tempo2 = $rootScope.tempoBusca($window.localStorage['atosAtualizado']);
                    console.log('tempo1');
                    console.log(tempo1);
                    console.log('tempo2');
                    console.log(tempo2);
                });

                $rootScope.$on("$destroy", function() {
                if (watch) {
                  watch.clearWatch();
                }
                });
                
                $rootScope.$on('$cordovaNetwork:online', function(event, networkState){
                    $rootScope.loadGoogleMaps();
                });
                if($cordovaNetwork.isOnline()){
                    $rootScope.loadGoogleMaps();
                }
//    $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS controles (id integer primary key, firstname date, lastname text)");
            });
            
            $rootScope.loadGoogleMaps = function () {
                if(typeof google === 'undefined'){
                    
                    var script = document.createElement("script");
                    script.type = "text/javascript";
                    script.id = "googleMaps";
                    script.src = 'http://maps.google.com/maps/api/js?key=AIzaSyD5lB02HvalBjI9ktty9KwzaRMB9kkjtR4';
                    
                    document.body.appendChild(script);
                }
            };
            
            $rootScope.verificaArquivo = function (caminho, arquivo) {
                var defered = $q.defer();
                var promise = defered.promise;

                $cordovaFile.readFileMetadata(caminho, arquivo)
                .then(function (success) {
                    var dateTime = new Date().getTime();
                    var diferenca = dateTime - success.lastModifiedDate;
                    var dias = (diferenca/1000/60/60/24);
                    if(success.size === 12699){
                        defered.reject('Arquivo está salvo como não encontrado');
                    }else if(dias > 1){
                        defered.reject('Buscando novamente no outro dia');
                    }else{
                        defered.resolve(success);
                    }
                }, function (error) {
                    defered.reject(error);
                });

                return promise;
            };
            $rootScope.Download = function (url, caminho, nomeArquivo) {
                var defered = $q.defer();
                var promise = defered.promise;
              ionic.Platform.ready(function(){
        //          console.log('url');
        //          console.log(url);
        //          console.log('caminho');
        //          console.log(caminho);
        //             var url = "http://3.bp.blogspot.com/-XchURXRz-5c/U5ApPOrPM9I/AAAAAAAADoo/YZEj4qeSlqo/s1600/Final-Fantasy-XV-Noctis-Red-Eyes.png";
                     var filename = nomeArquivo == undefined ? url.split("/").pop() : nomeArquivo;
                     var targetPath = caminho + filename;

                      $cordovaFileTransfer.download(url, targetPath, {}, true).then(function (result) {
                            $rootScope.hasil = 'Save file on '+targetPath+' success!';
                            $rootScope.mywallpaper=targetPath;
        //                    window.open(targetPath,"_system","location=yes,enableViewportScale=yes,hidden=no");
                      }, function (error) {
                            if(error.http_status === 404 && url !== $rootScope.urlArquivoNaoEncontrado){
                                var filename2 = filename.split(".");
                                var nomeArquivo = filename2[0]+".png";
                                defered.resolve($rootScope.Download($rootScope.urlArquivoNaoEncontrado,caminho,nomeArquivo));
                            }else{
                                defered.reject(error);
                                $rootScope.hasil = 'Error Download file';
                            }
                      }, function (progress) {
                            defered.resolve(filename);
                            $rootScope.downloadProgress = (progress.loaded / progress.total) * 100;
                      });
              });
              return promise;
            };
            $rootScope.tempoBusca = function (data) {
                if(data == undefined){
                    return null;
                }
//                console.log(data);
                var data = new Date(data);
                var hoje = new Date();
                var s = hoje - data;

                var ms = s % 1000;
                s = (s - ms) / 1000;
                var secs = s % 60;
                s = (s - secs) / 60;
                var mins = s % 60;
                var hrs = (s - mins) / 60;
                if (hrs == 0 && mins == 0)
                    return 1;
        //            return 'just a moment ago';
                else if (hrs == 0)
                    return 1;
        //            return mins + ' mins ago';
                else if (hrs < 24)
                    return 1;
        //            return hrs + ' hours ago';
                else
                    return Math.ceil(hrs / 24);
            };
            $rootScope.tempoLocalizacao = function (data) {
                if(data == undefined || data == null){
                    return {
                        'tipo': 3 ,
                        'msg' : 'Nunca atualizada'
                    };
                }
                var periodo = _calculaPeriodo(data); 
                console.log(periodo);
                
                if(periodo.minutos < 1 && periodo.horas < 1 && periodo.dias < 1){
                    return {
                        'tipo': 0 ,
                        'msg' : 'Atualizada'
                    };
                }else
                    if(periodo.minutos < 30 && periodo.horas < 1 && periodo.dias < 1){
                        return {
                            'tipo': 0 ,
                            'msg' : 'de '+periodo.horas+' Hr(s) e '+periodo.minutos+' Min(s)'
                        };
                    }else
                    if(periodo.horas < 8 && periodo.dias < 1){
                        return {
                            'tipo': 1 ,
                            'msg' : 'de '+periodo.horas+' Hr(s) e '+periodo.minutos+' Min(s)'
                        };
                    }else
                    if(periodo.dias > 0){
                        return {
                            'tipo': 2 ,
                            'msg' : 'de '+periodo.dias+' dia(s) , '+periodo.horas+' Hr(s) e '+periodo.minutos+' Min(s)'
                        };
                    }else{
                        return {
                            'tipo': 2 ,
                            'msg' : 'de '+periodo.horas+' Hr(s) e '+periodo.minutos+' Min(s)'
                        };
                    }
                
            };
            
            
            $ionicModal.fromTemplateUrl('templates/modal-assinatura-tecnico.html', {
                scope: $rootScope,
                animation: 'slide-in-up'
            }).then(function (modal) {
                $rootScope.modalAssinaturaTecnico = modal;

            }); 
            
             
            $ionicPlatform.onHardwareBackButton(function() {
                // allow user rotate
                screen.unlockOrientation();
                if($rootScope.modalAssinatura !== undefined){
                    $rootScope.closeModalAssinaturaCheckout();
//                    $rootScope.modalAssinatura.remove(); 
                    console.log('removendo modalAssinatura');
                }
            });
        
            _calculaPeriodo = function (data) {
                if(data == undefined){
                    return null;
                }
//                console.log(data);
                var data = new Date(data);
                var hoje = new Date();
                var s = hoje - data;

                var ms = s % 1000;
                s = (s - ms) / 1000;
                var secs = s % 60;
                s = (s - secs) / 60;
                var mins = s % 60;
                var hrs = (s - mins) / 60;
                var horas = hrs % 24;
                var dias = Math.floor(hrs / 24);
                return {
                    'segundos' : s,
                    'minutos' : mins,
                    'horas' : horas,
                    'horasTotal' : hrs,
                    'dias' : dias
                };                
            };

        }).filter('orderObjectBy', function () {
                var campoA;
                var campoB;
                var campoTempA;
                var campoTempB;
                var fieldTempArray;
//                var fieldTemp;
                var x;
                return function (items, field, reverse) {
//                    console.log(field);
                    var filtered = [];
                    angular.forEach(items, function (item) {
//                        console.log(item);
                        filtered.push(item);
                    });
                    filtered.sort(function (a, b) {
//                        console.log(a[field]);
//                        console.log(b[field]);
//                        console.log("field: "+field);
//                        console.log("field.indexOf('.'): "+field.indexOf('.'));
                        if(field.indexOf('.')){
                            fieldTempArray = field.split('.');
//                            console.log(fieldTempArray);
                            for (x in fieldTempArray) {
//                            console.log("x"+x);
//                            console.log("a"+x);
//                            console.log(a);
                                if(x == 0){
                                    campoTempA = a[fieldTempArray[x]];
                                    campoTempB = b[fieldTempArray[x]];
                                }else{
                                    campoTempA = campoTempA[fieldTempArray[x]];
                                    campoTempB = campoTempB[fieldTempArray[x]];
                                }
                            }
                            campoA = campoTempA;
                            campoB = campoTempB;
                            
//                            fieldTemp
                        }else{
                            campoA = a[field];
                            campoB = b[field];
                        }
//                        console.log("campoA: "+campoA);
                        if(campoA instanceof Object){
                           
                            return ( campoA[Object.keys(campoA)[0]] >  campoB[Object.keys(campoB)[0]] ? 1 : -1);
                        }
                            if(campoA == parseInt(campoA)){
                                return (parseInt(campoA) > parseInt(campoB) ? 1 : -1);
                            }else{
                                return (campoA > campoB ? 1 : -1);
                            }
                    });
                    if (reverse)
                        filtered.reverse();
                    return filtered;
                };
            }).filter('keylength', function () {
                return function (input) {
                    if (!angular.isObject(input)) {
                        throw Error("Usage of non-objects with keylength filter!!")
                    }
                    return Object.keys(input).length;
                }
            }).filter('tel', function () {
                return function (tel) {
                    if (!tel) { return ''; }

                    var value = tel.replace(/[^0-9\.]/g, '');

                    if(value[0] === "0"){
                        value = value.substr(1);
                    }

                    var  ddd, numero;

                    switch (value.length) {
                        case 10:
                            ddd = value.slice(0, 2);
                            numero = value.slice(2);
                            numero = numero.slice(0, 4) + '-' + numero.slice(4);
                            break;

                        case 11:
                            ddd = value.slice(0, 2);
                            numero = value.slice(2);
                            numero = numero.slice(0, 5) + '-' + numero.slice(5);
                            break;

                        default:
                            return tel;
                    }

                    return ("(0" + ddd + ") " + numero).trim();
                };
            })
