angular.module("starter").factory("SQLiteOrdemServico", function ($http, config, $rootScope, $httpParamSerializer) {

    var _getOrdens = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos');
    };
    var _getCronograma = function (buscaAtendimento) {
//        console.log(buscaAtendimento);
//        console.log($httpParamSerializer(buscaAtendimento));
        var parametros = null;
        if(buscaAtendimento !== undefined){
            parametros = "?"+$httpParamSerializer(buscaAtendimento);
        }
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-atendimento'+parametros);
    };
    return {
        getCronograma: _getCronograma,
        getOrdens: _getOrdens,
    };
}).factory("SQLiteEstoque", function ($http, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window) {

    var _iniciaTabela = function () {
//        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS sqltable (id INTEGER NOT NULL PRIMARY KEY, name text)");
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdp");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdp (id INTEGER NOT NULL PRIMARY KEY, codigo text, descricao text, status text)");
        

    };
    var _getPecas = function () {
        _iniciaTabela();
        var query = "SELECT id, codigo, descricao, status FROM atdp";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _deletePecas = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdp";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setPecas = function (pecas) {
        _iniciaTabela();
//        _deletePecas();
        var query = "INSERT INTO atdp (id, codigo, descricao, status) VALUES (?,?,?,?)";
        angular.forEach(pecas, function (peca,index){
            $cordovaSQLite.execute($rootScope.db, query, [peca.id, peca.codigo, peca.descricao, peca.status]).then(function(res) {
//              console.log("insertId: " + res.insertId);
            }, function (err) {
              console.error(err);
            });
        });
        var valido = new Date();
        valido.setDate(valido.getDate() + 15);
        $window.localStorage['estoqueValido'] = new Date(valido);
        $window.localStorage['estoqueAtualizado'] = new Date();
        $window.localStorage['estoqueQtde'] = Object.keys(pecas).length;
    };
    return {
        deletePecas: _deletePecas,
        getPecas: _getPecas,
        setPecas: _setPecas
    };
}).factory("SQLiteOrdemServico", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, SQLiteAPIGrupo, SQLiteAPIDefeito, $ionicPopup, 
    SQLiteAPIDefeitoProcedimento, SQLiteAPIatdcOcorrenciaProduto, SQLiteAPICliente, SQLiteAPIAtendimento, SQLiteAPIProduto, SQLiteAPIatosStatus, $filter, SQLiteAPIat,
    SQLiteAPIatosAtividade, SQLiteAPIatdcOcorrencia, SQLiteAPIatdcEndereco, SQLiteAPIatosImagem, SQLiteAPIatosAtividadeTipo, SQLiteAPIatdcOcorrenciaLog, SQLiteAPIServico, 
    SQLiteAPIatdcOcorrenciaEncerramento, SQLiteAPIatos, SQLiteAPIAbstract, SQLiteAPIitadauUsuario, SQLiteAPIitadauUsuarioLocalizacao, SQLiteAPIatdcOcorrenciaInteracao, 
    SQLiteAPIatdcOcorrenciaAnexo, SQLiteAPIatdcOcorrenciaExpositor, SQLiteAPIProdutoAjuda, SQLiteAPIProdutoTipo, SQLiteAPIatosAvaliacao, $localStorage, $timeout, SQLiteAPIatosServico) {
    
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_atendimento"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atos_atendimento \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            atdcEndereco integer, \n\
            atdcOcorrencia integer, \n\
            atos integer, \n\
            descricao text, \n\
            dataAgendamento DATETIME, \n\
            distancia integer, \n\
            endereco text, \n\
            localizacao text, \n\
            periodo text, \n\
            dataInicio DATETIME, \n\
            dataFim DATETIME, \n\
            atosStatus integer, \n\
            status text, \n\
            tipo text)");
        _iniciaTabelaCliente();
        _iniciaTabelaProduto();
        _iniciaTabelaGrupoDefeito();
    };
    var _iniciaTabelaCliente = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            itadauUsuario integer, \n\
            codigo text, \n\
            nome text, \n\
            documentoFederal text, \n\
            documentoEstadual text, \n\
            email text, \n\
            telefone text, \n\
            telefone2 text, \n\
            celular text, \n\
            celular2 text, \n\
            contato text)");
    }; 
    
    var _iniciaTabelaProduto = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdb_produto"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdb_produto \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            linhaTipo text, \n\
            linhaDescricao text, \n\
            familia text, \n\
            produtoCodigo text, \n\
            produtoDescricao text)");
    };
    
    
    var _iniciaTabelaGrupoDefeito = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_grupo"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_grupo \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            tipo text, \n\
            descricao text, \n\
            status text)");
    };
    
    var _deleteAtendimentos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atos_atendimento";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtendimentos = function (atendimentos) {
        return SQLiteAPIAtendimento.setAtendimentos(atendimentos);
    };
    
    
    var _getGrupoDefeitos = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_grupo";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _deleteGrupoDefeitos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_grupo";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setGrupoDefeitos = function (grupoDefeitos) {
        _iniciaTabela();
//        _deleteGrupoDefeitos();
        var query = "INSERT INTO atdc_grupo ( \n\
                        id, \n\
                        tipo, \n\
                        descricao, \n\
                        status) VALUES (?,?,?,?)";
        angular.forEach(grupoDefeitos, function (grupoDefeito,index){
            $cordovaSQLite.execute($rootScope.db, query, [
                grupoDefeito.id, 
                grupoDefeito.tipo, 
                grupoDefeito.descricao, 
                grupoDefeito.status]).then(function(res) {
//              console.log("insertId: " + res.insertId);
            }, function (err) {
              console.error(err);
            });
        });
        var valido = new Date();
        valido.setDate(valido.getDate() + 15);
        $window.localStorage['grupoDefeitoValido'] = new Date(valido);
        $window.localStorage['grupoDefeitoAtualizado'] = new Date();
    };
    
    var _getDefeitos = function (atdcGrupo) {
        return SQLiteAPIDefeito.getDefeitos(atdcGrupo);
    };
    var _getDefeitoProcedimentos = function (defeito) {
        return SQLiteAPIDefeitoProcedimento.getDefeitoProcedimentos(defeito);
    };
    var _deleteDefeitos = function () {
        return SQLiteAPIDefeito.getDefeitos();
    };
    var _setDefeitos = function (grupoDefeitos) {
        return SQLiteAPIDefeito.getDefeitos(grupoDefeitos);
    };
    
    var _buscaGrupoDefeitos = function () {
        return SQLiteAPIGrupo.buscaGrupos();
    };
    var _buscaDefeitos = function () {
        return SQLiteAPIDefeito.buscaDefeitos();
    };
    var _buscaClientes = function () {
        return SQLiteAPICliente.buscaClientes();
    };
    var _getCliente = function (id) {
        return SQLiteAPICliente.getCliente(id);
    };
    var _getClienteEndereco = function (atdcEndereco) {
        return SQLiteAPICliente.getClienteEndereco(atdcEndereco);
    };
    var _buscaDefeitoProcedimentos = function () {
        return SQLiteAPIDefeitoProcedimento.buscaDefeitoProcedimentos();
    };
    
    var _buscaAtosStatus = function () {
        return SQLiteAPIatosStatus.buscaAtosStatus();
    };
    
    var _buscaAtosAvaliacao = function () {
        return SQLiteAPIatosAvaliacao.buscaAtosAvaliacao();
    };
    
    var _carregaOpcoesAvaliacao = function () {
        var objetoTemp = {};
        SQLiteAPIatosAvaliacao.getAtosAvaliacao().then(function (data) {            
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
//                delete row.imagem;
                objetoTemp[i] = row;
            }
            $localStorage.setObject('opcoesAvaliacao', objetoTemp);
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    
    var _buscaAtos = function () {
        return SQLiteAPIatos.buscaAtos();
    };
    
    var _buscaAtdcOcorrenciaEncerramentos = function () {
        return SQLiteAPIatdcOcorrenciaEncerramento.buscaAtdcOcorrenciaEncerramentos();
    };
    
    var _getAtosStatusFinalizar = function (tipo) {
        return SQLiteAPIatosStatus.getAtosStatusFinalizar(tipo);
    };
    
    
    var _buscaAtosAtividades = function () {
        return SQLiteAPIatosAtividade.buscaAtosAtividades();
    };
    
    var _buscaAtosAtividadeTipo = function () {
        return SQLiteAPIatosAtividadeTipo.buscaAtosAtividadeTipo();
    };
    var _getAtosAtividadeTipo = function () {
        return SQLiteAPIatosAtividadeTipo.getAtosAtividadeTipo();
    };
    
    var _getAtosAtividades = function (atdcOcorrencia) {
        return SQLiteAPIatosAtividade.getAtosAtividades(atdcOcorrencia);
    };
    
    var _getAtosAtividades2 = function (atdcOcorrencia) {
        return SQLiteAPIatosAtividade.getAtosAtividades2(atdcOcorrencia);
    };
    
    var _buscaAtosServicos = function () {
        return SQLiteAPIatosServico.buscaAtosServicos();
    };
        
    var _getAtosServicos = function (atdcOcorrencia) {
        return SQLiteAPIatosServico.getAtosServicos(atdcOcorrencia);
    };
    
    var _getAtosServicos2 = function (atdcOcorrencia) {
        return SQLiteAPIatosServico.getAtosServicos2(atdcOcorrencia);
    };
    
    var _buscaAtosImagens = function () {
        return SQLiteAPIatosImagem.buscaAtosImagens();
    };
    var _getAtosImagens = function (atdcOcorrencia) {
        return SQLiteAPIatosImagem.getAtosImagens(atdcOcorrencia);
    };
    
    var _buscaAtdcOcorrenciaProdutos = function () {
        return SQLiteAPIatdcOcorrenciaProduto.buscaAtdcOcorrenciaProdutos();
    };
    
    var _getAtdcOcorrenciaProdutos = function (atdcOcorrencia) {
        return SQLiteAPIatdcOcorrenciaProduto.getAtdcOcorrenciaProdutos(atdcOcorrencia);
    };
    
    var _getInteracoesOcorrencia = function (atdcOcorrencia) {
        return SQLiteAPIatdcOcorrenciaInteracao.getInteracoesOcorrencia(atdcOcorrencia);
    };
    
    var _getAnexosOcorrencia = function (atdcOcorrencia) {
        return SQLiteAPIatdcOcorrenciaAnexo.getAnexosOcorrencia(atdcOcorrencia);
    };
    
    var _getExpositoresOcorrencia = function (atdcOcorrencia) {
        return SQLiteAPIatdcOcorrenciaExpositor.getExpositoresOcorrencia(atdcOcorrencia);
    };
    
    var _getDocumentacoesProduto = function (produtoCodigo) {
        return SQLiteAPIProdutoAjuda.getDocumentacoesProduto(produtoCodigo);
    };
    
    var _getTiposProduto = function (produtoCodigo) {
        return SQLiteAPIProdutoTipo.getTiposProduto(produtoCodigo);
    };
    
    var _getAtdcOcorrenciaProduto = function (id) {
        return SQLiteAPIatdcOcorrenciaProduto.getAtdcOcorrenciaProduto(id);
    };
    
    
    var _getAtdcOcorrencia = function (atdcOcorrencia) {
        return SQLiteAPIatdcOcorrencia.getAtdcOcorrencia(atdcOcorrencia);
    };
    
    var _getAtdcEndereco = function (atdcEndereco) {
        return SQLiteAPIatdcEndereco.getAtdcEndereco(atdcEndereco);
    };
    
    var _buscaAtendimentos = function () {
        return SQLiteAPIAtendimento.buscaAtendimentos();
    };
    
    var _buscaAtdcOcorrencias = function () {
        return SQLiteAPIatdcOcorrencia.buscaAtdcOcorrencias();
    };
    
    var _enviaAtdcOcorrencias = function (atdc_ocorrencias) {
        return SQLiteAPIatdcOcorrencia.enviaAtdcOcorrencias(atdc_ocorrencias);
    };
    
    var _enviaAtendimentos = function (atdc_ocorrencias) {
        return SQLiteAPIAtendimento.enviaAtendimentos(atdc_ocorrencias);
    };
    
    var _enviaAtos = function (atdc_ocorrencias) {
        return SQLiteAPIAtendimento.enviaAtos(atdc_ocorrencias);
    };
       
    var _buscaAtdcEnderecos = function () {
        return SQLiteAPIatdcEndereco.buscaAtdcEnderecos();
    };
    
    var _getAtendimentos = function (buscaAtendimento) {
        return SQLiteAPIAtendimento.getAtendimentos(buscaAtendimento);
    };
    
    var _realizarCheckin = function (id) {
        return SQLiteAPIAtendimento.realizarCheckin(id);
    };
    
    var _buscaProdutos = function () {
        return SQLiteAPIProduto.buscaProdutos();
    };
    
    var _buscaServicos = function () {
        return SQLiteAPIServico.buscaServicos();
    }; 
    
    var _buscaAt = function () {
        return SQLiteAPIat.buscaAt();
    }; 
    
    var _getAtosStatusAtendimento = function () {
        return SQLiteAPIatosStatus.getAtosStatusAtendimento();
    };
    
    var _limpaTabelas = function () {
        SQLiteAPIGrupo.apagaTabela(),
        SQLiteAPIDefeito.apagaTabela(), 
        SQLiteAPIDefeitoProcedimento.apagaTabela(), 
        SQLiteAPIatdcOcorrenciaProduto.apagaTabela(), 
        SQLiteAPICliente.apagaTabela(), 
        SQLiteAPIAtendimento.apagaTabela(), 
        SQLiteAPIProduto.apagaTabela(), 
        SQLiteAPIServico.apagaTabela(), 
        SQLiteAPIat.apagaTabela(), 
        SQLiteAPIatosStatus.apagaTabela(),
        SQLiteAPIatosAvaliacao.apagaTabela(),
        SQLiteAPIatosAtividade.apagaTabela(), 
        SQLiteAPIatosServico.apagaTabela(), 
        SQLiteAPIatdcOcorrencia.apagaTabela(), 
        SQLiteAPIatdcEndereco.apagaTabela(), 
        SQLiteAPIatosImagem.apagaTabela();
    };
    
    
    var _verificaRegistrosParaAtualizar = function (){
        var defered = $q.defer();
        var promise = defered.promise;
        var registrosAtualizar = {'quantidade' : 0};        
        
        SQLiteAPIatdcOcorrencia.getAtdcOcorrenciasParaSincronizar().then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atdc_ocorrencias = data;
            return SQLiteAPIatdcOcorrenciaEncerramento.getAtdcOcorrenciaEncerramentosParaSincronizar();
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atdc_ocorrencia_encerramentos = data;
            return SQLiteAPIAbstract.getRegistrosParaSincronizar('atdc_ocorrencia_log');
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atdc_ocorrencia_logs = data;
            return SQLiteAPIAbstract.getRegistrosParaSincronizar('atdc_ocorrencia_interacao');
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atdc_ocorrencia_interacoes = data;
//            return SQLiteAPIatosImagem.getAtosImagensParaSincronizar();
            return SQLiteAPIAbstract.getRegistrosParaSincronizar('atos_imagem');
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atos_imagens = data;
//            return SQLiteAPIatosAtividade.getAtosAtividadesParaSincronizar();
            return SQLiteAPIAbstract.getRegistrosParaSincronizar('atos_atividade');
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atos_atividades = data;
            return SQLiteAPIAbstract.getRegistrosParaSincronizar('atos_servico');
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atos_servicos = data;
//            return SQLiteAPIatdcOcorrenciaProduto.getAtdcOcorrenciaProdutosParaSincronizar();
            return SQLiteAPIAbstract.getRegistrosParaSincronizar('atdc_ocorrencia_produto');
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atdc_ocorrencia_produtos = data;
            return SQLiteAPIAtendimento.getAtendimentosParaSincronizar();
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atos_atendimentos = data;
            return SQLiteAPIAbstract.getRegistrosParaSincronizar('itadau_usuario');
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.itadau_usuario = data;
            return SQLiteAPIAbstract.getRegistrosParaSincronizar('itadau_usuario_localizacao');
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.itadau_usuario_localizacao = data;
            return SQLiteAPIatos.getAtosParaSincronizar();
        }).then(function (data) {
            registrosAtualizar.quantidade += data.length;
            registrosAtualizar.atos = data;
            defered.resolve(registrosAtualizar);
        }, function (err) {
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
        
    };
    
    var _buscaRegistros = function (buscaConfiguracoes, buscaProdutos){
        var defered = $q.defer();
        var promise = defered.promise;
        if($rootScope.buscando){
            $rootScope.showAlert("Registros estão sendo sincronizados em segundo plano, favor esperar que termine para buscar novos registros.");
            $rootScope.fecharCarregando();
        }else{
            $rootScope.abrirCarregando('Verificando pendencias a enviar');
            _verificaRegistrosParaAtualizar().then(function (registrosAtualizar) {
    //            console.log(registrosAtualizar);
                var qtde = registrosAtualizar.quantidade - registrosAtualizar.itadau_usuario_localizacao.length;
                if(qtde > 0){
                    $rootScope.fecharCarregando();
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'Registros a enviar',
                        template: 'Existem registros a serem enviados, deseja realmente buscar novos registros?'
                    });
                    confirmPopup.then(function (res) {
                        if (res) {
                            defered.resolve(_atualizar(buscaConfiguracoes, buscaProdutos));
                        }else{
                            $rootScope.fecharCarregando();
                        }
                    });
                }else{
                    defered.resolve(_atualizar(buscaConfiguracoes, buscaProdutos));
                }
            }, function (err) {
                $rootScope.fecharCarregando();
                console.error(err);
                defered.reject(err);
            });
        }
        
        return promise;
        
    };
    var porcentagem = function(valor1, valor2){
        return "Atualizando: "+$filter('number')(parseFloat(valor1/valor2)*100, 2)+'%';
    };
    
    var _atualizar = function (buscaConfiguracoes, buscaProdutos){
        var defered = $q.defer();
        var promise = defered.promise;
        var registrosAtualizar = {'quantidade' : 0};
        var total = buscaConfiguracoes ? 23 : 16;
        if(buscaProdutos){
            total++;
        }
        var concluido = 0;
        
        $rootScope.abrirCarregando(porcentagem(concluido,total));
        SQLiteAPIatdcOcorrencia.buscaAtdcOcorrencias().then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPICliente.buscaClientes();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            if(buscaConfiguracoes){
                concluido++;
                return SQLiteAPIDefeito.buscaDefeitos();
            }
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            if(buscaConfiguracoes){
                concluido++;
                return SQLiteAPIDefeitoProcedimento.buscaDefeitoProcedimentos();
            }
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            if(buscaConfiguracoes){
                concluido++;
                return SQLiteAPIGrupo.buscaGrupos();
            }
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            if(buscaProdutos){
                concluido++;
                return SQLiteAPIProduto.buscaProdutos();
            }
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIServico.buscaServicos();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIat.buscaAt();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatdcEndereco.buscaAtdcEnderecos();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            if(buscaConfiguracoes){
                concluido++;
                return SQLiteAPIatosAtividadeTipo.buscaAtosAtividadeTipo();
            }
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            if(buscaConfiguracoes){
                concluido++;
                return SQLiteAPIatosStatus.buscaAtosStatus();
            }
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            if(buscaConfiguracoes){
                concluido++;
                return SQLiteAPIatosAvaliacao.buscaAtosAvaliacao();
            }
//        }).then(function (data) {
//            $rootScope.abrirCarregando(porcentagem(concluido,total));
//            concluido++;
//            return SQLiteAPIitadauUsuarioLocalizacao.busca;
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatdcOcorrenciaLog.buscaAtdcOcorrenciaLogs();
        }).then(function (data) {
            concluido++;
            return SQLiteAPIatdcOcorrenciaInteracao.buscaAtdcOcorrenciaInteracoes();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatdcOcorrenciaAnexo.buscaAtdcOcorrenciaAnexos();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatdcOcorrenciaExpositor.buscaAtdcOcorrenciaExpositores();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIProdutoAjuda.buscaProdutoDocumentacoes();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatdcOcorrenciaEncerramento.buscaAtdcOcorrenciaEncerramentos();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            if(buscaConfiguracoes){
                concluido++;
                return SQLiteAPIProdutoTipo.buscaProdutoTipos();
            }
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatosImagem.buscaAtosImagens();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatosAtividade.buscaAtosAtividades();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatosServico.buscaAtosServicos();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIAtendimento.buscaAtendimentos();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
//            console.log('atendimentos');
//            console.log(data);
            return SQLiteAPIatdcOcorrenciaProduto.buscaAtdcOcorrenciaProdutos();
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatos.buscaAtos();
        }).then(function (data) {
//            concluido++;
            $rootScope.fecharCarregando();
            $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
            $window.localStorage['ultimaAtualizacao'] = new Date();
            defered.resolve(registrosAtualizar);
        }, function (err) {
            $rootScope.fecharCarregando();
//            console.error(err);
            $rootScope.geraLog(err, new Error());
            $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
            defered.reject(err);
        });
        
        return promise;
        
    };
    
    var _buscaRegistrosBackground = function (){
        var defered = $q.defer();
        var promise = defered.promise;
//        _verificaRegistrosParaAtualizar().then(function (registrosAtualizar) {
//            var qtde = registrosAtualizar.quantidade - registrosAtualizar.itadau_usuario_localizacao.length;
//            if(qtde > 0){
//                defered.reject("Existem registros a serem enviados...");
//            }else{
                defered.resolve(_atualizarBackground());
//            }
//        }, function (err) {
//            $rootScope.fecharCarregando();
//            console.error(err);
//            defered.reject(err);
//        });
        
        return promise;
        
    };
    var porcentagemBackground = function(valor1, valor2){
        return $filter('number')(parseFloat(valor1/valor2)*100, 2)+'%';
    };
    
    var _verificaConsulta = function(){
        var hoje = new Date();
        var retornoConsulta = {'qtde' : 0};
        var validoAte;
        
        validoAte = new Date($window.localStorage['defeitoValido']);
        retornoConsulta.defeitoValido = !(validoAte instanceof Date) || hoje >= validoAte || $window.localStorage['defeitoValido'] == null;

        validoAte = new Date($window.localStorage['defeitoProcedimentoValido']);
        retornoConsulta.defeitoProcedimentoValido = !(validoAte instanceof Date) || hoje >= validoAte || $window.localStorage['defeitoProcedimentoValido'] == null;

        validoAte = new Date($window.localStorage['grupoDefeitoValido']);
        retornoConsulta.grupoDefeitoValido = !(validoAte instanceof Date) || hoje >= validoAte || $window.localStorage['grupoDefeitoValido'] == null;            

        validoAte = new Date($window.localStorage['produtoValido']);
        retornoConsulta.produtoValido = !(validoAte instanceof Date) || hoje >= validoAte || $window.localStorage['produtoValido'] == null;

        validoAte = new Date($window.localStorage['produtoTipoValido']);
        retornoConsulta.produtoTipoValido = !(validoAte instanceof Date) || hoje >= validoAte || $window.localStorage['produtoTipoValido'] == null;

        validoAte = new Date($window.localStorage['servicoValido']);
        retornoConsulta.servicoValido = !(validoAte instanceof Date) || hoje >= validoAte || $window.localStorage['servicoValido'] == null;

//        validoAte = new Date($window.localStorage['atValido']);
//        retornoConsulta.atValido = !(validoAte instanceof Date) || hoje >= validoAte || $window.localStorage['atValido'] == null;

        validoAte = new Date($window.localStorage['atosAtividadeTipoValido']);
        retornoConsulta.atosAtividadeTipoValido = !(validoAte instanceof Date) || hoje >= validoAte || $window.localStorage['atosAtividadeTipoValido'] == null;

        validoAte = new Date($window.localStorage['atosStatusValido']);
        retornoConsulta.atosStatusValido = true;        

        validoAte = new Date($window.localStorage['atosAvaliacaoValido']);
        retornoConsulta.atosAvaliacaoValido = true;
        
        angular.forEach(retornoConsulta, function (value,index){
            if(value){
                retornoConsulta.qtde++;
            }
        });
            
        return retornoConsulta;
        
    };
    
    var arrayVerificaValidade = ['defeito','defeitoProcedimento','grupoDefeito','produto','produtoTipo','servico','atosAtividadeTipo','atosStatus','atosAvaliacao'];
    
    var _verificaBusca = function (tipo, consulta){
        var hoje = new Date();
                
        if(arrayVerificaValidade.indexOf(tipo)){
            if((tipo+'Valido') in consulta){
                if(consulta[tipo+'Valido']){
    //                return true;
                }else{
//                    console.log(tipo+' dados válidos!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
                    return false;
                }
            }
        }
        
        var BloqueioAte = new Date($window.localStorage[tipo+'BloqueioAte']);
        if(!(BloqueioAte instanceof Date) || hoje >= BloqueioAte || $window.localStorage[tipo+'BloqueioAte'] == null){
//            console.log(tipo+' Consulta');
//            return true;
        }else{
            console.log(tipo+' periodo bloqueado!!!!!!!!!!!!!!');
            return false;
        }
        return true;

        
    };
    
    
    var _atualizarBackground = function (){
        var defered = $q.defer();
        var promise = defered.promise;
        var registrosAtualizar = {'quantidade' : 0};
        var concluido = 0;
        var consulta = _verificaConsulta();
        var total = 17 + consulta.qtde;
        $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
        var ultimaAtualizacao = $window.localStorage['ultimaAtualizacao'];
        
        if(!_verificaBusca('atdcOcorrencia', consulta)){
            defered.reject('Dados enviados recentemente(atdcOcorrencia)');
            return promise;
        }
        
        SQLiteAPIatdcOcorrencia.buscaAtdcOcorrencias(ultimaAtualizacao).then(function (data) {
            if(_verificaBusca('cliente', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPICliente.buscaClientes(ultimaAtualizacao);                
            }
        }).then(function (data) {
            if(_verificaBusca('defeito', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIDefeito.buscaDefeitos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('defeitoProcedimento', consulta)){ 
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIDefeitoProcedimento.buscaDefeitoProcedimentos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('grupoDefeito', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIGrupo.buscaGrupos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('produto', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIProduto.buscaProdutos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('servico', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIServico.buscaServicos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('at', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIat.buscaAt(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atdcEndereco', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatdcEndereco.buscaAtdcEnderecos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atosAtividadeTipo', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatosAtividadeTipo.buscaAtosAtividadeTipo(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atosStatus', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatosStatus.buscaAtosStatus(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atosAvaliacao', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatosAvaliacao.buscaAtosAvaliacao(ultimaAtualizacao);
            }
//        }).then(function (data) {
//            concluido++;
//            return SQLiteAPIitadauUsuarioLocalizacao.busca;
        }).then(function (data) {
            if(_verificaBusca('atdcOcorrenciaLog', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatdcOcorrenciaLog.buscaAtdcOcorrenciaLogs(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atdcOcorrenciaEncerramento', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatdcOcorrenciaEncerramento.buscaAtdcOcorrenciaEncerramentos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atosImagem', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatosImagem.buscaAtosImagens(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atosAtividade', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatosAtividade.buscaAtosAtividades(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atosServico', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatosServico.buscaAtosServicos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atdcOcorrenciaProduto', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatdcOcorrenciaProduto.buscaAtdcOcorrenciaProdutos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atendimento', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIAtendimento.buscaAtendimentos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atdcOcorrenciaInteracao', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatdcOcorrenciaInteracao.buscaAtdcOcorrenciaInteracoes(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atdcOcorrenciaAnexo', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatdcOcorrenciaAnexo.buscaAtdcOcorrenciaAnexos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atdcOcorrenciaExpositor', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatdcOcorrenciaExpositor.buscaAtdcOcorrenciaExpositores(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('produtoAjuda', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIProdutoAjuda.buscaProdutoDocumentacoes(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('produtoTipo', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIProdutoTipo.buscaProdutoTipos(ultimaAtualizacao);
            }
        }).then(function (data) {
            if(_verificaBusca('atos', consulta)){
                concluido++;
                $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
                return SQLiteAPIatos.buscaAtos(ultimaAtualizacao);
            }
        }).then(function (data) {
            concluido++;
            $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
            registrosAtualizar.quantidade = concluido;
            $rootScope.fecharCarregando();
            $window.localStorage['ultimaAtualizacao'] = new Date();
            defered.resolve(registrosAtualizar);
        }, function (err) {
            $rootScope.porcentagemConcluido = porcentagemBackground(concluido,total);
            $rootScope.fecharCarregando();
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
        
    };
    
    var _limparSincronizados = function (){
        var defered = $q.defer();
        var promise = defered.promise;
        
        SQLiteAPIAbstract.resetarTabela('atdc_ocorrencia').then(function () {
            $window.localStorage['ultimaAtualizacao'] = null;
            return SQLiteAPIAbstract.resetarTabela('atdc');
//        }).then(function () {
////        return SQLiteAPIDefeito.apagaTabela();
//        }).then(function () {
////        return SQLiteAPIDefeitoProcedimento.apagaTabela();
//        }).then(function () {
////        return SQLiteAPIGrupo.apagaTabela();
//        }).then(function () {
////        return SQLiteAPIProduto.apagaTabela();
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atdc_endereco');
//        }).then(function () {
////        return SQLiteAPIatosAtividadeTipo.apagaTabela();
//        }).then(function () {
////        return SQLiteAPIatosStatus.apagaTabela();
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('itadau_usuario_localizacao');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atdc_ocorrencia_log');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atdc_ocorrencia_encerramento');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atos_imagem');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atos_atividade');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atos_servico');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atdc_ocorrencia_produto');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atos_atendimento');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atos');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atdc_ocorrencia_interacao');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atdc_ocorrencia_anexo');
        }).then(function () {
            return SQLiteAPIAbstract.resetarTabela('atdc_ocorrencia_expositor');
//        }).then(function () {
////            return SQLiteAPIAbstract.resetarTabela('atdb_produto_ajuda');
        }).then(function () {
            defered.resolve('OK');
        }, function (err) {
            $rootScope.fecharCarregando();
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
        
    };
    
    var _resetarTabelas = function (){
        var defered = $q.defer();
        var promise = defered.promise;
        
        SQLiteAPIatdcOcorrencia.apagaTabela().then(function () {
            $window.localStorage['ultimaAtualizacao'] = null;
            return SQLiteAPICliente.apagaTabela();
//        }).then(function () {
//        return SQLiteAPIDefeito.apagaTabela();
//        }).then(function () {
//        return SQLiteAPIDefeitoProcedimento.apagaTabela();
//        }).then(function () {
//        return SQLiteAPIGrupo.apagaTabela();
//        }).then(function () {
//        return SQLiteAPIProduto.apagaTabela();
        }).then(function () {
            return SQLiteAPIatdcEndereco.apagaTabela();
//        }).then(function () {
//        return SQLiteAPIatosAtividadeTipo.apagaTabela();
//        }).then(function () {
//        return SQLiteAPIatosStatus.apagaTabela();
        }).then(function () {
            return SQLiteAPIitadauUsuarioLocalizacao.apagaTabela();
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaLog.apagaTabela();
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaEncerramento.apagaTabela();
        }).then(function () {
            return SQLiteAPIatosImagem.apagaTabela();
        }).then(function () {
            return SQLiteAPIatosAtividade.apagaTabela();
        }).then(function () {
            return SQLiteAPIatosServico.apagaTabela();
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaProduto.apagaTabela();
        }).then(function () {
            return SQLiteAPIAtendimento.apagaTabela();
        }).then(function () {
            return SQLiteAPIatos.apagaTabela();
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaInteracao.apagaTabela();
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaAnexo.apagaTabela();
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaExpositor.apagaTabela();
        }).then(function () {
            return SQLiteAPIProdutoAjuda.apagaTabela();
        }).then(function () {
            return SQLiteAPIProdutoTipo.apagaTabela();
        }).then(function () {
            defered.resolve('OK');
        }, function (err) {
            $rootScope.fecharCarregando();
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
        
    };
    
    
    var _excluiAntigos = function (dias){
        var defered = $q.defer();
        var promise = defered.promise;
        if(dias === undefined){
            dias = 30;
        }
        $rootScope.excluindoAntigos = true;
        
        SQLiteAPIatdcOcorrenciaLog.excluiAntigos(dias).then(function () {
//            $window.localStorage['ultimaAtualizacao'] = null;
            return SQLiteAPIatdcOcorrenciaEncerramento.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIatosImagem.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIatosAtividade.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIatosServico.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaProduto.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaInteracao.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaAnexo.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIatdcOcorrenciaExpositor.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIAtendimento.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIatdcOcorrencia.excluiAntigos(dias);
        }).then(function () {
            return SQLiteAPIatos.excluiAntigos(dias);
        }).then(function () {
//            return SQLiteAPIProdutoAjuda.excluiAntigos(dias);
//        }).then(function () {
            console.log('terminou exclusão antigos');
            $rootScope.excluindoAntigos = false;
            
            $timeout(function() {
                _excluiAntigos(dias);
            }, 86400000);
            defered.resolve('OK');
        }, function (err) {
            $rootScope.excluindoAntigos = false;
            $rootScope.fecharCarregando();
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
        
    };
    
    var _iniciaTabelas = function (){
        SQLiteAPIatdcOcorrencia.iniciaTabela();
        SQLiteAPICliente.iniciaTabela();
//        SQLiteAPIDefeito.iniciaTabela();
//        SQLiteAPIDefeitoProcedimento.iniciaTabela();
//        SQLiteAPIGrupo.iniciaTabela();
//        SQLiteAPIProduto.iniciaTabela();
        SQLiteAPIatdcEndereco.iniciaTabela();
//        SQLiteAPIatosAtividadeTipo.iniciaTabela();
//        SQLiteAPIatosStatus.iniciaTabela();
        SQLiteAPIitadauUsuario.iniciaTabela();
        SQLiteAPIitadauUsuarioLocalizacao.iniciaTabela();
        SQLiteAPIatdcOcorrenciaLog.iniciaTabela();
        SQLiteAPIatdcOcorrenciaEncerramento.iniciaTabela();
        SQLiteAPIatosImagem.iniciaTabela();
        SQLiteAPIatosAtividade.iniciaTabela();
        SQLiteAPIatosServico.iniciaTabela();
        SQLiteAPIatdcOcorrenciaProduto.iniciaTabela();
        SQLiteAPIAtendimento.iniciaTabela();
        SQLiteAPIatos.iniciaTabela();
        SQLiteAPIatdcOcorrenciaInteracao.iniciaTabela();
        SQLiteAPIatdcOcorrenciaAnexo.iniciaTabela();
        SQLiteAPIatdcOcorrenciaExpositor.iniciaTabela();
        SQLiteAPIProdutoAjuda.iniciaTabela();
        SQLiteAPIProdutoTipo.iniciaTabela();
        
    };
    
    return {
        excluiAntigos: _excluiAntigos,
        iniciaTabelas: _iniciaTabelas,
        resetarTabelas: _resetarTabelas,
        buscaRegistrosBackground: _buscaRegistrosBackground,
        buscaRegistros: _buscaRegistros,
        getAtosAtividadeTipo: _getAtosAtividadeTipo,
        buscaAtosAtividadeTipo: _buscaAtosAtividadeTipo,
        enviaAtendimentos: _enviaAtendimentos,
        enviaAtos: _enviaAtos,
        enviaAtdcOcorrencias: _enviaAtdcOcorrencias,
        verificaRegistrosParaAtualizar: _verificaRegistrosParaAtualizar,
        deleteGrupoDefeitos: _deleteGrupoDefeitos,
        getGrupoDefeitos: _getGrupoDefeitos,
        setGrupoDefeitos: _setGrupoDefeitos,
        
        buscaAtdcOcorrenciaEncerramentos: _buscaAtdcOcorrenciaEncerramentos,
        buscaDefeitoProcedimentos: _buscaDefeitoProcedimentos,
        buscaAtosStatus: _buscaAtosStatus,
        buscaAtosAvaliacao: _buscaAtosAvaliacao,
        carregaOpcoesAvaliacao: _carregaOpcoesAvaliacao,
        buscaAtos: _buscaAtos,
        getAtosStatusFinalizar: _getAtosStatusFinalizar,
        buscaAtosAtividades: _buscaAtosAtividades,
        buscaAtosServicos: _buscaAtosServicos,
        buscaAtosImagens: _buscaAtosImagens,
        getAtosImagens: _getAtosImagens,
        buscaAtdcOcorrenciaProdutos: _buscaAtdcOcorrenciaProdutos,
        getInteracoesOcorrencia: _getInteracoesOcorrencia,
        getAnexosOcorrencia: _getAnexosOcorrencia,
        getExpositoresOcorrencia: _getExpositoresOcorrencia,
        getDocumentacoesProduto: _getDocumentacoesProduto,
        getTiposProduto: _getTiposProduto,
        getAtdcOcorrenciaProdutos: _getAtdcOcorrenciaProdutos,
        getAtdcOcorrenciaProduto: _getAtdcOcorrenciaProduto,
        getAtosAtividades: _getAtosAtividades,
        getAtosAtividades2: _getAtosAtividades2,
        getAtosServicos: _getAtosServicos,
        getAtosServicos2: _getAtosServicos2,
        getAtdcOcorrencia: _getAtdcOcorrencia,
        getAtdcEndereco: _getAtdcEndereco,
        buscaGrupoDefeitos: _buscaGrupoDefeitos,
        buscaAtendimentos: _buscaAtendimentos,
        buscaAtdcOcorrencias: _buscaAtdcOcorrencias,
        buscaAtdcEnderecos: _buscaAtdcEnderecos,
        buscaProdutos: _buscaProdutos,
        buscaServicos: _buscaServicos,
        buscaAt: _buscaAt,
        getAtosStatusAtendimento: _getAtosStatusAtendimento,
        deleteDefeitos: _deleteDefeitos,
        buscaDefeitos: _buscaDefeitos,
        buscaClientes: _buscaClientes,
        getCliente: _getCliente,
        getClienteEndereco: _getClienteEndereco,
        getDefeitos: _getDefeitos,
        setDefeitos: _setDefeitos,
//        
//        deleteDefeitoProcedimentos: _deleteDefeitoProcedimentos,
        getDefeitoProcedimentos: _getDefeitoProcedimentos,
//        setDefeitoProcedimentos: _setDefeitoProcedimentos,
        
        
        deleteAtendimentos: _deleteAtendimentos,
        getAtendimentos: _getAtendimentos,
        realizarCheckin: _realizarCheckin,
        setAtendimentos: _setAtendimentos,
        limparSincronizados: _limparSincronizados,
        limpaTabelas: _limpaTabelas
    };
});