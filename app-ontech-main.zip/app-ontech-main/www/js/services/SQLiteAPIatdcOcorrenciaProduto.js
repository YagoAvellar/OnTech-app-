angular.module("starter").factory("SQLiteAPIatdcOcorrenciaProduto", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    SQLiteAPIAbstract, SQLiteAPIDefeito, SQLiteAPIatdcOcorrenciaLog, SQLiteAPIatosAtividade, SQLiteAPIatosServico, SQLiteAPIProdutoAjuda) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_produto").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () { 
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_produto"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_ocorrencia_produto \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atdcOcorrencia integer, \n\
            atdcGrupoDefeito integer, \n\
            atdcGrupoDefeitoProcedimento integer, \n\
            tipo text, \n\
            linha text, \n\
            familia text, \n\
            codigo text, \n\
            descricaoErp text, \n\
            descricao text, \n\
            notaFiscal text, \n\
            dataCompra datetime, \n\
            loja text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            excluido integer, \n\
            sincronizado integer)");
    };
        
    var _buscaAtdcOcorrenciaProdutos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_ocorrencia_produto', data);
    };
    
    var _getAtdcOcorrenciaProdutos = function (atdcOcorrencia) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
//        console.log(atdcOcorrencia);
        var query = "SELECT * FROM atdc_ocorrencia_produto";
        if(atdcOcorrencia !== undefined && atdcOcorrencia > 0){
            query += " WHERE atdcOcorrencia = "+atdcOcorrencia+" AND (excluido IS NULL OR excluido <> 1) ";
        }
        
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            if(consulta.rows.length > 0){
                for (var i = 0; i < consulta.rows.length; i++) {
                    var row = consulta.rows.item(i);
                    _retornaObjetoCompleto(row).then(function(data){
                        retorno[data.id] = data; 
                        if(consulta.rows.length <= i+1 ){
                            defered.resolve(retorno);
                        }
                    }, function(err){
                        console.error(err); 
                        defered.reject(err);
                    });
                }
            }else{
                defered.resolve(retorno);
            }
        }, function(err){
            defered.reject(err);
        });
        return promise;
        
    };
    
    var _retornaObjetoCompleto = function (atdcOcorrenciaProduto) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = atdcOcorrenciaProduto;
        SQLiteAPIDefeito.getDefeito(atdcOcorrenciaProduto.atdcGrupoDefeito).then(function(data){
            retorno.atdcGrupoDefeito = data;
            return SQLiteAPIAbstract.find(atdcOcorrenciaProduto.atdcGrupoDefeitoProcedimento,'atdc_grupo_defeito_procedimento')
        }).then(function(data){
            retorno.atdcGrupoDefeitoProcedimento = data;
            return SQLiteAPIProdutoAjuda.getDocumentacoesProduto(atdcOcorrenciaProduto.codigo)
        }).then(function(data){
            retorno.atdcProdutoAjuda = data;
            defered.resolve(retorno);
        }, function(err){
//            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    
    var _getAtdcOcorrenciaProduto = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_produto WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteAtdcOcorrenciaProdutos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_ocorrencia_produto";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtdcOcorrenciaProdutos = function (atdcOcorrenciaProdutos) {
        _iniciaTabela();
////        _deleteAtdcOcorrenciaProdutos();
//        var query = "INSERT INTO atdc_ocorrencia_produto ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        atdcOcorrencia, \n\
//                        atdcGrupoDefeito, \n\
//                        atdcGrupoDefeitoProcedimento, \n\
//                        tipo, \n\
//                        linha, \n\
//                        familia, \n\
//                        codigo, \n\
//                        descricaoErp, \n\
//                        descricao, \n\
//                        notaFiscal, \n\
//                        dataCompra, \n\
//                        loja,\n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
//        angular.forEach(atdcOcorrenciaProdutos, function (atdcOcorrenciaProduto,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atdcOcorrenciaProduto.id,
//                atdcOcorrenciaProduto.id,
//                atdcOcorrenciaProduto.atdcOcorrencia,
//                atdcOcorrenciaProduto.atdcGrupoDefeito,
//                atdcOcorrenciaProduto.atdcGrupoDefeitoProcedimento,
//                atdcOcorrenciaProduto.tipo,
//                atdcOcorrenciaProduto.linha,
//                atdcOcorrenciaProduto.familia,
//                atdcOcorrenciaProduto.codigo,
//                atdcOcorrenciaProduto.descricaoErp,
//                atdcOcorrenciaProduto.descricao,
//                atdcOcorrenciaProduto.notaFiscal,
//                $rootScope.trataDataNull(atdcOcorrenciaProduto.dataCompra),
//                atdcOcorrenciaProduto.loja,
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAtdcOcorrenciaProdutos2(atdcOcorrenciaProdutos, 0, 'atdc_ocorrencia_produto').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atdcOcorrenciaProdutoValido'] = new Date(valido);
            $window.localStorage['atdcOcorrenciaProdutoAtualizado'] = new Date();
            $window.localStorage['atdcOcorrenciaProdutoQtde'] = Object.keys(atdcOcorrenciaProdutos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    
    var _setAtdcOcorrenciaProdutos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
    //        delete registro.status;
    //        delete registro.abertura;
    //        delete registro.encerramento;
    //        delete registro.distancia;
    //        registro.dataAgendamento = $rootScope.trataDataNull(registro.dataAgendamento);
    //        registro.dataInicio = $rootScope.trataDataNull(registro.dataInicio);
    //        registro.dataFim = $rootScope.trataDataNull(registro.dataFim);

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAtdcOcorrenciaProdutos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    var _atualizaAtdcOcorrenciaProduto = function (id, atdcOcorrenciaProduto) {
        var defered = $q.defer();
        var promise = defered.promise;
        
        var dtAlteracao = new Date();
        var dataAlteracao = $rootScope.converteObjetoDataPost(dtAlteracao);
        
        var dtCompra = new Date(atdcOcorrenciaProduto.dataCompra);
        var dataCompra = $rootScope.converteObjetoDataPost(dtCompra);
        
        var atdcOcorrencia = {
            'atdcOcorrencia'    : atdcOcorrenciaProduto.atdcOcorrencia,
            'atdcGrupoDefeito'  : (atdcOcorrenciaProduto.atdcGrupoDefeito !== null) ? atdcOcorrenciaProduto.atdcGrupoDefeito.id : null,
            'atdcGrupoDefeitoProcedimento'  : (atdcOcorrenciaProduto.atdcGrupoDefeitoProcedimento !== undefined && atdcOcorrenciaProduto.atdcGrupoDefeitoProcedimento !== null) ? atdcOcorrenciaProduto.atdcGrupoDefeitoProcedimento.id : null,
            'tipo'          : atdcOcorrenciaProduto.tipo,
            'linha'         : atdcOcorrenciaProduto.linha,
            'familia'       : atdcOcorrenciaProduto.familia,
            'codigo'        : atdcOcorrenciaProduto.codigo,
            'descricaoErp'  : atdcOcorrenciaProduto.descricaoErp,
            'descricao'     : atdcOcorrenciaProduto.descricao,
            'notaFiscal'    : atdcOcorrenciaProduto.notaFiscal,
            'dataCompra'    : dataCompra,
            'loja'          : atdcOcorrenciaProduto.loja,
            'dataAlteracao' : dataAlteracao,
            'sincronizado'  : 0
        };
            
        console.log(atdcOcorrenciaProduto);
        
        var retUpdate;
        SQLiteAPIAbstract.update('atdc_ocorrencia_produto', id, atdcOcorrencia).then(function(data){
            retUpdate = data;
//            return _logProduto(atdcOcorrenciaProduto,'editProduto');
        }).then(function(){
            return _retornaObjetoCompleto(retUpdate);
        }).then(function(completo){
            defered.resolve(completo);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    
    var _adicionaAtdcOcorrenciaProduto = function (atdcOcorrenciaProduto) {
        var defered = $q.defer();
        var promise = defered.promise;
        
        var dtAlteracao = new Date();
        var dataAlteracao = $rootScope.converteObjetoDataPost(dtAlteracao);
        
        var dtCompra = new Date(atdcOcorrenciaProduto.dataCompra);
        var dataCompra = $rootScope.converteObjetoDataPost(dtCompra);
        
        var retInsert;
        
        var atdcOcorrencia = {
            'atdcOcorrencia'    : atdcOcorrenciaProduto.atdcOcorrencia,
            'atdcGrupoDefeito'  : atdcOcorrenciaProduto.atdcGrupoDefeito.id,
            'atdcGrupoDefeitoProcedimento'  : atdcOcorrenciaProduto.atdcGrupoDefeitoProcedimento.id,
            'tipo'          : atdcOcorrenciaProduto.tipo,
            'linha'         : atdcOcorrenciaProduto.linha,
            'familia'       : atdcOcorrenciaProduto.familia,
            'codigo'        : atdcOcorrenciaProduto.codigo,
            'descricaoErp'  : atdcOcorrenciaProduto.descricaoErp,
            'descricao'     : atdcOcorrenciaProduto.descricao,
            'notaFiscal'    : atdcOcorrenciaProduto.notaFiscal,
            'dataCompra'    : dataCompra,
            'loja'          : atdcOcorrenciaProduto.loja,
            'dataAlteracao' : dataAlteracao,
            'sincronizado'  : 0
        };
            
        console.log(atdcOcorrenciaProduto);
        SQLiteAPIAbstract.insert('atdc_ocorrencia_produto', atdcOcorrencia).then(function(data){
            retInsert = data;
            return _logProduto(atdcOcorrenciaProduto,'addProduto');
        }).then(function(){
            return _retornaObjetoCompleto(retInsert);
        }).then(function(completo){
            defered.resolve(completo);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    
    
    var _logProduto = function (atdcOcorrenciaProduto,tipo) {
        var defered = $q.defer();
        var promise = defered.promise;
        var informacao = '';
        
        if(tipo === 'addProduto'){
            informacao = 'Foi incluído o produto <b>'+_getNomeProduto(atdcOcorrenciaProduto)+'</b> a ocorrência.';
        }
        if(tipo === 'editProduto'){
            informacao = 'Foi alterado o produto <b>'+_getNomeProduto(atdcOcorrenciaProduto)+'</b> da ocorrência.';
        }
        if(tipo === 'remProduto'){
            informacao = 'Foi excluído o produto <b>'+_getNomeProduto(atdcOcorrenciaProduto)+'</b> da ocorrência.';
        }
        
        SQLiteAPIatdcOcorrenciaLog.add(atdcOcorrenciaProduto.atdcOcorrencia,tipo, informacao).then(function(retorno){
            defered.resolve(retorno);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    
    var _getNomeProduto = function (atdcOcorrenciaProduto){
        return atdcOcorrenciaProduto.descricaoErp;
    };
    
    var _deleteAtosAtividades = function (ocorrenciaProduto) {
        var defered = $q.defer();
        var promise = defered.promise;
        
        var query = "SELECT * FROM atos_atividade";
        if(ocorrenciaProduto != undefined){
            query+= " WHERE atdcOcorrenciaProduto = "+ocorrenciaProduto+" AND (excluido IS NULL OR excluido <> 1) ";
        }
        var atividades = []; 
        $cordovaSQLite.execute($rootScope.db, query).then(function(atosAtividades){
            for (var i = 0; i < atosAtividades.rows.length; i++) {
                var row = atosAtividades.rows.item(i);
                atividades.push(row); 
            }
            if(atividades.length > 0){
                console.log('atividades');
                console.log(atividades);
                SQLiteAPIAbstract.deleteGroup('atos_atividade', atividades).then(function(){
                    defered.resolve(atividades);
                }, function(err){
                    console.error(err);
                    defered.reject(err);
                });                
            }else{
                defered.resolve([]);
            }
        }).then(function(){
            defered.resolve(atividades);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    
//    var _deleteAtosAtividades = function (ocorrenciaProduto) {
//        console.log(ocorrenciaProduto);
//        var defered = $q.defer();
//        var promise = defered.promise;
//        
//        var dtAlteracao = new Date();
//        var dataAlteracao = $rootScope.converteObjetoDataPost(dtAlteracao);
//        
//        var query = "UPDATE atos_atividade SET excluido = 1, sincronizado = 0, dataAlteracao = '"+dataAlteracao+"' ";
//        if(ocorrenciaProduto != undefined){
//            query+= " WHERE atdcOcorrenciaProduto = "+ocorrenciaProduto+" AND (excluido IS NULL OR excluido <> 1) ";
//        }
//        $cordovaSQLite.execute($rootScope.db, query).then(function(atosAtividades){
//            defered.resolve("OK");
//        }, function(err){
//            console.error(err);
//            defered.reject(err);
//        });
//        return promise;
//    };
    
    var _deleteProduto = function (ocorrenciaProduto) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        console.log('teste');
        console.log('teste2');
        
        _deleteAtosAtividades(ocorrenciaProduto.id).then(function (data) {
            console.log('atividadesExcluidas');
            console.log(data);
            retorno['atividades'] = data;
            return SQLiteAPIAbstract.delete('atdc_ocorrencia_produto', ocorrenciaProduto.id);
        }).then(function (produto) {
            console.log('produto');
            console.log(produto);
            retorno['produto'] = produto;
            return _logProduto(ocorrenciaProduto,'remProduto');
        }).then(function (produto) {
            $rootScope.fecharCarregando();
            defered.resolve(retorno);
        }, function (err) {
            console.log('teste4');
            $rootScope.fecharCarregando();
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    
    
    var _enviaAtdcOcorrenciaProdutos = function (registrosSincronizar) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {'atividade' : [], 'servico' : []};
        SQLiteAPIAbstract.enviaRegistros(registrosSincronizar,'atdc_ocorrencia_produto').then(function (data) {
            var atualizaProduto = [];
            angular.forEach(data, function (ocorrenciaProduto,index){
                if(ocorrenciaProduto.id != ocorrenciaProduto.idApp){
                    atualizaProduto.push({'de':ocorrenciaProduto.idApp,'para':ocorrenciaProduto.id,'atdcOcorrencia':ocorrenciaProduto.atdcOcorrencia});
                }
            });
            if(atualizaProduto.length > 0){
                SQLiteAPIatosAtividade.atualizaProdutoAtividade(atualizaProduto,0).then(function (data) {
                    return SQLiteAPIatosServico.atualizaProdutoServico(atualizaProduto,0);
                }).then(function () {
                    return SQLiteAPIAbstract.getRegistrosParaSincronizar('atos_atividade');
                }).then(function (atos_atividade) {
                    retorno.atividade = atos_atividade;
                    return SQLiteAPIAbstract.getRegistrosParaSincronizar('atos_servico');
                }).then(function (atos_servico) {
                    retorno.servico = atos_servico;
                    defered.resolve(retorno);
                }, function (err) {
                    defered.reject(err);
                });
            }else{
                defered.resolve(retorno);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _excluiAntigos = function (dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT a.id FROM atdc_ocorrencia_produto a \n\
                     JOIN atdc_ocorrencia b ON  b.id = a.atdcOcorrencia \n\
                     JOIN atos c ON  c.atdcOcorrencia = b.id \n\
                     ";
        query+= " WHERE b.atdcStatus = 6 \n\
                  AND c.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        
        query = "DELETE FROM atdc_ocorrencia_produto WHERE id IN ( "+query+" )";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    
    return {
//        getAtosAtividades: _getAtosAtividades,
        enviaAtdcOcorrenciaProdutos: _enviaAtdcOcorrenciaProdutos,
        deleteProduto: _deleteProduto,
        adicionaAtdcOcorrenciaProduto: _adicionaAtdcOcorrenciaProduto,
        atualizaAtdcOcorrenciaProduto: _atualizaAtdcOcorrenciaProduto,
        deleteAtdcOcorrenciaProdutos: _deleteAtdcOcorrenciaProdutos,
        buscaAtdcOcorrenciaProdutos: _buscaAtdcOcorrenciaProdutos,
        getAtdcOcorrenciaProdutos: _getAtdcOcorrenciaProdutos,
        getAtdcOcorrenciaProduto: _getAtdcOcorrenciaProduto,
        setAtdcOcorrenciaProdutos: _setAtdcOcorrenciaProdutos,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});