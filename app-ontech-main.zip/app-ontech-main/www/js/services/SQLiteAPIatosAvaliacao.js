angular.module("starter").factory("SQLiteAPIatosAvaliacao", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    SQLiteAPIAbstract, $ionicPlatform) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_avaliacao").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_avaliacao"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atos_avaliacao \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            descricao text, \n\
            imagem BLOB, \n\
            dataAlteracao DATETIME)");
    };
    
    var _buscaAtosAvaliacao = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atos_avaliacao', data);
    };
    var _getAtosAvaliacao = function () {
        _iniciaTabela();
        var query = "SELECT * FROM atos_avaliacao";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _deleteAtosAvaliacao = function () {
        _iniciaTabela();
        var query = "DELETE FROM atos_avaliacao";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtosAvaliacao = function (atosAvaliacao) {
        _iniciaTabela();
        _setAtosAvaliacao2(atosAvaliacao, 0, 'atos_avaliacao').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 15);
            $window.localStorage['atosAvaliacaoValido'] = new Date(valido);
            $window.localStorage['atosAvaliacaoAtualizado'] = new Date();
            $window.localStorage['atosAvaliacaoQtde'] = Object.keys(atosAvaliacao).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setAtosAvaliacao2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.at;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
    //                
            //caso id inserido na API for diferente do aplicativo
            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAtosAvaliacao2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    return {
        deleteAtosAvaliacao: _deleteAtosAvaliacao,
        buscaAtosAvaliacao: _buscaAtosAvaliacao,
        getAtosAvaliacao: _getAtosAvaliacao,
        setAtosAvaliacao: _setAtosAvaliacao,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});