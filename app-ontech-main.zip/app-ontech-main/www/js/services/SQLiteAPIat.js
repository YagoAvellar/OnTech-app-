angular.module("starter").factory("SQLiteAPIat", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    atosStatusAPI, SQLiteAPIAbstract, $ionicPlatform) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE at").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE at"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS at \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            nome text, \n\
            permitirAssinaturaOcorrencia text, \n\
            dataAlteracao DATETIME)");
    };
    
    var _buscaAt = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('at', data);
    };
    var _getAt = function () {
        _iniciaTabela();
        return SQLiteAPIAbstract.fetchAll('at');
    };
    var _deleteAt = function () {
        _iniciaTabela();
        var query = "DELETE FROM at";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAt = function (atosStatus) {
        _iniciaTabela();
////        _deleteAt();
//        var query = "INSERT INTO at ( \n\
//                        id, \n\
//                        tipo, \n\
//                        ordem, \n\
//                        descricao, \n\
//                        status) VALUES (?,?,?,?,?)";
//        angular.forEach(atosStatus, function (satus,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                satus.id, 
//                satus.tipo, 
//                satus.ordem, 
//                satus.descricao, 
//                satus.status]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAt2(atosStatus, 0, 'at').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 15);
            $window.localStorage['atosStatusValido'] = new Date(valido);
            $window.localStorage['atosStatusAtualizado'] = new Date();
            $window.localStorage['atosStatusQtde'] = Object.keys(atosStatus).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setAt2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.at;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
    //                
            //caso id inserido na API for diferente do aplicativo
            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAt2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    return {
        deleteAt: _deleteAt,
        buscaAt: _buscaAt,
        getAt: _getAt,
        setAt: _setAt,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});