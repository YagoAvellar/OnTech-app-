angular.module("starter").factory('manipularArquivos',function($window, $cordovaFile, $q){
            
        var getInfoDir = function(arrayRetorno,arrayTemp,indice) {
            var defered = $q.defer();
            var promise = defered.promise;
            var arquivo = arrayTemp[indice];
            indice++;
            
            
            if(arquivo.isFile){
                arrayRetorno.push(arquivo);
//                arquivo.file(function (success) {
//                    var tamanho = success.size;
//                    console.log('tamanho');
//                    console.log(tamanho);
//                }, function (error) {
////                                            $rootScope.geraLog(error, new Error());
//                });
            }else{
                defered.resolve(listDir(arrayRetorno));
            }
            
            
            if(indice < retorno.qtde){
                
            }
            
            
            return promise;
        };    
        var listDir = function(path,arrayRetorno) {
            var defered = $q.defer();
            var promise = defered.promise;
            if(arrayTemp === undefined){
                arrayTemp = [];
            }
            window.resolveLocalFileSystemURL(path,
                    function (fileSystem) {
                        var reader = fileSystem.createReader();
                        reader.readEntries(
                                function (entries) {
                                    console.log(entries.length);
                                    console.log(entries);
                                    defered.resolve(getInfoDir(arrayRetorno, entries, 0));
                                },
                                function (err) {
                                    console.log(err);
                                }
                        );
                    }, function (err) {
                console.log(err);
            }
            );
            return promise;
        };    
            
        return {
            listarDiretorio: listDir,
            scan : function(url,fileType)
                {
                     var fileTypeCollection = [];
                     var defer = $q.defer();


                        url.forEach(function(element, index) 
                        {
                        //requestLocalFileSystemURL
                        console.log('element');
                        console.log(element);
                        window.resolveLocalFileSystemURL(element,onRequestFileSystem, fail);


                        console.log("Ends resolve");
                        });


                    function onRequestFileSystem(fileSystem) 
                    {
                        console.log('fileSystem');
                        console.log(fileSystem);
                        var directoryReader = fileSystem.createReader();
                        directoryReader.readEntries(onReadEntries,fail);
                    } /*onRequestFile Ends*/

                    function onReadEntries(entries) 
                    {

                        console.log(entries);
                        if(entries.length==0)
                        {
                             console.log("Entries Length....Resolving");
                             defer.resolve(fileTypeCollection);
                        }
                        else
                        {   
                            entries.forEach( function(element, index) 
                            {

                                if (element.isDirectory === true) 
                                {
                                // Recursive -- call back into this subdirectory

                                 onRequestFileSystem(element);
                                } 

                                if(element.isFile == true) 
                                {
                                    if(fileType !== undefined && isArray(fileType)){
                                        fileType.forEach(function(type)
                                        {
                                            if(element.name.indexOf(type) != -1)
                                            {
                                                fileTypeCollection.push(element);
                                            }
                                        });
                                    }else{
                                        fileTypeCollection.push(element);
                                    }
//                                    console.log(element);
                                } /*is File ENds*/
                            });  /*Entries For Each Ends*/
                        }   

                    }  /*OnRead Ends*/

                    function fail(resp)
                    {
                        console.log(resp);
                        defer.reject();
                    }  /*Fail Ends*/

                return defer.promise;

            }  //Scan Function Ends
        }
  });