angular.module("starter").factory("SQLiteAPIatosStatus", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    atosStatusAPI, SQLiteAPIAbstract, $ionicPlatform) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_status").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_status"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atos_status \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            tipo text, \n\
            ordem integer, \n\
            descricao text, \n\
            status text, \n\
            dataAlteracao DATETIME)");
    };
    
    var _buscaAtosStatus = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atos_status', data);
    };
    var _getAtosStatusAtendimento = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $ionicPlatform.ready(function () {
            _iniciaTabela(); 
            var query = "SELECT * FROM atos_status\n\
                        WHERE tipo = 'ATENDIMENTO' AND id IN(1,4,6,7,8,11,15,16) AND status = 't' OR  tipo = 'MONTAGEM'";
            defered.resolve($cordovaSQLite.execute($rootScope.db, query));
        });
        return promise;
    };
    var _getAtosStatusFinalizar = function (tipo) {
        _iniciaTabela();
        var query = "SELECT * FROM atos_status\n\
                    WHERE tipo = 'ATENDIMENTO' AND id IN(5,6,7,16) AND status = 't'";
        if(tipo === "Expositor"){
            query = "SELECT * FROM atos_status\n\
                        WHERE tipo = 'MONTAGEM' AND status = 't'";
        }
        
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtosStatus = function () {
        _iniciaTabela();
        var query = "SELECT * FROM atos_status";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _deleteAtosStatus = function () {
        _iniciaTabela();
        var query = "DELETE FROM atos_status";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtosStatus = function (atosStatus) {
        _iniciaTabela();
////        _deleteAtosStatus();
//        var query = "INSERT INTO atos_status ( \n\
//                        id, \n\
//                        tipo, \n\
//                        ordem, \n\
//                        descricao, \n\
//                        status) VALUES (?,?,?,?,?)";
//        angular.forEach(atosStatus, function (satus,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                satus.id, 
//                satus.tipo, 
//                satus.ordem, 
//                satus.descricao, 
//                satus.status]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAtosStatus2(atosStatus, 0, 'atos_status').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 15);
            $window.localStorage['atosStatusValido'] = new Date(valido);
            $window.localStorage['atosStatusAtualizado'] = new Date();
            $window.localStorage['atosStatusQtde'] = Object.keys(atosStatus).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setAtosStatus2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.at;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
    //                
            //caso id inserido na API for diferente do aplicativo
            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAtosStatus2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    return {
        getAtosStatusAtendimento: _getAtosStatusAtendimento,
        getAtosStatusFinalizar: _getAtosStatusFinalizar,
        deleteAtosStatus: _deleteAtosStatus,
        buscaAtosStatus: _buscaAtosStatus,
        getAtosStatus: _getAtosStatus,
        setAtosStatus: _setAtosStatus,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});