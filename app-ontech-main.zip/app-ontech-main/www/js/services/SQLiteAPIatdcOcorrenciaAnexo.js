angular.module("starter").factory("SQLiteAPIatdcOcorrenciaAnexo", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, AtdcOcorrenciaAnexoAPI, SQLiteAPIAbstract, $cordovaFile) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_anexo").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_anexo");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_ocorrencia_anexo \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atdcOcorrencia integer, \n\
            itadauUsuario integer, \n\
            data DATETIME, \n\
            titulo text, \n\
            anexo text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
    
    var _buscaAtdcOcorrenciaAnexos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_ocorrencia_anexo', data);
    };
    
    var _getAnexosOcorrencia = function (atdcOcorrencia) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_anexos = [];
        var query = "SELECT \n\
                        'anexo' AS tipo,\n\
                        atdcOcorrencia, \n\
                        data, \n\
                        titulo, \n\
                        anexo \n\
                    FROM atdc_ocorrencia_anexo WHERE atdcOcorrencia = ?\n\
                    UNION\n\
                    SELECT \n\
                        'layoutproposto' AS tipo,\n\
                        atdcOcorrencia, \n\
                        dataAtualizacao, \n\
                        'Layout Proposto', \n\
                        anexoLayoutProposto \n\
                    FROM atdc_ocorrencia_expositor WHERE atdcOcorrencia = ? AND anexoLayoutProposto IS NOT NULL";
        
        $cordovaSQLite.execute($rootScope.db, query, [atdcOcorrencia,atdcOcorrencia]).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                if(row.tipo == 'anexo'){
                    row.caminhoAnexo = $rootScope.caminhoAnexo + row.anexo;
                }
                if(row.tipo == 'layoutproposto'){
                    row.caminhoAnexo = $rootScope.caminhoLayoutProposto + row.anexo;
                }
                atdc_ocorrencia_anexos.push(row);
            }
            defered.resolve(atdc_ocorrencia_anexos);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
        
    };
    
    var _getAtdcOcorrenciaAnexos = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_anexo";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtdcOcorrenciaAnexo = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_anexo WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteAtdcOcorrenciaAnexos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_ocorrencia_anexo";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtdcOcorrenciaAnexos = function (atdcOcorrenciaAnexos) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela();
        _setAtdcOcorrenciaAnexos2(atdcOcorrenciaAnexos, 0, 'atdc_ocorrencia_anexo').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atdcOcorrenciaAnexoValido'] = new Date(valido);
            $window.localStorage['atdcOcorrenciaAnexoAtualizado'] = new Date();
            $window.localStorage['atdcOcorrenciaAnexoQtde'] = Object.keys(atdcOcorrenciaAnexos).length;
            defered.resolve(atdcOcorrenciaAnexos);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _setAtdcOcorrenciaAnexos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
            registro.data = $rootScope.trataDataNull(registro.data);

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setAtdcOcorrenciaAnexos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    function _getAtdcOcorrenciaAnexosParaSincronizar () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_anexos = [];
        var query = "SELECT * FROM atdc_ocorrencia_anexo WHERE sincronizado = 0 OR sincronizado = null";
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdc_ocorrencia_anexos.push(row);
            }
            defered.resolve(atdc_ocorrencia_anexos);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    function _enviaAtdcOcorrenciaAnexos (atdc_ocorrencia_anexos) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela(); 
        $http.post($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia?sync=enviar', atdc_ocorrencia_anexos).then(function (data) {
            _retiraAtdcOcorrenciaAnexoSincronizacao(data.data, 0).then(function (data) {
                defered.resolve(data);
            }, function (err) {
                defered.reject(err);
            });
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    var _retiraAtdcOcorrenciaAnexoSincronizacao = function (retorno, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var id = retorno[indice].id;
        indice++;
        
        var query = "UPDATE atdc_ocorrencia_anexo set sincronizado = 1 WHERE id = ?";
        
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function (data) {
            if(indice < retorno.qtde){
                return _retiraAtdcOcorrenciaAnexoSincronizacao(retorno, indice);
            }else{
                defered.resolve(retorno);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    function _downloadArquivos () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_anexos = [];
        
        if($rootScope.excluindoAntigos){
            setTimeout(_downloadArquivos, 6000);
            defered.resolve(atdc_ocorrencia_anexos);
        }else{
            var query = "SELECT id, anexo FROM atdc_ocorrencia_anexo";
            _iniciaTabela(); 
    //        console.log('teste123');
            $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
                for (var i = 0; i < data.rows.length; i++) {
                    var row = data.rows.item(i);
                    atdc_ocorrencia_anexos.push(row);
                }
                defered.resolve(_buscaArquivos(atdc_ocorrencia_anexos, 0));
            }, function (err) {
                defered.reject(err);
            });
        }
        return promise;
    }
    
    function _buscaArquivos (atdc_ocorrencia_anexos, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = atdc_ocorrencia_anexos[indice];
        indice++;
        
        if(atdc_ocorrencia_anexos.length > 0){
            $rootScope.verificaArquivo($rootScope.caminhoAnexo, registro.anexo)
            .then(function (success) {
    //            console.log('success');
    //            console.log(success);
                if(indice < atdc_ocorrencia_anexos.length){ 
                    defered.resolve(_buscaArquivos(atdc_ocorrencia_anexos, indice));
                }else{
                    setTimeout(_downloadArquivos, 600000);
                    defered.resolve(atdc_ocorrencia_anexos);
                }
            }, function (error) {
    //            console.log('error');
    //            console.log(error);
                var arquivo = $rootScope.urlAnexo + registro.anexo;
                $rootScope.Download(arquivo,$rootScope.caminhoAnexo).then(function(retorno){
                    if(retorno !== registro.anexo){
                        registro.anexo = retorno;
                        SQLiteAPIAbstract.insertOrUpdate ('atdc_ocorrencia_anexo', registro.id, registro, false);
                    }
                    if(indice < atdc_ocorrencia_anexos.length){ 
                        defered.resolve(_buscaArquivos(atdc_ocorrencia_anexos, indice));
                    }else{
                        setTimeout(_downloadArquivos, 600000);
                        defered.resolve(atdc_ocorrencia_anexos);
                    }
                }, function (error) {
                    if(indice < atdc_ocorrencia_anexos.length){ 
                        defered.resolve(_buscaArquivos(atdc_ocorrencia_anexos, indice));
                    }else{
                        setTimeout(_downloadArquivos, 600000);
                        defered.resolve(atdc_ocorrencia_anexos);
                    }
                });
            });
        }else{
            setTimeout(_downloadArquivos, 600000);
            defered.resolve(atdc_ocorrencia_anexos);
        }
        return promise;
    }
    
    var _excluiAntigos = function (dias) {
        var defered = $q.defer();
        var promise = defered.promise;
        var select = 'a.*';
        var query = _getQuery(select, dias);
        
        _getAtdcOcorrenciaAnexosLimpar (query).then(function (data) {
            select = 'a.id';
//            query = _getQuery(select, dias);            
            query = "DELETE FROM atdc_ocorrencia_anexo WHERE id IN ( "+_getQuery(select, dias)+" )";
//            defered.resolve('OK');
            defered.resolve($cordovaSQLite.execute($rootScope.db, query));
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    function _getQuery (select, dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT "+select+" FROM atdc_ocorrencia_anexo a \n\
                     JOIN atdc_ocorrencia b ON  b.id = a.atdcOcorrencia \n\
                     JOIN atos c ON  c.atdcOcorrencia = b.id \n\
                     ";
        query+= " WHERE b.atdcStatus = 6 \n\
                  AND c.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        return query;
    }
    
    
    function _getAtdcOcorrenciaAnexosLimpar (query) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_anexos = [];
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdc_ocorrencia_anexos.push(row);
            }
            if(atdc_ocorrencia_anexos.length > 0){
                defered.resolve(_excluirAnexos(atdc_ocorrencia_anexos, 0));
            }else{
                defered.resolve(atdc_ocorrencia_anexos);
            }
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    function _excluirAnexos (atdc_ocorrencia_anexos,indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = atdc_ocorrencia_anexos[indice];
        indice++;
        _iniciaTabela(); 
                
        $cordovaFile.checkFile($rootScope.caminhoAnexo,registro.anexo).then(function (success) {
            console.log('success');
            console.log(success);
            $cordovaFile.removeFile($rootScope.caminhoAnexo,registro.anexo).then(function (success) {
                if(indice < atdc_ocorrencia_anexos.length){
                    defered.resolve(_excluirAnexos(atdc_ocorrencia_anexos, indice));
                }else{
                    defered.resolve(atdc_ocorrencia_anexos);
                }
            }, function (error) {
                if(indice < atdc_ocorrencia_anexos.length){
                    defered.resolve(_excluirAnexos(atdc_ocorrencia_anexos, indice));
                }else{
                    defered.resolve(atdc_ocorrencia_anexos);
                }
            });
        }, function (error) {
            console.log('error');
            console.log(error);
            console.log('registro.anexo');
            console.log(registro.anexo);
            if(indice < atdc_ocorrencia_anexos.length){
                defered.resolve(_excluirAnexos(atdc_ocorrencia_anexos, indice));
            }else{
                defered.resolve(atdc_ocorrencia_anexos);
            }
        });
        
        return promise;
    }
    
    
    return {
        excluiAntigos: _excluiAntigos,
        downloadArquivos: _downloadArquivos,
        getAnexosOcorrencia: _getAnexosOcorrencia,
        enviaAtdcOcorrenciaAnexos: _enviaAtdcOcorrenciaAnexos,
        getAtdcOcorrenciaAnexosParaSincronizar: _getAtdcOcorrenciaAnexosParaSincronizar,
        deleteAtdcOcorrenciaAnexos: _deleteAtdcOcorrenciaAnexos,
        buscaAtdcOcorrenciaAnexos: _buscaAtdcOcorrenciaAnexos,
        getAtdcOcorrenciaAnexos: _getAtdcOcorrenciaAnexos,
        getAtdcOcorrenciaAnexo: _getAtdcOcorrenciaAnexo,
        setAtdcOcorrenciaAnexos: _setAtdcOcorrenciaAnexos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});