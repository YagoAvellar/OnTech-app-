angular.module("starter").factory("SQLiteAPIatosServico", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    SQLiteAPIAbstract, SQLiteAPIatdcOcorrenciaLog) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_servico").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_servico");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atos_servico \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atos integer, \n\
            atdcOcorrencia integer, \n\
            atosStatus integer, \n\
            atdcOcorrenciaProduto integer, \n\
            itadauUsuario integer, \n\
            dataInclusao datetime, \n\
            dataInicio datetime, \n\
            dataFim datetime, \n\
            codigo text, \n\
            descricao text, \n\
            valor float, \n\
            laudoTecnico text, \n\
            atosStatusDescricao text, \n\
            observacao text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            excluido integer, \n\
            sincronizado integer)");
    };
    
    var _buscaAtosServicos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atos_servico', data);
    };
    
    var _getAtosServicos = function (atos) {
        _iniciaTabela(); 
        var query = "SELECT A.*, B.descricao AS atosStatusDescricao FROM atos_servico A JOIN atos_status B ON B.ID = A.atosStatus";
        if(atos != undefined){
            query+= " WHERE atos = "+atos+" AND (excluido IS NULL OR excluido <> 1) ";
        }
//        console.log(query);
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtosServicos2 = function (atos) {
        var defered = $q.defer();
        var promise = defered.promise;
        
        var query = "SELECT A.*, B.descricao AS atosStatusDescricao FROM atos_servico A JOIN atos_status B ON B.ID = A.atosStatus";
        if(atos != undefined){
            query+= " WHERE atos = "+atos+" AND (excluido IS NULL OR excluido <> 1) ";
        }
        var servicos = {};
        $cordovaSQLite.execute($rootScope.db, query).then(function(atosServicos){
            if(atosServicos.rows.length > 0){
                for (var i = 0; i < atosServicos.rows.length; i++) {
                    var row = atosServicos.rows.item(i);
                    _retornaObjetoCompleto(row).then(function(data){
                        servicos[data.id] = data; 
                        if(atosServicos.rows.length <= i+1 ){
                            defered.resolve(servicos);
                        }
                    }, function(err){
                        console.error(err); 
                        defered.reject(err);
                    });
                }
            }else{
                defered.resolve(servicos);
            }
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    
    
    
    var _deleteAtosServicos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atos_servico";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtosServicos = function (atosServicos) {
        _iniciaTabela();
////        _deleteAtosServicos();
//        var query = "INSERT INTO atos_servico ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        atos, \n\
//                        atdcOcorrencia, \n\
//                        atosStatus, \n\
//                        atosServicoTipo, \n\
//                        atdcOcorrenciaProduto, \n\
//                        itadauUsuario, \n\
//                        dataInclusao, \n\
//                        dataInicio, \n\
//                        dataFim, \n\
//                        laudoTecnico, \n\
//                        atosStatusDescricao, \n\
//                        atosServicoTipoDescricao, \n\
//                        observacao,\n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"; 
//        angular.forEach(atosServicos, function (atosServico,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atosServico.id,
//                atosServico.id,
//                atosServico.atos,
//                atosServico.atdcOcorrencia,
//                atosServico.atosStatus,
//                atosServico.atosServicoTipo,
//                atosServico.atdcOcorrenciaProduto,
//                atosServico.itadauUsuario,
//                $rootScope.trataDataNull(atosServico.dataInclusao),
//                $rootScope.trataDataNull(atosServico.dataInicio),
//                $rootScope.trataDataNull(atosServico.dataFim),
//                atosServico.laudoTecnico,
//                atosServico.atosStatusDescricao,
//                atosServico.atosServicoTipoDescricao,
//                atosServico.observacao,
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) { 
//              console.error(err);
//            });
//        });
        _setAtosServicos2(atosServicos, 0, 'atos_servico').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atosServicoValido'] = new Date(valido);
            $window.localStorage['atosServicoAtualizado'] = new Date();
            $window.localStorage['atosServicoQtde'] = Object.keys(atosServicos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    
    var _setAtosServicos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
    //        delete registro.status;
    //        delete registro.abertura;
    //        delete registro.encerramento;
    //        delete registro.distancia;
    //        registro.dataAgendamento = $rootScope.trataDataNull(registro.dataAgendamento);
    //        registro.dataInicio = $rootScope.trataDataNull(registro.dataInicio);
    //        registro.dataFim = $rootScope.trataDataNull(registro.dataFim);

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAtosServicos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    var _atualizaServico = function (id, servicoEditar) {
        var defered = $q.defer();
        var promise = defered.promise;
        console.log('servicoEditar atualiza');
        console.log(servicoEditar);
        var servico = {
            'codigo'                : servicoEditar.codigo,
            'descricao'             : servicoEditar.descricao,
            'valor'                 : servicoEditar.valor,
            'atdcOcorrenciaProduto' : servicoEditar.atdcOcorrenciaProduto != undefined ? servicoEditar.atdcOcorrenciaProduto.id : null,
            'observacao'            : servicoEditar.observacao
        };
        
//        console.log(servicoEditar);
        SQLiteAPIAbstract.update('atos_servico', id, servico).then(function(data){
            defered.resolve(_retornaObjetoCompleto(data));
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    var _adicionaServico = function (servicoEditar) {
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        
        console.log('servicoEditar');
        console.log(servicoEditar);
        
        var servico = {
            'atos'                  : servicoEditar.atos,
            'atdcOcorrencia'        : servicoEditar.atdcOcorrencia != undefined ? servicoEditar.atdcOcorrencia : null,
            'codigo'                : servicoEditar.codigo,
            'descricao'             : servicoEditar.descricao,
            'valor'                 : servicoEditar.valorServico != undefined ? servicoEditar.valorServico : servicoEditar.valor,
            'atdcOcorrenciaProduto' : servicoEditar.atdcOcorrenciaProduto != undefined ? servicoEditar.atdcOcorrenciaProduto.id : null,
            'dataInclusao'          : $rootScope.converteObjetoDataPost(timeNow),
            'atosStatus'            : 17,
            'atosStatusDescricao'   : 'Aberto',
            'observacao'            : servicoEditar.observacao
        };
//        
//        console.log(servico);
        SQLiteAPIAbstract.insert('atos_servico', servico).then(function(data){
            defered.resolve(_retornaObjetoCompleto(data));
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    }; 
    
    var _retornaObjetoCompleto = function (atosServico) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = atosServico;
        SQLiteAPIAbstract.find(atosServico.atdcOcorrenciaProduto,'atdc_ocorrencia_produto').then(function(data){
            retorno.atdcOcorrenciaProduto = data;
//            return SQLiteAPIAbstract.find(atosServico.atosServicoTipo,'atos_servico_tipo');
//        }).then(function (data) {
//            retorno.atosServicoTipo = data;
            defered.resolve(retorno);
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    
    var _realizarCheckinServico = function (id_servico) {
//        console.log(id_servico);
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        var dataInicio = $rootScope.converteObjetoDataPost(timeNow);        
        var dados = {
            'dataInicio' : dataInicio,
            'dataAlteracao' : dataInicio,
            'sincronizado' : 0,
            'itadauUsuario' : $rootScope.usuarioLogado.id,
            'atosStatus' : 18
        };
//        console.log(dados);
        
        SQLiteAPIAbstract.update('atos_servico', id_servico, dados).then(function(data){
//            console.log(data);
            defered.resolve(_retornaObjetoCompleto(data));
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    
    var _finalizarServico = function (servico) {
//        console.log(servico);
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        var dataFim = $rootScope.converteObjetoDataPost(timeNow);        
        var dados = {
            'dataFim' : dataFim,
            'dataAlteracao' : dataFim,
            'sincronizado' : 0,
            'atosStatus' : 19,
            'itadauUsuario' : $rootScope.usuarioLogado.id,
            'laudoTecnico' : servico.laudoTecnico
        };
//        console.log(dados);
        
        SQLiteAPIAbstract.update('atos_servico', servico.id, dados).then(function(data){
//            console.log(data);
            
//            SQLiteAPIatdcOcorrenciaLog.add(servico.atdcOcorrencia,'encServico', '');
            
            defered.resolve(_retornaObjetoCompleto(data));
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    var _finalizarServicos = function (checkout) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atosServicos = [];
        var dataInicio = angular.copy(checkout.dataInicio);
        
        _getAtosServicos(checkout.atos).then(function(data){
            if(data.rows.length > 0){
                for (var i = 0; i < data.rows.length; i++) {
                    var row = data.rows.item(i);
                    if(row.laudoTecnico == null){
                        row.laudoTecnico = checkout.observacao;
                    }
                    atosServicos.push(row);
                }
                defered.resolve(_finalizar(atosServicos,0,dataInicio));
            }else{
                defered.resolve(atosServicos);
            }
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _finalizar = function (atosServicos,indice,dataInicio) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atosServico = atosServicos[indice];
        var timeNow = new Date();
        var dataFim = $rootScope.converteObjetoDataPost(timeNow);
        indice++;
        atosServico.dataInicio = atosServico.dataInicio != null ? atosServico.dataInicio : dataInicio;
        atosServico.dataFim = atosServico.dataFim != null && atosServico.dataFim != '' ? atosServico.dataFim : dataFim;
        atosServico.atosStatus = 19;
        atosServico.dataAlteracao = dataFim;
        atosServico.sincronizado = 0;
        atosServico.itadauUsuario = $rootScope.usuarioLogado.id;
        
        console.log('finalizar atos_servico');
        console.log(atosServico);
        
        SQLiteAPIAbstract.update("atos_servico", atosServico.id, atosServico).then(function(data){
            if(atosServicos.length > indice){
                defered.resolve(_finalizar(atosServicos,indice,dataInicio));
            }else{
                defered.resolve(atosServicos);
            }
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _atualizaProdutoServico = function (atualizaProduto, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = atualizaProduto[indice];
        indice++;
        
        var query = "UPDATE atos_servico SET \n\
        atdcOcorrenciaProduto = "+registro.para+" \n\
        WHERE atdcOcorrenciaProduto = "+registro.de+" AND atdcOcorrencia = "+registro.atdcOcorrencia+" AND (sincronizado = 0 OR sincronizado IS NULL )"; 
                
        $cordovaSQLite.execute($rootScope.db, query).then(function(retorno){
            if(indice < atualizaProduto.length){
                defered.resolve(_atualizaProdutoServico(atualizaProduto, indice));
            }else{
                defered.resolve(retorno);
            }
        }, function(err){
            defered.reject(err);
            console.log(query);
            console.error(err);
        });
        return promise;
    };    
    
    var _excluiAntigos = function (dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT a.id FROM atos_servico a \n\
                     JOIN atos b ON  b.id = a.atos \n\
                     JOIN atdc_ocorrencia d ON d.id = b.atdcOcorrencia \n\
                     ";
        query+= " WHERE d.atdcStatus = 6 \n\
                  AND b.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        
        query = "DELETE FROM atos_servico WHERE id IN ( "+query+" )";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    
    return {
        atualizaProdutoServico : _atualizaProdutoServico,
        finalizarServicos : _finalizarServicos,
        realizarCheckinServico : _realizarCheckinServico,
        finalizarServico: _finalizarServico,
        retornaObjetoCompleto: _retornaObjetoCompleto,
        atualizaServico: _atualizaServico,
        adicionaServico: _adicionaServico,
        deleteAtosServicos: _deleteAtosServicos,
        buscaAtosServicos: _buscaAtosServicos,
        getAtosServicos: _getAtosServicos,
        getAtosServicos2: _getAtosServicos2,
        setAtosServicos: _setAtosServicos,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});