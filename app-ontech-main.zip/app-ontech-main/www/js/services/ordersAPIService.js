angular.module("starter").factory("ordersAPI", function ($http, config, $rootScope) {



//			var headers = {
//				'Access-Control-Allow-Origin' : '*',
//				'Access-Control-Allow-Methods' : 'POST, GET, OPTIONS, PUT',
//				'Content-Type': 'application/json',
//				'Accept': 'application/json'
//			};
//
//			return $http({
//				method: "POST",
//				headers: headers,
//	      url: 'http://api.onassistencia.pedro.com/v1/atdp-requisicao',
//				data: {
//                                    "atdpEstoque":"1",
//                                    "data":"2016-01-27 13:55:48",
//                                    "quantidadeRequisitada":"11"
//                                }
//	    }).success(function(result) {
//					console.log("Auth.signin.success!")
//					console.log(result);
//	    }).error(function(data, status, headers, config) {
//					console.log("Auth.signin.error!")
//	        console.log(data);
//	        console.log(status);
//	        console.log(headers);
//	        console.log(config);
//	    });

    var _getOrder = function (id) {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia/' + id);
    };

    var _deleteOrder = function (id) {
        return $http.delete($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia/' + id);
    };

    var _getOrders = function () {
        var retorno = $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia');
        console.log(retorno);
        return retorno;
    };

    return {
        getOrder: _getOrder,
        deleteOrder: _deleteOrder,
        getOrders: _getOrders
    };
})
.factory("ocorrenciaAPI", function ($http, config, $rootScope) {
    var _deleteOcorrencia = function (id) {
        return $http.delete($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia/' + id);
    };

    var _getOcorrencias = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia');
    };

    var _getOcorrenciaProdutos = function (atdcOcorrencia) {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-produto?atdcOcorrencia=' + atdcOcorrencia);
    };
    
    var _atualizaLocalizacaoCliente = function (id, atdcEndereco) {
        return $http.patch($rootScope.configEmpresa.baseUrl + '/atdc-endereco/' + id, atdcEndereco);
    };
    
    return {
        atualizaLocalizacaoCliente: _atualizaLocalizacaoCliente,
        getOcorrenciaProdutos: _getOcorrenciaProdutos,
        deleteOcorrencia: _deleteOcorrencia,
        getOcorrencias: _getOcorrencias
    };
})
.factory("ordemServicoAPI", function ($http, config, $rootScope, $httpParamSerializer) {

    var _getOrdens = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos');
    };

    var _getClientes = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc');
    };
    var _getCronograma = function (buscaAtendimento) {
//        console.log(buscaAtendimento);
//        console.log($httpParamSerializer(buscaAtendimento));
        var parametros = null;
        if(buscaAtendimento !== undefined){
            parametros = "?"+$httpParamSerializer(buscaAtendimento);
        }
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-atendimento'+parametros);
    };
    var _getAtosStatusFinalizar = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-status?tipo=ATENDIMENTO&finalidade=encerrar');
    };
    var _getAtosStatusAtendimento = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-status?tipo=ATENDIMENTO');
    };
    var _getOrdem = function (id) {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos/' + id);
    };
    var _getAtendimento = function (id, teste) {
        teste = 2;
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-atendimento/' + id);
    };
    
    var _realizarCheckin = function (id) {
        var checkin = new Object();
        var timeNow = new Date();
        checkin.dataInicio = $rootScope.converteObjetoDataPost(timeNow);
        return $http.patch($rootScope.configEmpresa.baseUrl + '/atos-atendimento/' + id, checkin);
    };
    
    var _confirmarAtendimento = function (id) {
        var confirmar = new Object();
        var timeNow = new Date();
        confirmar.atosStatus = 3;
        confirmar.confirmacao = $rootScope.converteObjetoDataPost(timeNow);
        return $http.patch($rootScope.configEmpresa.baseUrl + '/atos-atendimento/' + id, confirmar);
    };
    
    var _realizarCheckinAtividade = function (id) {
        var atividade = new Object();
        var timeNow = new Date();
        atividade.dataInicio = $rootScope.converteObjetoDataPost(timeNow);
        atividade.atosStatus = 9;
        return $http.patch($rootScope.configEmpresa.baseUrl + '/atos-atividade/' + id, atividade);
    };
    
    var _reagendarAtendimento = function (reagendamento) {
        var id = reagendamento.id;
        delete reagendamento.id;
        return $http.patch($rootScope.configEmpresa.baseUrl + '/atos-atendimento/' + id, reagendamento);
    };
    var _realizarCheckout = function (checkout) {
        var id = checkout.id;
        delete checkout.id;
//        delete checkout.atosStatus;
        var timeNow = new Date();
        checkout.dataFim = $rootScope.converteObjetoDataPost(timeNow);
        return $http.patch($rootScope.configEmpresa.baseUrl + '/atos-atendimento/' + id, checkout);
    };
    var _finalizarAtividade = function (atividadeFim) {
        var atividade = new Object();
        var timeNow = new Date();
        atividade.laudoTecnico = atividadeFim.laudoTecnico;
        atividade.dataFim = $rootScope.converteObjetoDataPost(timeNow);
        atividade.atosStatus = 10;
        
        return $http.patch($rootScope.configEmpresa.baseUrl + '/atos-atividade/' + atividadeFim.id, atividade);
    };
    var _getAtendimentoAtual = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-atendimento?atosStatus=4');
    };
    
    var _addImagemOS = function (atosImagem) {
        return $http.post($rootScope.configEmpresa.baseUrl + '/atos-imagem', atosImagem,{

            transformRequest:angular.identity,
            headers:{'Content-Type':undefined
            }
        });
    };
    
    var _getProdutoTipoLinhaFamilia = function (dados) {
        var parametros;
        if(dados !== undefined){
            parametros = "?"+$httpParamSerializer(dados);
        }
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdb-produto'+parametros);
    };
    
    var _getAtividadeTipo = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-atividade-tipo');
    };    
    
    var _getGrupoDefeito = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-grupo');
    };    
    
    var _getDefeitos = function (dados) {
        var parametros = '';
        if(dados !== undefined){
            parametros = "?"+$httpParamSerializer(dados);
        }
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-grupo-defeito'+parametros);
    };    
    var _getDefeitoProcedimentos = function (dados) {
        var parametros = '';
        if(dados !== undefined){
            parametros = "?"+$httpParamSerializer(dados);
        }
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-grupo-defeito-procedimento'+parametros);
    };
    var _addOcorrenciaProdutoProcedimento = function (atdcOcorrenciaProdutoProcedimento) {
        return $http.post($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-produto-procedimento', atdcOcorrenciaProdutoProcedimento);
    };
    var _atualizaOcorrenciaProduto = function (id, produtoEditar) {
        var ocorrenciaProduto = angular.copy(produtoEditar);
        if(angular.isObject(ocorrenciaProduto.atdcGrupoDefeito)){
            ocorrenciaProduto.atdcGrupoDefeito = ocorrenciaProduto.atdcGrupoDefeito.id;
        }
//        console.log(ocorrenciaProduto);
        delete ocorrenciaProduto.id;
        delete ocorrenciaProduto.atdcProdutoAjuda;
        delete ocorrenciaProduto._embedded;
        delete ocorrenciaProduto._links;
//        delete ocorrenciaProduto.notaFiscal;
//        delete ocorrenciaProduto.dataCompra;
//        delete ocorrenciaProduto.atdcOcorrenciaProdutoProcedimentos;
//        console.log(ocorrenciaProduto);
        return $http.patch($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-produto/' + id, ocorrenciaProduto);
    };
    var _adicionaOcorrenciaProduto = function (produtoEditar) {
        var ocorrenciaProduto = angular.copy(produtoEditar);
        if(angular.isObject(ocorrenciaProduto.atdcGrupoDefeito)){
            ocorrenciaProduto.atdcGrupoDefeito = ocorrenciaProduto.atdcGrupoDefeito.id;
        }
//        console.log(ocorrenciaProduto);
        delete ocorrenciaProduto.id;
        delete ocorrenciaProduto.atdcProdutoAjuda;
        delete ocorrenciaProduto._embedded;
        delete ocorrenciaProduto._links;
//        delete ocorrenciaProduto.notaFiscal;
//        delete ocorrenciaProduto.dataCompra;
//        delete ocorrenciaProduto.atdcOcorrenciaProdutoProcedimentos;
//        console.log(ocorrenciaProduto);
        return $http.post($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-produto', ocorrenciaProduto);
    };
    var _atualizaAtividade = function (id, atividadeEditar) {
        var atividade = {
            'atosAtividadeTipo'     : atividadeEditar.atosAtividadeTipo.id,
            'atdcOcorrenciaProduto' : atividadeEditar.atdcOcorrenciaProduto.id,
            'observacao'            : atividadeEditar.observacao
        };
//        console.log(atividade);
        return $http.patch($rootScope.configEmpresa.baseUrl + '/atos-atividade/' + id, atividade);
    };
    var _adicionaAtividade = function (atividadeEditar) {
        var atividade = {
            'atos'                  : atividadeEditar.atos,
            'atosAtividadeTipo'     : atividadeEditar.atosAtividadeTipo.id,
            'atdcOcorrenciaProduto' : atividadeEditar.atdcOcorrenciaProduto.id,
            'observacao'            : atividadeEditar.observacao
        };
//        console.log(atividade);
        return $http.post($rootScope.configEmpresa.baseUrl + '/atos-atividade', atividade);
    };

    var _deleteProdutoProcedimento = function (id) {
        return $http.delete($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-produto-procedimento/' + id);
    };

    var _deleteProduto = function (id) {
        return $http.delete($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-produto/' + id);
    };
    var _deleteAtividade = function (id) {
        return $http.delete($rootScope.configEmpresa.baseUrl + '/atos-atividade/' + id);
    };

    return {
        addOcorrenciaProdutoProcedimento: _addOcorrenciaProdutoProcedimento,
        getProdutoTipoLinhaFamilia: _getProdutoTipoLinhaFamilia,
        deleteProdutoProcedimento: _deleteProdutoProcedimento,
        atualizaOcorrenciaProduto: _atualizaOcorrenciaProduto,
        adicionaOcorrenciaProduto: _adicionaOcorrenciaProduto,
        realizarCheckinAtividade: _realizarCheckinAtividade,
        getAtosStatusAtendimento: _getAtosStatusAtendimento,
        getDefeitoProcedimentos: _getDefeitoProcedimentos,
        getAtosStatusFinalizar: _getAtosStatusFinalizar,
        reagendarAtendimento: _reagendarAtendimento,
        confirmarAtendimento: _confirmarAtendimento,
        getAtendimentoAtual: _getAtendimentoAtual,
        finalizarAtividade: _finalizarAtividade,
        atualizaAtividade: _atualizaAtividade,
        adicionaAtividade: _adicionaAtividade,
        getAtividadeTipo: _getAtividadeTipo,
        realizarCheckout: _realizarCheckout,
        realizarCheckin: _realizarCheckin,
        getGrupoDefeito: _getGrupoDefeito,
        deleteAtividade: _deleteAtividade,
        getAtendimento: _getAtendimento,
        deleteProduto: _deleteProduto,
        getCronograma: _getCronograma,
        getDefeitos: _getDefeitos,
        addImagemOS: _addImagemOS,
        getClientes: _getClientes,
        getOrdens: _getOrdens,
        getOrdem: _getOrdem
    };
})
.factory("estoqueAPI", function ($http, config, $rootScope) {
    var _getPecaEstoque = function (id) {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdp-estoque/' + id);
    };
    var _requisitarPecaEstoque = function (requisicaoPeca) {
//            var options = {
//			secure: true
//		};
//            options = angular.extend({
//                            headers: {
////                                "Accept": "application/json",
////                                "Content-Type": "multipart/form-data; boundary=----WebKitFormBoundaryJkccNPmALFyjqua9"
////                                'Content-Type' : 'text/html; charset=UTF-8',
//////                'Accept' => 'application/json',
////                'Accept' : '*/*',
////            'Accept-Encoding' : 'gzip, deflate'
////                                "enctype": "multipart/form-data"
//                            }
//                        }, options);
//		return $http.post($rootScope.configEmpresa.baseUrl + '/atdp-requisicao',requisicaoPeca,options);
        return $http.post($rootScope.configEmpresa.baseUrl + '/atdp-requisicao', requisicaoPeca);
    };
    var _darEntradaPecaEstoque = function (requisicaoPeca) {
        return $http.post($rootScope.configEmpresa.baseUrl + '/atdp-movimentacao', requisicaoPeca);
    };
    var _darBaixaPecaEstoque = function (requisicaoPeca) {
        return $http.post($rootScope.configEmpresa.baseUrl + '/atdp-movimentacao', requisicaoPeca);
    };
    
    var _addPecaEstoque = function (atdpEstoque) {
        return $http.post($rootScope.configEmpresa.baseUrl + '/atdp-estoque?origem=app', atdpEstoque);
    };
    
    var _deletePecaEstoque = function (id) {
        return $http.delete($rootScope.configEmpresa.baseUrl + '/atdp-estoque/' + id);
    };

    var _getEstoque = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdp-estoque?origem=app');
    };

    var _getEstoqueMovimentacao = function (atdpEstoque) {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdp-movimentacao?origem=app&atdpEstoque=' + atdpEstoque);
    };

    var _getPecas = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdp?origem=app');
    };
    
    return {
        getPecaEstoque: _getPecaEstoque,
        getEstoqueMovimentacao: _getEstoqueMovimentacao,
        requisitarPecaEstoque: _requisitarPecaEstoque,
        darEntradaPecaEstoque: _darEntradaPecaEstoque,
        darBaixaPecaEstoque: _darBaixaPecaEstoque,
        deletePecaEstoque: _deletePecaEstoque,
        addPecaEstoque: _addPecaEstoque,
        getEstoque: _getEstoque,
        getPecas: _getPecas
    };
}).factory('Camera', ['$q', function($q) {

  return {
    getPicture: function(options) {
      var q = $q.defer();

      navigator.camera.getPicture(function(result) {
        // Do any magic you need
        q.resolve(result);
      }, function(err) {
        q.reject(err);
      }, options);

      return q.promise;
    }
  };
}])
.factory("configuracoesAPI", function ($http, config, $rootScope) {

    var _getVersao = function (id) {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia/' + id);
    };

    var _getUsuario = function () {
        var retorno = $http.get($rootScope.configEmpresa.baseUrl + '/itadau-usuario?logado=1');
//        console.log(retorno);
        return retorno;
    };
    var _alterarSenha = function (id, itadauUsuario) {
        return $http.patch($rootScope.configEmpresa.baseUrl + '/itadau-usuario/' + id, itadauUsuario);
    };

    return {
        alterarSenha: _alterarSenha,
        getUsuario: _getUsuario,
        getVersao: _getVersao
    };
})
.factory("clientesAPI", function ($http, config, $rootScope) {

    var _getClientes = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc?sync=busca');
    };

    return {
        getClientes: _getClientes
//        getUsuario: _getUsuario,
//        getVersao: _getVersao
    };
})
.factory("produtosAPI", function ($http, config, $rootScope) {

    var _getProdutos = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdb-produto?sync=busca');
    };

    return {
        getProdutos: _getProdutos
//        getUsuario: _getUsuario,
//        getVersao: _getVersao
    };
}).factory("AtendimentoAPI", function ($http, config, $rootScope) {

    var _getAtendimentos = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-atendimento?sync=busca');
    };

    return {
        getAtendimentos: _getAtendimentos
    };
}).factory("atosStatusAPI", function ($http, config, $rootScope) {

    var _getAtosStatus = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-status?sync=busca');
    };

    return {
        getAtosStatus: _getAtosStatus
    };
}).factory("AtdcOcorrenciaAPI", function ($http, config, $rootScope) {

    var _getAtdcOcorrencias = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia?sync=busca');
    };

    return {
        getAtdcOcorrencias: _getAtdcOcorrencias
    };
}).factory("AtdcEnderecoAPI", function ($http, config, $rootScope) {

    var _getAtdcEnderecos = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-endereco?sync=busca');
    };

    return {
        getAtdcEnderecos: _getAtdcEnderecos
    };
}).factory("atosAtividadeTipoAPI", function ($http, config, $rootScope) {

    var _getAtosAtividadeTipo = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atos-atividade-tipo?sync=busca');
    };

    return {
        getAtosAtividadeTipo: _getAtosAtividadeTipo
    };
}).factory("AtdcOcorrenciaEncerramentoAPI", function ($http, config, $rootScope) {

    var _getAtdcOcorrenciaEncerramentos = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-encerramento?sync=busca');
    };

    return {
        getAtdcOcorrenciaEncerramentos: _getAtdcOcorrenciaEncerramentos
    };
}).factory("AtdcOcorrenciaLogAPI", function ($http, config, $rootScope) {

    var _getAtdcOcorrenciaLogs = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-log?sync=busca');
    };

    return {
        getAtdcOcorrenciaLogs: _getAtdcOcorrenciaLogs
    };
}).factory("AtdcOcorrenciaInteracaoAPI", function ($http, config, $rootScope) {

    var _getAtdcOcorrenciaInteracoes = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-interacao?sync=busca');
    };

    return {
        getAtdcOcorrenciaInteracoes: _getAtdcOcorrenciaInteracoes
    };
}).factory("AtdcOcorrenciaAnexoAPI", function ($http, config, $rootScope) {

    var _getAtdcOcorrenciaAnexos = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia-anexo?sync=busca');
    };

    return {
        getAtdcOcorrenciaAnexos: _getAtdcOcorrenciaAnexos
    };
}).factory("ProdutoAjudaAPI", function ($http, config, $rootScope) {

    var _getProdutoDocumentacoes = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdb-produto-ajuda?sync=busca');
    };

    return {
        getProdutoDocumentacoes: _getProdutoDocumentacoes
    };
}).factory("ProdutoTipoAPI", function ($http, config, $rootScope) {

    var _getProdutoTipos = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdb-produto-tipo?sync=busca');
    };

    return {
        getProdutoTipos: _getProdutoTipos
    };
}).factory("ItadauUsuarioLocalizacaoAPI", function ($http, config, $rootScope) {

    var _getItadauUsuarioLocalizacaos = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/itadau-usuario-localizacao?sync=busca');
    };

    return {
        getItadauUsuarioLocalizacaos: _getItadauUsuarioLocalizacaos
    };
});