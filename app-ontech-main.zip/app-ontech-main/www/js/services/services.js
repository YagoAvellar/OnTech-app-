angular.module('starter.services',[])

    .service('oauthFixInterceptor', ['$rootScope','$q','OAuthToken', 'config', 'authService', '$cordovaNetwork',function($rootScope, $q, OAuthToken, config, authService, $cordovaNetwork){
        return{
            request: function (config) {
                if (OAuthToken.getAuthorizationHeader()) {
                    config.headers = config.headers || {};
                    config.headers.Authorization = OAuthToken.getAuthorizationHeader();
                }
                return config;
            },
            responseError: function (rejection) {
                if (rejection.status == 400 && rejection.data &&
                        (rejection.statusText == "invalid_request" || rejection.statusText == "invalid_grant")) {
                    OAuthToken.removeToken();
                    $rootScope.$emit('oauth:error', {rejection: rejection});
                }

                if (rejection.status == 401) {
                    $rootScope.enviando = false;
                    $rootScope.dataEnviando = null;
                    var deffered = $q.defer();
                    $rootScope.$emit('oauth:error', {rejection: rejection, deffered: deffered});
                    return deffered.promise;
                }
//                if (rejection.status == 403) {
//                    console.log('erro 403');
//                    $rootScope.enviando = false;
//                    $rootScope.buscando = false;
//                    var deffered = $q.defer();
//                    $rootScope.$emit('oauth:error', {rejection: rejection, deffered: deffered});
//                    return deffered.promise;
//                }
//                if (rejection.status == 500 && config.baseUrl != config.baseUrlSasazaki && $cordovaNetwork.isOnline()) {
//                    var deffered = $q.defer();
//                    rejection.config.url = rejection.config.url.replace(config.baseUrl, config.baseUrlSasazaki);
//                
//                    OAuthToken.alteraUrlOauth(config.baseUrlOauthSasazaki);
//                    
//                    config.baseUrl = config.baseUrlSasazaki;
//                    config.documentacaoUrl = config.documentacaoUrlSasazaki;
//                    config.imageUrl = config.imageUrlSasazaki;
//
//                    $rootScope.$emit('response:error', {rejection: rejection, deffered: deffered});
//                    return deffered.promise;
//                }
                return $q.reject(rejection);
            }
        };
    }])

    .service('logout', ['OAuthToken','$state','$ionicHistory',
        function(OAuthToken, $state,$ionicHistory ) {
            return {
                logout: function () {
                    OAuthToken.removeToken();
                    $ionicHistory.clearCache();
                    $ionicHistory.clearHistory();
                    $ionicHistory.nextViewOptions({
                        disableBack: true,
                        historyRoot: true
                    });
                }
            };
        }
    ])
    .service('$localStorage',['$window',function($window){
        return {
            set: function(key, value){
                $window.localStorage[key]=value;
                return $window.localStorage[key];
            },
            get: function(key, defaultValue){
                return $window.localStorage[key]|| defaultValue;
            },
            setObject: function(key,value){
                $window.localStorage[key]= JSON.stringify(value);
                return this.getObject(key);
            },
            getObject: function(key){
                return JSON.parse($window.localStorage[key]|| null);
            }
        }
  }]);