angular.module("starter").factory("SQLiteAPIAbstract", function ($ionicPlatform, $http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, ordemServicoAPI, 
    AtendimentoAPI, $cordovaFile, $cordovaFileTransfer, $localStorage) {

    var _fetchAll = function (tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT * FROM "+tabela;
        var retorno = {};
        var linha = {};
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                linha = consulta.rows.item(i);
                retorno[linha.id] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    
    var _find = function (id, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT * FROM "+tabela+" WHERE id = ?";
//        console.log(query);
//        console.log("id = "+id);
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function(consulta){
            if(consulta.rows.length > 0){
                defered.resolve(consulta.rows.item(0));
            }else{
                defered.resolve(null);
            }
        }, function(err){
            defered.reject(err);
        });
        return promise; 
    };
    
    var _findCampo = function (tabela, campo, valor) {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT * FROM "+tabela+" WHERE "+campo+" = ?";
//        console.log(query);
//        console.log("id = "+id);
        $cordovaSQLite.execute($rootScope.db, query,[valor]).then(function(consulta){
            if(consulta.rows.length > 0){
                defered.resolve(consulta.rows.item(0));
            }else{
                defered.resolve(null);
            }
        }, function(err){
            defered.reject(err);
        });
        return promise; 
    };
    
    
    var _infoColuna = function (tabela,coluna) {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "PRAGMA table_info("+tabela+")";
        var retorno = false;
        var linha = {};
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                linha = consulta.rows.item(i);
                if(linha.name === coluna){
                    retorno = linha;
                }
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise; 
    };
    
    var _adicionaColuna = function (tabela,coluna,tipo, notNull) {
        var not_null = parseInt(notNull) === 0 ? "NULL" : "NOT NULL";
        var valorDefault = '';
        if(not_null === "NOT NULL"){
            valorDefault = tipo === 'integer' ? "DEFAULT 0" : "DEFAULT ''";
        }
        var query = "ALTER TABLE "+tabela+" ADD COLUMN "+coluna+" "+tipo+" "+not_null+" "+valorDefault;
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    var _adicionaColunaSeNaoExiste = function (tabela, coluna, tipo, notNull) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(notNull === undefined){
            notNull = 0;
        }
        _infoColuna(tabela,coluna).then(function(existe){
            if(existe === false){
                defered.resolve(_adicionaColuna(tabela, coluna, tipo, notNull));
            }else{
                defered.resolve(existe);
            }
        }, function(err){
            defered.reject(err);
        });
        return promise; 
    };
    
    var _findSync = function (id, tabela) {
//        console.log('id_findSync');
//        console.log(id);
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT * FROM "+tabela+" WHERE idApp = ?";
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function(consulta){
//            console.log(consulta.rows);
            if(consulta.rows.length > 0){
//                console.log('quantidade consulta');
//                console.log(consulta.rows.length);
                var resultado = consulta.rows.item(0);
                defered.resolve(resultado);
            }else{
                defered.resolve(_find(id, tabela));
            }
        }, function(err){
            defered.reject(err);
        });
        return promise; 
    };
    
    var tabelasQueSincronizam = {
        'atos_atendimento'              : true,
        'atos'                          : true,
        'atdc_ocorrencia'               : true,
        'atdc_ocorrencia_encerramento'  : true,
        'atdc_ocorrencia_produto'       : true,
        'atos_atividade'                : true,
        'atos_servico'                  : true,
        'atdc_ocorrencia_log'           : true,
        'atdc_ocorrencia_interacao'     : true,
        'atos_imagem'                   : true,
        'itadau_usuario'                : true,
        'itadau_usuario_localizacao'    : true
    };
    
    var _update = function (tabela, id, dados, insertOrUpdate, buscaSync) {
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        var dataAlteracao = $rootScope.converteObjetoDataPost(timeNow);
//        if(tabela === 'atos_atividade'){
//            console.log('dados');
//            console.log(dados);
//        } 
        if(!insertOrUpdate){
//            console.log("adicionou dataAlteracao e sincronizado");
            dados.dataAlteracao = dados.dataAlteracao != null ? dados.dataAlteracao : dataAlteracao;
            dados.sincronizado = dados.sincronizado != null ? dados.sincronizado : 0;
        }
        var campos = [];
        var query = "UPDATE "+tabela+" SET ";
        
        angular.forEach(dados, function (valor,campo){
            if(tabela === 'itadau_usuario' && campo === 'empresaLogin'){
                return;
            }
//            query+= campo+' = "'+_trataValorSalvar(valor)+'", ';
            query+= campo+' = ?, ';
            campos.push(_trataValorSalvar(valor));
        });
        query = query.substring(0, query.length-2);
        query += " WHERE id = ? ";
        campos.push(id);
        
        if(dados.sincronizado != undefined && buscaSync){
            query += " AND sincronizado = 1 ";
            if(tabelasQueSincronizam[tabela] != undefined){
                query += " AND ( dataSincronizacao IS NULL OR ((julianday(DateTime('now', 'localtime')) - julianday(dataSincronizacao)) * 1440) > 10) ";
            }
        }
//        if(tabela === 'atos_atividade'){
//            console.log(query);
//            console.log("id = " + id);
//        }
        
        $cordovaSQLite.execute($rootScope.db, query, campos).then(function(consulta){
            defered.resolve(_find(id, tabela));
        }, function(err){
            defered.reject(err);
            console.log(query);
            console.log("id = " + id);
            console.error(err);
        });
        return promise;
    };
    
    var _delete = function (tabela, id) {
//            console.log(tabela);
//            console.log(id);
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        var dataAlteracao = $rootScope.converteObjetoDataPost(timeNow);
        
        _find(id,tabela).then(function(consulta){
//            console.log(tabela);
//            console.log(id);
//            console.log(consulta);
            if(consulta.idAPI == null && (consulta.sincronizado == 0 || consulta.sincronizado == null)){ 
                defered.resolve(_deleteFisico(tabela, id));
            }else{
                var query = "UPDATE "+tabela+" SET excluido = 1, dataAlteracao = '"+dataAlteracao+"',  sincronizado = 0 WHERE id = ? ";
                
                $cordovaSQLite.execute($rootScope.db, query,[id]).then(function(consulta){
                    defered.resolve(_find(id, tabela));
                }, function(err){
                    defered.reject(err);
                    console.log(query);
                    console.log("id = " + id);
                    console.error(err);
                });
            }
        }, function(err){
            defered.reject(err);
            console.error(err);
        });
        
        return promise;
    };
    
    var _deleteGroup = function (tabela, registros, indice) {
        if(indice === undefined){
            indice = 0;
        }
        var defered = $q.defer();
        var promise = defered.promise;
        var id = registros[indice].id;
        indice++;
        
        _delete(tabela, id).then(function (data) {
            if(indice < registros.length){
                defered.resolve(_deleteGroup(tabela, registros, indice));
            }else{
                defered.resolve(registros);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _deleteFisico = function (tabela, id) {
        var defered = $q.defer();
        var promise = defered.promise;
        
        var query = "DELETE FROM "+tabela+" WHERE id = ? ";
        
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function(consulta){
            defered.resolve(_find(id, tabela));
        }, function(err){
            defered.reject(err);
            console.log(query);
            console.log("id = " + id);
            console.error(err);
        });
        return promise;
    };
    
    var _resetarTabela = function (tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        
        var query = "DELETE FROM "+tabela;
        
        if(tabelasQueSincronizam[tabela] != undefined){
            query += " WHERE sincronizado = 1";
        }
        
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            defered.resolve(consulta);
        }, function(err){
            defered.reject(err);
            console.log(query);
            console.error(err);
        });
        return promise;
    };
    
    var _trataValorSalvar = function (valor) {
        var retorno;
        if (typeof valor !== "object") {
            retorno = valor;
        }else
        if (valor && valor.hasOwnProperty('date') &&
                valor.hasOwnProperty('timezone') &&
                valor.hasOwnProperty('timezone_type')) {
            retorno = valor.date;
        }else{
            retorno = valor;
        }
        if(typeof retorno === "string"){
            return retorno.replace(/"/g,"'");
        }else{
            return retorno;
        }
    };
    
    var _insert = function (tabela, dados) {
        var defered = $q.defer();
        var promise = defered.promise;
        var campos = [];
        var valores = [];
        var interrogacoes = [];
//        console.log(tabela);
//        console.log(dados);
//        _iniciaTabela(); 
        angular.forEach(dados, function (valor,campo){
            campos.push(campo);
            valores.push(_trataValorSalvar(valor));
            interrogacoes.push('?');
        });
        var query = 'INSERT INTO '+tabela+' ('+campos.join(',')+') VALUES ('+interrogacoes.join(',')+')'; 
        $cordovaSQLite.execute($rootScope.db, query, valores).then(function(res) {
            _find(res.insertId, tabela).then(function(find) {
                if(find.idApp !== undefined && find.idApp == null){
                    find.idApp = find.id;
                    _update(tabela, find.id, find, true).then(function(res) {
                        defered.resolve(find);
                    }, function (err) {
                        defered.reject(err);
                    });
                }else{
                    defered.resolve(find);
                }
            }, function (err) {
                console.log(query);
                console.log(valores);
                console.error(err);
                defered.reject(err);
            });
        }, function (err) {
            console.log(query);
            console.log(valores);
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    function _insertOrUpdate (tabela, id, registro, buscaSync) {
        var defered = $q.defer();
        var promise = defered.promise;
//        console.log(tabela);
//        console.log(registro);
//        console.log(id); 
        _find(id,tabela).then(function(data){
            if(data !== null){
                defered.resolve(_update(tabela, data.id, registro, true, buscaSync));
            }else{
                defered.resolve(_insert(tabela, registro));
            }
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    function _getRegistrosParaSincronizar (tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = [];
        var query = "SELECT * FROM "+tabela+" WHERE sincronizado = 0 OR sincronizado IS NULL";
//        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                registro.push(row);
            }
//            console.log('tabela');
//            console.log(query);
//            console.log('registro');
//            console.log(registro);
            defered.resolve(registro);
        }, function (err) {
            defered.reject(err);
        });

        return promise;
    }
    
    var _trataRegistros = function (registros) {
//        console.log(registros);
        angular.forEach(registros, function (registro, indice1){
            angular.forEach(registro, function (valor,indice2){
//                console.log(valor);
                if(valor === 'null'){
                    registros[indice1][indice2] = null;
                }
            });
        });
//        console.log(registros);
//        return promise;
    };
    
    function _enviaRegistros (registros, tabela, url) {
        
        $rootScope.erroEnviando = $rootScope.erroEnviando !== undefined ? $rootScope.erroEnviando : [];
        var defered = $q.defer();
        var promise = defered.promise;
        _trataRegistros(registros);
//        console.log('registros');
//        console.log(registros);
//        _find(105,tabela).then(function(data){
//            console.log(data);
//            if(data){
//                console.log(data.length);
//                console.log(Object.keys(data).length);
//            }
//            defered.resolve(data);
//        }, function (err) {
//            defered.reject(err);
//        });
//        _iniciaTabela(); 
//        console.log('tabela');
//        console.log(tabela);
        if(url === undefined){
            url = '/'+tabela.replace(/_/g,'-')+'?sync=enviar';
        }
//        console.log('url');
//        console.log(url);
//        console.log('registros');
//        console.log(registros);
//        console.log(registros.length);
        if(registros.length > 0){
            var valido = new Date();
            valido.setDate(valido.getDate() + (1/(24*60)));
            $window.localStorage[_getNomeLocalStorage(tabela)+'BloqueioAte'] = new Date(valido); 
            
            if(tabela == 'atos_imagem'){
                defered.resolve(_enviaRegistrosArquivos(registros, tabela, url, 0));
            }else{
                $http.post($rootScope.configEmpresa.baseUrl + url, registros).then(function (data) {
    //                console.log(data.data); 
        //            defered.resolve(data.data);
                    var registros = [];                    
                    try {
                        angular.forEach(data.data, function (valor,indice){
                            if(!(angular.isUndefined(valor.id))){
                                registros.push(valor);
                            }
                        });
                        if(registros.length > 0){
                            _retiraRegistroSincronizacao(registros, 0, tabela).then(function (data) {
                                defered.resolve(data);
                            }, function (err) {
                                console.log('err');
                                console.log(err);
                                $rootScope.erroEnviando.push(err);
                                $rootScope.geraLog(err, new Error());
                                defered.resolve({erro : true, conteudo : err});
                            });
                        }else{
                            $rootScope.erroEnviando.push(data);
                            $rootScope.geraLog(data, new Error());
                            defered.resolve({erro : true, conteudo : data});
                        }
                    } catch (err) {
                        console.log('err');
                        console.log(err);
                        $rootScope.erroEnviando.push(err);
                        $rootScope.geraLog(err, new Error());
                        defered.resolve({erro : true, conteudo : err});
                    }
                }, function (err) {
                    console.log('err');
                    console.log(err);
                    $rootScope.erroEnviando.push(err);
                    $rootScope.geraLog(err, new Error());
                    defered.resolve({erro : true, conteudo : err});
                });
            }
        }else{
            defered.resolve({});
        }
//        console.log(JSON.stringify(registros));
        return promise;
    }
    
    function _enviaRegistrosArquivos (registros, tabela, url, indice) {
        var defered = $q.defer();
        var promise = defered.promise;        
        if(url === undefined){
            url = '/'+tabela.replace(/_/g,'-')+'?sync=enviar';
        }
        if(registros.length > 0){
                var registro = registros[indice];
                var filepath = $rootScope.caminhoFotos + registro.imagem;
//                indice++;
                
                // Não necessariamente executará esta verificação pois não é sincrono mas com as alterações dificilmente precisará fazer essa verificação
            if(registro.excluido === 1){
                filepath = $rootScope.arquivoNaoEncontrado;
            }else{
                $cordovaFile.checkFile($rootScope.caminhoFotos,registro.imagem).then(function (success) {
                }, function (error) {
                    console.log(filepath);
//                    filepath = $rootScope.arquivoNaoEncontrado;
//                    console.log(filepath);
                });
            }
                
                var token = $localStorage.getObject('token');
                var options = new FileUploadOptions();
                
                var options = {
                    fileKey: "arquivo",
                    httpMethod: "POST",
//                    mimeType: "image/jpeg",
                    params: registro,
                    transformRequest:angular.identity,
//                    chunkedMode: true,
                    headers: {
                        "Authorization": token.token_type + " " + token.access_token,
                        'Accept' : '*/*',
                        'Content-Type':undefined
                    }
                };
                
                $cordovaFileTransfer.upload(encodeURI($rootScope.configEmpresa.baseUrl + url), filepath, options, true).then(function (data) {
//                    console.log(data);
//                    console.log(data.response);
//                    console.log(JSON.parse(data.response));
        //            defered.resolve(data.data); 
                    var registros2 = [];
                    var retornoErro = {};
                    try {
                        var retorno = JSON.parse(data.response);
                        if(retorno.erro > 0){
                            retornoErro = retorno.erro;
                        }else{
                            angular.forEach(JSON.parse(data.response), function (valor,index){
                                if(!(angular.isUndefined(valor.id))){
                                    registros2.push(valor);
                                }
                            });
                        }
                    }
                    catch (erro) { 
                        console.log(data);
                        retornoErro = erro;
                        console.log(erro);
                    }
                    if(registros2.length > 0){
                        _retiraRegistroSincronizacao(registros2, 0, tabela).then(function (data) {
                            if(indice < registros.length){
                                _getRegistrosParaSincronizar(tabela).then(function (data) {
                                    _trataRegistros(data);
                                    defered.resolve(_enviaRegistrosArquivos(data, tabela, url, 0));
                                }, function (err) {
                                    console.log('err');
                                    console.log(err);
                                    $rootScope.erroEnviando.push(err);
                                    $rootScope.geraLog(err, new Error());
                                    defered.resolve({erro : true, conteudo : err});
                                });
                            }else{
                                console.log(data);
                                defered.resolve(data);
                            }
                        }, function (err) {
                            console.log('err');
                            console.log(err);
                            $rootScope.erroEnviando.push(err);
                            $rootScope.geraLog(err, new Error());
                            defered.resolve({erro : true, conteudo : err});
                        });
                    }else{
                        retornoErro.retornoAPI = data;
                        $rootScope.erroEnviando.push(retornoErro);
                        $rootScope.geraLog(retornoErro, new Error());
                        defered.resolve({erro : true, conteudo : retornoErro});
                    }
                }, function (err) {
                    console.log('err');
                    console.log(err);
                    $rootScope.erroEnviando.push(err);
                    $rootScope.geraLog(err, new Error());
                    defered.resolve({erro : true, conteudo : err});
                });
//            }
//            defered.reject({});
        }else{
            defered.resolve({});
        }
//        console.log(JSON.stringify(registros));
        return promise;
    }
    
    var _retiraRegistroSincronizacao = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = retorno[indice];
        var timeNow = new Date();
        var dataAlteracao = $rootScope.converteObjetoDataPost(timeNow);
        
            
        indice++;
//        console.log('retorno');
//        console.log(retorno);
//        console.log('registro');
//        console.log(registro);
        //caso id inserido na API for diferente do aplicativo
        if(!(angular.isUndefined(registro.excluido)) && registro.excluido == 1){
//            console.log('exclui');
            _deleteFisico(tabela, registro.id).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_retiraRegistroSincronizacao(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else
        if(registro.id != registro.idApp){
//            console.log("passou");
            //busca se existe no aplicativo o novo id
            registro.dataSincronizacao = dataAlteracao;
            _retiraRegistroSincronizacaoConflito(registro, tabela).then(function (data) {
                if(indice < retorno.length){
//                    console.log(data);
                    defered.resolve(_retiraRegistroSincronizacao(retorno, indice, tabela));
                }else{
//                    console.log(data);
                    defered.resolve(retorno);
                }
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
            
            
        }else{
//            console.log('altera2');
//            console.log(registro);
//            console.log(registro.id);
//            console.log(registro.idApp);
            var query = "UPDATE "+tabela+" set sincronizado = 1, idAPI = "+registro.id+", dataSincronizacao = '"+dataAlteracao+"' WHERE id = ?";
            
            if($rootScope.dataEnviando !== null){
                query += " AND ( dataAlteracao IS NULL OR dataAlteracao < '"+$rootScope.dataEnviando+"') ";
            }
            
            if(tabela === 'atos_imagem'){
                _atualizaNomeImagem(registro,tabela).then(function(data){
                    $cordovaSQLite.execute($rootScope.db, query,[registro.id]).then(function (data) {
        //                console.log(data);
        //                console.log("retorno.length");
        //                console.log(retorno.length);
                        if(indice < retorno.length){
                            //Provavelmente o erro aconteceu aqui, verificar depois.
                            defered.resolve(_retiraRegistroSincronizacao(retorno, indice, tabela));
                        }else{
                            defered.resolve(retorno);
                        }
                    }, function (err) {
                        console.log(query);
                        console.log("id = " + registro.id);
                        console.error(err);
                        defered.reject(err);
                    });
                }, function (err) {
                    defered.reject(err);
                });
            }else{
                $cordovaSQLite.execute($rootScope.db, query,[registro.id]).then(function (data) {
    //                console.log(data);
    //                console.log("retorno.length");
    //                console.log(retorno.length);
                    if(indice < retorno.length){
                        defered.resolve(_retiraRegistroSincronizacao(retorno, indice, tabela));
                    }else{
                        defered.resolve(retorno);
                    }
                }, function (err) {
                    console.log(query);
                    console.log("id = " + registro.id);
                    console.error(err);
                    defered.reject(err);
                });
            }
            
        }
        
        
        return promise;
    };
    
    var _atualizaNomeImagem = function (registro, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        
        _find(registro.idApp,tabela).then(function(data){
//            console.log(data); 
            if(registro == null || data == null || registro.imagem == undefined || data.imagem == registro.imagem){
//                console.log('igual imagem');
                defered.resolve(registro);
            }else{
                var atualiza = {
                    imagem : registro.imagem,
                    imagemData : null
                };
                if('dataAlteracao' in data){
                    atualiza.dataAlteracao = data.dataAlteracao;
                }
//                var novoNome = "os_"+data.atos+"("+data.id+")";
//                console.log("Copying from : " + $rootScope.caminhoFotos + data.imagem);
//                console.log("Copying to : " + $rootScope.caminhoFotos + registro.imagem);
                $cordovaFile.moveFile($rootScope.caminhoFotos, data.imagem, $rootScope.caminhoFotos, registro.imagem).then(function(success) {
    //                $scope.fileName = cordova.file.dataDirectory + sourceFileName;
//                    console.log('success');
//                    console.log(success);
                }, function(error) {
                    console.error(error);
                });
                defered.resolve(_update(tabela, data.id, atualiza));
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _retiraRegistroSincronizacaoConflito = function (registro, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        //busca se existe no aplicativo o novo id
//        console.log('registro');
//        console.log(registro);
        _find(registro.id,tabela).then(function(data){
            var atualizar = angular.copy(registro);
            if(data){
//                console.log('data');
//                console.log(data);
                var copia = angular.copy(data);
                delete copia.id;
                if(copia.idApp === undefined || copia.idApp == null){
                    copia.idApp = data.id;
                }
                //se existir o id duplica o registro existente
                _insert(tabela, copia).then(function(data){
                    //exclui o registro orignal dulpicado
                    _deleteFisico(tabela, registro.id).then(function(data){
                        //atualiza o registro que foi sincronizado
//                        console.log('atualizar');
//                        console.log(atualizar);
                        atualizar.sincronizado = 1;
                        defered.resolve(_atualizaConflito(tabela, registro.idApp, atualizar));
                    }, function(err){
                        console.error(err); 
                        defered.reject(err);
                    });
                }, function(err){
                    console.error(err); 
                    defered.reject(err);
                });
            }else{
//                console.log('registro.idApp');
//                console.log(registro.idApp);
                atualizar.sincronizado = 1;
                defered.resolve(_atualizaConflito(tabela, registro.idApp, atualizar));
            }
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        
        return promise;
    };
    
    
    function _atualizaConflito (tabela, id, registro) {
        var defered = $q.defer();
        var promise = defered.promise;
//        console.log('idConflito');
//        console.log(id);
//        console.log(registro);
        //busca o id do registro a ser atualizado primeiro pelo campo idApp depois pelo id
        _findSync(id,tabela).then(function(data){
//            console.log(data.id);
//            console.log(registro);
            registro.idApp = data.id;
            if(tabela === 'atos_imagem'){
                _atualizaNomeImagem(registro,tabela).then(function(data){
                    if(data == null){
                        defered.resolve(registro);
                    }else{
                        defered.resolve(_update(tabela, data.id, registro));
                    }
                }, function (err) {
                    defered.reject(err);
                });
            }else{
                defered.resolve(_update(tabela, data.id, registro));
            }
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
//     var _getSincronizacao = function (retorno, indice, tabela) {
//        var defered = $q.defer();
//        var promise = defered.promise;
//        var registro = retorno[indice];
//        indice++;
////        console.log('retorno');
////        console.log(retorno);
////        console.log('registro');
////        console.log(registro);
//        //caso id inserido na API for diferente do aplicativo
//        if(!(angular.isUndefined(registro.excluido)) && registro.excluido == 1){
//            _deleteFisico(tabela, registro.id).then(function (data) {
//                if(indice < retorno.length){ 
//                    defered.resolve(_retiraRegistroSincronizacao(retorno, indice, tabela));
//                }else{
//                    defered.resolve(retorno);
//                }
//            }, function(err){
//                console.error(err); 
//                defered.reject(err);
//            });
//        }else
//        if(registro.id != registro.idApp){
////            console.log("passou");
//            //busca se existe no aplicativo o novo id
//            _retiraRegistroSincronizacaoConflito(registro, tabela).then(function (data) {
//                if(indice < retorno.length){
//                    defered.resolve(_retiraRegistroSincronizacao(retorno, indice, tabela));
//                }else{
//                    defered.resolve(retorno);
//                }
//            }, function(err){
//                console.error(err); 
//                defered.reject(err);
//            });
//            
//            
//        }else{
//            var query = "UPDATE "+tabela+" set sincronizado = 1 WHERE id = ?";
//            
//            $cordovaSQLite.execute($rootScope.db, query,[registro.id]).then(function (data) {
////                console.log(data);
////                console.log("retorno.length");
////                console.log(retorno.length);
//                if(indice < retorno.length){
//                    defered.resolve(_retiraRegistroSincronizacao(retorno, indice, tabela));
//                }else{
//                    defered.resolve(retorno);
//                }
//            }, function (err) {
//                console.log(query);
//                console.log("id = " + registro.id);
//                console.error(err);
//                defered.reject(err);
//            });
//        }
//        
//        
//        return promise;
//    };

//    var _buscaRegistrosAPI = function (tabela) {
//        var defered = $q.defer();
//        var promise = defered.promise;
//        _getRegistrosAPI(tabela).success(function (data) {
//            defered.resolve(_setRegistrosAPI(data));
//        }).error(function (err) {
//            defered.reject(err);
//        });
//        return promise;
//    };
    
    var _getRegistrosAPI = function (tabela, data) {
        var defered = $q.defer();
        var promise = defered.promise;
        data = data != undefined && data != null ? data : null;
        
        var tempo = data && data != null && data != 'null' ? '&tempo='+$rootScope.tempoBusca(data) : '';
        
        var url = '/'+tabela.replace(/_/g,'-')+'?sync=busca'+tempo;
        
        $http.get($rootScope.configEmpresa.baseUrl + url).success(function (data) {
//            console.log('tabela');
//            console.log(tabela);
            if(data._embedded !== undefined && data._embedded[tabela] !== undefined){
                defered.resolve(_setRegistrosAPI(data._embedded[tabela], tabela));
            }else{
                defered.resolve({});
            }
        }).error(function (err) {
            defered.reject(err);
        });
        return promise;
    };
    
    var _setRegistrosAPI = function (registros, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        _setRegistrosAPI2(registros, 0, tabela).then(function(retorno){
            var valido = new Date();
            valido.setDate(valido.getDate() + _getDiasValidos(tabela));
            var camelCase = _getNomeLocalStorage(tabela);
            console.log(camelCase);
            $window.localStorage[camelCase+'Valido'] = new Date(valido);
            $window.localStorage[camelCase+'Atualizado'] = new Date();
            $window.localStorage[camelCase+'Qtde'] = Object.keys(registros).length;
            defered.resolve(retorno);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    var _getNomeLocalStorage = function (tabela){
        if(tabela === 'atdc'){
            return 'cliente';
        }else if(tabela === 'atdc_grupo_defeito'){
            return 'defeito';
        }else if(tabela === 'atdc_grupo_defeito_procedimento'){
            return 'defeitoProcedimento';
        }else if(tabela === 'atdc_grupo'){
            return 'grupoDefeito';
        }else if(tabela === 'atdb_produto'){
            return 'produto';
        }else if(tabela === 'atdb_produto_ajuda'){
            return 'produtoAjuda';
        }else if(tabela === 'atos_atendimento'){
            return 'atendimento';
        }else{
            return $rootScope.toCamelCase(tabela);
        }
    };
    var _getDiasValidos = function (tabela){
        if(tabela === 'atos_status'){
            return 1;
        }else{
            return 15;
        }
    };
    
    var _setRegistrosAPI2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = _trataRegistroAPI(tabela, retorno[indice]);
            indice++;
            _insertOrUpdate(tabela, registro.id, registro, true).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setRegistrosAPI2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };    
    
    var _trataRegistroAPI = function (tabela, registro) {
        if(tabela === 'atdc'){
            delete registro._links;
            delete registro.status;
            delete registro.dataCadastro;
            delete registro.at;
            delete registro.sincronizado;
        }
        if(tabela === 'atdc_grupo_defeito'){
            delete registro._links;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
        }
        if(tabela === 'atdc_grupo_defeito_procedimento'){
            delete registro._links;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
        }
        if(tabela === 'atdc_grupo'){
            delete registro._links;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
            delete registro._embedded;
        }
        if(tabela === 'atdb_produto'){
            delete registro._links;
        }
        if(tabela === 'atdb_servico'){
            delete registro._links;
        }
        if(tabela === 'at'){
            delete registro._links;
        }
        if(tabela === 'atdb_produto_ajuda'){
            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
        }
        if(tabela === 'atdb_produto_tipo'){
            delete registro._links;
        }
        if(tabela === 'atdc_endereco'){
            delete registro._links;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
            delete registro._embedded;
        }
        if(tabela === 'atdc_ocorrencia_anexo'){
            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
            registro.data = $rootScope.trataDataNull(registro.data);
        }
        if(tabela === 'atdc_ocorrencia_expositor'){
            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
            registro.dataAtualizacao = $rootScope.trataDataNull(registro.dataAtualizacao);
        }
        if(tabela === 'atdc_ocorrencia_encerramento'){
            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
            registro.data = $rootScope.trataDataNull(registro.data);
        }
        if(tabela === 'atdc_ocorrencia_interacao'){
            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
            registro.data = $rootScope.trataDataNull(registro.data);
        }
        if(tabela === 'atdc_ocorrencia_log'){
            delete registro._links;
            registro.sincronizado = 1;
    //        delete registro.dataAlteracao;
    //        delete registro._embedded;
        }
        if(tabela === 'atdc_ocorrencia_produto'){
            delete registro._links;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
        }
        if(tabela === 'atos'){
            delete registro._links;
            registro.abertura = $rootScope.trataDataNull(registro.abertura);
            registro.encerramento = $rootScope.trataDataNull(registro.encerramento);
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
        }
        if(tabela === 'atos_atividade'){
            delete registro._links;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
        }
        if(tabela === 'atos_servico'){
            delete registro._links;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
        }
        if(tabela === 'atos_atividade_tipo'){
            delete registro._links;
            delete registro.at;
        }
        if(tabela === 'atos_imagem'){
            delete registro._links;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
            registro.data = $rootScope.trataDataNull(registro.data);
        }
        if(tabela === 'atos_status'){
            delete registro._links;
            delete registro.at;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
        }
        if(tabela === 'atos_avaliacao'){
            delete registro._links;
//            delete registro.at;
//            delete registro.dataAlteracao;
//            delete registro.sincronizado;
        }
        if(tabela === 'itadau_usuario_localizacao'){
            delete registro._links;
            delete registro.at;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
        }
        if(tabela === 'itadau_usuario'){
            delete registro._links;
        }
        if(tabela === 'atos_atendimento'){
            delete registro._links;
            delete registro.status;
            delete registro.abertura;
            delete registro.encerramento;
            delete registro.distancia;
    //        delete registro['$$hashKey'];
            registro.dataAgendamento = $rootScope.trataDataNull(registro.dataAgendamento);
            registro.dataInicio = $rootScope.trataDataNull(registro.dataInicio);
            registro.dataFim = $rootScope.trataDataNull(registro.dataFim);
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
        }
        if(tabela === 'atdc_ocorrencia'){
            
            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
        }
        return registro;
    };
    
    
    return {
        adicionaColunaSeNaoExiste: _adicionaColunaSeNaoExiste,
        getRegistrosAPI: _getRegistrosAPI,
        insertOrUpdate: _insertOrUpdate,
        deleteGroup: _deleteGroup,
        getRegistrosParaSincronizar: _getRegistrosParaSincronizar,
        enviaRegistros: _enviaRegistros,
        resetarTabela : _resetarTabela,
        fetchAll: _fetchAll,
        findCampo: _findCampo,
        find: _find,
        update: _update,
        delete: _delete,
        insert: _insert
//        apagaTabela: _apagaTabela
    };
});