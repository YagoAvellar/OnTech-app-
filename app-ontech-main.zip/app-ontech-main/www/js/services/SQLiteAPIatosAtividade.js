angular.module("starter").factory("SQLiteAPIatosAtividade", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    SQLiteAPIAbstract, SQLiteAPIatdcOcorrenciaLog) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_atividade").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_atividade");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atos_atividade \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atos integer, \n\
            atdcOcorrencia integer, \n\
            atosStatus integer, \n\
            atosAtividadeTipo integer, \n\
            atdcOcorrenciaProduto integer, \n\
            itadauUsuario integer, \n\
            dataInclusao datetime, \n\
            dataInicio datetime, \n\
            dataFim datetime, \n\
            laudoTecnico text, \n\
            atosStatusDescricao text, \n\
            atosAtividadeTipoDescricao text, \n\
            observacao text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            excluido integer, \n\
            sincronizado integer)");
    };
    
    var _buscaAtosAtividades = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atos_atividade', data);
    };
    
    var _getAtosAtividades = function (atos) {
        _iniciaTabela(); 
        var query = "SELECT A.*, B.descricao AS atosStatusDescricao FROM atos_atividade A JOIN atos_status B ON B.ID = A.atosStatus";
        if(atos != undefined){
            query+= " WHERE atos = "+atos+" AND (excluido IS NULL OR excluido <> 1) ";
        }
//        console.log(query);
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtosAtividades2 = function (atos) {
        var defered = $q.defer();
        var promise = defered.promise;
        
        var query = "SELECT A.*, B.descricao AS atosStatusDescricao FROM atos_atividade A JOIN atos_status B ON B.ID = A.atosStatus";
        if(atos != undefined){
            query+= " WHERE atos = "+atos+" AND (excluido IS NULL OR excluido <> 1) ";
        }
        var atividades = {};
        $cordovaSQLite.execute($rootScope.db, query).then(function(atosAtividades){
            if(atosAtividades.rows.length > 0){
                for (var i = 0; i < atosAtividades.rows.length; i++) {
                    var row = atosAtividades.rows.item(i);
                    _retornaObjetoCompleto(row).then(function(data){
                        atividades[data.id] = data; 
                        if(atosAtividades.rows.length <= i+1 ){
                            defered.resolve(atividades);
                        }
                    }, function(err){
                        console.error(err); 
                        defered.reject(err);
                    });
                }
            }else{
                defered.resolve(atividades);
            }
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    
    
    
    var _deleteAtosAtividades = function () {
        _iniciaTabela();
        var query = "DELETE FROM atos_atividade";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtosAtividades = function (atosAtividades) {
        _iniciaTabela();
////        _deleteAtosAtividades();
//        var query = "INSERT INTO atos_atividade ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        atos, \n\
//                        atdcOcorrencia, \n\
//                        atosStatus, \n\
//                        atosAtividadeTipo, \n\
//                        atdcOcorrenciaProduto, \n\
//                        itadauUsuario, \n\
//                        dataInclusao, \n\
//                        dataInicio, \n\
//                        dataFim, \n\
//                        laudoTecnico, \n\
//                        atosStatusDescricao, \n\
//                        atosAtividadeTipoDescricao, \n\
//                        observacao,\n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"; 
//        angular.forEach(atosAtividades, function (atosAtividade,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atosAtividade.id,
//                atosAtividade.id,
//                atosAtividade.atos,
//                atosAtividade.atdcOcorrencia,
//                atosAtividade.atosStatus,
//                atosAtividade.atosAtividadeTipo,
//                atosAtividade.atdcOcorrenciaProduto,
//                atosAtividade.itadauUsuario,
//                $rootScope.trataDataNull(atosAtividade.dataInclusao),
//                $rootScope.trataDataNull(atosAtividade.dataInicio),
//                $rootScope.trataDataNull(atosAtividade.dataFim),
//                atosAtividade.laudoTecnico,
//                atosAtividade.atosStatusDescricao,
//                atosAtividade.atosAtividadeTipoDescricao,
//                atosAtividade.observacao,
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) { 
//              console.error(err);
//            });
//        });
        _setAtosAtividades2(atosAtividades, 0, 'atos_atividade').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atosAtividadeValido'] = new Date(valido);
            $window.localStorage['atosAtividadeAtualizado'] = new Date();
            $window.localStorage['atosAtividadeQtde'] = Object.keys(atosAtividades).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    
    var _setAtosAtividades2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
    //        delete registro.status;
    //        delete registro.abertura;
    //        delete registro.encerramento;
    //        delete registro.distancia;
    //        registro.dataAgendamento = $rootScope.trataDataNull(registro.dataAgendamento);
    //        registro.dataInicio = $rootScope.trataDataNull(registro.dataInicio);
    //        registro.dataFim = $rootScope.trataDataNull(registro.dataFim);

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAtosAtividades2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    var _atualizaAtividade = function (id, atividadeEditar) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atividade = {
            'atosAtividadeTipo'     : atividadeEditar.atosAtividadeTipo.id,
            'atdcOcorrenciaProduto' : atividadeEditar.atdcOcorrenciaProduto != undefined ? atividadeEditar.atdcOcorrenciaProduto.id : null,
            'observacao'            : atividadeEditar.observacao
        };
//        console.log(atividadeEditar);
        SQLiteAPIAbstract.update('atos_atividade', id, atividade).then(function(data){
            defered.resolve(_retornaObjetoCompleto(data));
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    };
    var _adicionaAtividade = function (atividadeEditar) {
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        var atividade = {
            'atos'                  : atividadeEditar.atos,
            'atdcOcorrencia'        : atividadeEditar.atdcOcorrencia != undefined ? atividadeEditar.atdcOcorrencia : null,
            'atosAtividadeTipo'     : atividadeEditar.atosAtividadeTipo.id,
            'atdcOcorrenciaProduto' : atividadeEditar.atdcOcorrenciaProduto != undefined ? atividadeEditar.atdcOcorrenciaProduto.id : null,
            'dataInclusao'          : $rootScope.converteObjetoDataPost(timeNow),
            'atosStatus'            : 8,
            'observacao'            : atividadeEditar.observacao
        };
//        
//        console.log(atividade);
        SQLiteAPIAbstract.insert('atos_atividade', atividade).then(function(data){
            defered.resolve(_retornaObjetoCompleto(data));
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    }; 
    
    var _retornaObjetoCompleto = function (atosAtividade) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = atosAtividade;
        SQLiteAPIAbstract.find(atosAtividade.atdcOcorrenciaProduto,'atdc_ocorrencia_produto').then(function(data){
            retorno.atdcOcorrenciaProduto = data;
            return SQLiteAPIAbstract.find(atosAtividade.atosAtividadeTipo,'atos_atividade_tipo');
        }).then(function (data) {
            retorno.atosAtividadeTipo = data;
            defered.resolve(retorno);
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    
    var _realizarCheckinAtividade = function (id_atividade) {
//        console.log(id_atividade);
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        var dataInicio = $rootScope.converteObjetoDataPost(timeNow);        
        var dados = {
            'dataInicio' : dataInicio,
            'dataAlteracao' : dataInicio,
            'sincronizado' : 0,
            'itadauUsuario' : $rootScope.usuarioLogado.id,
            'atosStatus' : 9
        };
//        console.log(dados);
        
        SQLiteAPIAbstract.update('atos_atividade', id_atividade, dados).then(function(data){
//            console.log(data);
            if(data === null){
                defered.reject("Ocorreu um erro ao realizar o checkin da atividade");
            }else{
                defered.resolve(_retornaObjetoCompleto(data));
            }
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    
    var _finalizarAtividade = function (atividade) {
//        console.log(atividade);
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        var dataFim = $rootScope.converteObjetoDataPost(timeNow);        
        var dados = {
            'dataFim' : dataFim,
            'dataAlteracao' : dataFim,
            'sincronizado' : 0,
            'atosStatus' : 10,
            'itadauUsuario' : $rootScope.usuarioLogado.id,
            'laudoTecnico' : atividade.laudoTecnico
        };
//        console.log(atividade);
//        console.log(dados);
        
        SQLiteAPIAbstract.update('atos_atividade', atividade.id, dados).then(function(data){
//            console.log(data);
            
//            SQLiteAPIatdcOcorrenciaLog.add(atividade.atdcOcorrencia,'encAtividade', '');
             if(data === null){
                defered.reject("Ocorreu um erro ao finalizar a atividade");
            }else{
                defered.resolve(_retornaObjetoCompleto(data));
            }
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    var _finalizarAtividades = function (checkout) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atosAtividades = [];
        var dataInicio = angular.copy(checkout.dataInicio);
        
        _getAtosAtividades(checkout.atos).then(function(data){
            if(data.rows.length > 0){
                for (var i = 0; i < data.rows.length; i++) {
                    var row = data.rows.item(i);
                    if(row.laudoTecnico == null){
                        row.laudoTecnico = checkout.observacao;
                    }
                    atosAtividades.push(row);
                }
                defered.resolve(_finalizar(atosAtividades,0,dataInicio));
            }else{
                defered.resolve(atosAtividades);
            }
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _finalizar = function (atosAtividades,indice,dataInicio) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atosAtividade = atosAtividades[indice];
        var timeNow = new Date();
        var dataFim = $rootScope.converteObjetoDataPost(timeNow);
        indice++;
        atosAtividade.dataInicio = atosAtividade.dataInicio != null ? atosAtividade.dataInicio : dataInicio;
        atosAtividade.dataFim = atosAtividade.dataFim != null && atosAtividade.dataFim != '' ? atosAtividade.dataFim : dataFim;
        atosAtividade.atosStatus = 10;
        atosAtividade.dataAlteracao = dataFim;
        atosAtividade.sincronizado = 0;
        atosAtividade.itadauUsuario = $rootScope.usuarioLogado.id;
        
        SQLiteAPIAbstract.update("atos_atividade", atosAtividade.id, atosAtividade).then(function(data){
            if(atosAtividades.length > indice){
                defered.resolve(_finalizar(atosAtividades,indice,dataInicio));
            }else{
                defered.resolve(atosAtividades);
            }
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _atualizaProdutoAtividade = function (atualizaProduto, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = atualizaProduto[indice];
        indice++;
        
        var query = "UPDATE atos_atividade SET \n\
        atdcOcorrenciaProduto = "+registro.para+" \n\
        WHERE atdcOcorrenciaProduto = "+registro.de+" AND atdcOcorrencia = "+registro.atdcOcorrencia+" AND (sincronizado = 0 OR sincronizado IS NULL )"; 
                
        $cordovaSQLite.execute($rootScope.db, query).then(function(retorno){
            if(indice < atualizaProduto.length){
                defered.resolve(_atualizaProdutoAtividade(atualizaProduto, indice));
            }else{
                defered.resolve(retorno);
            }
        }, function(err){
            defered.reject(err);
            console.log(query);
            console.error(err);
        });
        return promise;
    };    
    
    var _excluiAntigos = function (dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT a.id FROM atos_atividade a \n\
                     JOIN atos b ON  b.id = a.atos \n\
                     JOIN atdc_ocorrencia d ON d.id = b.atdcOcorrencia \n\
                     ";
        query+= " WHERE d.atdcStatus = 6 \n\
                  AND b.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        
        query = "DELETE FROM atos_atividade WHERE id IN ( "+query+" )";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    
    return {
        atualizaProdutoAtividade : _atualizaProdutoAtividade,
        finalizarAtividades : _finalizarAtividades,
        realizarCheckinAtividade : _realizarCheckinAtividade,
        finalizarAtividade: _finalizarAtividade,
        retornaObjetoCompleto: _retornaObjetoCompleto,
        atualizaAtividade: _atualizaAtividade,
        adicionaAtividade: _adicionaAtividade,
        deleteAtosAtividades: _deleteAtosAtividades,
        buscaAtosAtividades: _buscaAtosAtividades,
        getAtosAtividades: _getAtosAtividades,
        getAtosAtividades2: _getAtosAtividades2,
        setAtosAtividades: _setAtosAtividades,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});