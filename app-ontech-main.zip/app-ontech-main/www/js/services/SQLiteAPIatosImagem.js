angular.module("starter").factory("SQLiteAPIatosImagem", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    SQLiteAPIAbstract, SQLiteAPIatdcOcorrenciaLog, $cordovaFile) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_imagem").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _criaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_imagem");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atos_imagem \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atos integer NOT NULL, \n\
            data datetime NOT NULL, \n\
            descricao text, \n\
            imagem text, \n\
            imagemData blob, \n\
            imagemUrl text, \n\
            imagemUrlMini text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            excluido integer, \n\
            sincronizado integer)");
    };
    
    var _iniciaTabela = function () {
        _criaTabela().then(function (data) {
//            return SQLiteAPIAbstract.adicionaColunaSeNaoExiste('atos_imagem','atosTeste','integer', 1);
//        }).then(function (data) {
//            console.log('data');
//            console.log(data);
        }, function(err){
            console.error(err);
            $rootScope.geraLog(err);
        });
    };
    
    var _buscaAtosImagens = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atos_imagem', data);
    };
    
    var _getAtosImagens = function (atos) {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT * FROM atos_imagem";
        var retorno = {};
        var indices = {};
        if(atos != undefined){
            query+= " WHERE atos = "+atos+" AND (excluido IS NULL OR excluido <> 1) ";
        }
        $cordovaSQLite.execute($rootScope.db, query).then(function(atos_imagens){
            for (var i = 0; i < atos_imagens.rows.length; i++) {
                var row = atos_imagens.rows.item(i);
                retorno[row.id] = row;
                indices[i] = row.id;
            }
            defered.resolve(_trataImagemSrc(retorno, 0, indices));
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    
    var _getAtosImagensRestantes = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT A.*, B.atdcOcorrencia, B.tipo FROM atos_imagem A LEFT JOIN atos B on B.id = A.atos";
        var retorno = {};
        var indices = {};
        
        var valido = new Date();
        valido.setDate(valido.getDate() - 1);
        
        query+= " WHERE (A.dataSincronizacao >= '"+$rootScope.converteObjetoDataPost(valido)+"' OR A.sincronizado = 0) AND (A.excluido IS NULL OR A.excluido <> 1) \n\
                  ORDER BY sincronizado ASC, data DESC";
        
        $cordovaSQLite.execute($rootScope.db, query).then(function(atos_imagens){
            for (var i = 0; i < atos_imagens.rows.length; i++) {
                var row = atos_imagens.rows.item(i);
                retorno[row.id] = row;
                indices[i] = row.id;
            }
            defered.resolve(_trataImagemSrc(retorno, 0, indices));
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    
    var _trataImagemSrc = function (imagens, indice, indices) {
        var defered = $q.defer();
        var promise = defered.promise;
        var qtdeImagens = Object.keys(imagens).length;
                
        if(qtdeImagens > 0){
//            console.log('_trataImagemSrc');
            var registro = imagens[indices[indice]];
//            console.log(registro);
            indice++;
            
            _trataImagemSrc2(registro).then(function (data) {
                registro.imagemSrc = data;
                if(indice < qtdeImagens){
                    defered.resolve(_trataImagemSrc(imagens, indice, indices));
                }else{
                    defered.resolve(imagens);
                }
                defered.resolve(imagens);
            }, function(err){
                registro.imagemSrc = '';
                if(indice < qtdeImagens){ 
                    defered.resolve(_trataImagemSrc(imagens, indice));
                }else{
                    defered.resolve(imagens);
                }
                defered.resolve(imagens);
//                console.error(err); 
//                defered.reject(err);
            });
            
        }else{
            defered.resolve(imagens);
        }
        return promise;
    };
    
    var _trataImagemSrc2 = function (imagem) {
        var defered = $q.defer();
        var promise = defered.promise;        
        var arquivo = $rootScope.caminhoFotos+imagem.imagem;
        
//        console.log(imagem.imagemData);
        if(imagem.imagemData != null){
            $cordovaFile.checkFile('',imagem.imagemData).then(function (success) {
                defered.resolve(imagem.imagemData);
            }, function (error) {
                defered.resolve(semImagem());
            });
        }else{
//            console.log(arquivo); 
            $cordovaFile.checkFile('',arquivo).then(function (success) {
//                console.log('success');
//                console.log(success);
                defered.resolve(retornaImagem(arquivo));
            }, function (error) {
//                console.log('error');
//                console.log(error);
                defered.resolve(semImagem());
            });
        }
        
        return promise;
    };
    
    var retornaImagem = function (arquivo){
        var defered = $q.defer();
        var promise = defered.promise;
        
        if(window.location.hostname === '192.168.1.20'){
//            console.log('base64');
            var parte1 = arquivo.split('/');
            var ultimo = parte1.length-1;
            var nome = angular.copy(parte1[ultimo]);
            delete parte1[ultimo];
            var caminho = parte1.join('/');
            
//            console.log('nome');
//            console.log(nome);
//            console.log('caminho');
//            console.log(caminho);
            
            $cordovaFile.readAsDataURL(caminho, nome).then(function(base64) {
//                console.log(base64);
                defered.resolve(base64);
            }, function(error) {
                console.error(error);
                defered.resolve(arquivo);
            });
        }else{
            defered.resolve(arquivo);
        }
        return promise;
    };
    
    var semImagem = function (){
        return 'http://placehold.it/300x300';
    };
    
    var _deleteAtosImagens = function () {
        _iniciaTabela();
        var query = "DELETE FROM atos_imagem";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtosImagens = function (atosImagens) {
        _iniciaTabela();
////        _deleteAtosImagens();
//        var query = "INSERT INTO atos_imagem ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        atos, \n\
//                        data, \n\
//                        descricao, \n\
//                        imagem, \n\
//                        imagemUrl, \n\
//                        imagemUrlMini, \n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?,?,?)";
//        angular.forEach(atosImagens, function (atosImagem,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atosImagem.id,
//                atosImagem.id, 
//                atosImagem.atos,
//                $rootScope.trataDataNull(atosImagem.data),
//                atosImagem.descricao,
//                atosImagem.imagem,
////                atosImagem.imagemData,
//                atosImagem.imagemUrl,
//                atosImagem.imagemUrlMini,
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) { 
//              console.error(err);
//            });
//        });
        _setAtosImagens2(atosImagens, 0, 'atos_imagem').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atosImagemValido'] = new Date(valido);
            $window.localStorage['atosImagemAtualizado'] = new Date();
            $window.localStorage['atosImagemQtde'] = Object.keys(atosImagens).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    
    var _setAtosImagens2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(Object.keys(retorno).length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
            registro.data = $rootScope.trataDataNull(registro.data);
    //        delete registro.status;
    //        delete registro.abertura;
    //        delete registro.encerramento;
    //        delete registro.distancia;
    //        registro.dataInicio = $rootScope.trataDataNull(registro.dataInicio);
    //        registro.dataFim = $rootScope.trataDataNull(registro.dataFim);

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAtosImagens2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
//    var _excluiAntigos = function (dias) {
//        if(dias === undefined){
//            dias = 30;
//        }
//        var dataLimite = new Date();
//        dataLimite.setDate(dataLimite.getDate() - dias);
//        
//        var query = "SELECT a.id FROM atos_imagem a \n\
//                     JOIN atos b ON  b.id = a.atos \n\
//                     JOIN atos_atendimento c ON c.atos = b.id \n\
//                     JOIN atdc_ocorrencia d ON d.id = b.atdcOcorrencia \n\
//                     ";
//        query+= " WHERE d.atdcStatus = 6 \n\
//                  AND b.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
//                  AND a.sincronizado = 1";
//        
//        query = "DELETE FROM atos_imagem WHERE id IN ( "+query+" )";
//        return $cordovaSQLite.execute($rootScope.db, query);
//    };
    
     
    function _downloadArquivos () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atos_imagens = [];
        
        if($rootScope.excluindoAntigos){
            setTimeout(_downloadArquivos, 6000);
            defered.resolve(atos_imagens);
        }else{
            var query = "SELECT id, imagem FROM atos_imagem WHERE sincronizado = 1";
            _iniciaTabela(); 
    //        console.log('teste123');
            $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
                for (var i = 0; i < data.rows.length; i++) {
                    var row = data.rows.item(i);
                    atos_imagens.push(row);
                }
                defered.resolve(_buscaArquivos(atos_imagens, 0));
            }, function (err) {
                defered.reject(err);
            });
        }
        return promise;
    }
    
    function _buscaArquivos (atos_imagens, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = atos_imagens[indice];
        indice++;
        
        if(atos_imagens.length > 0){
            $cordovaFile.checkFile($rootScope.caminhoFotos, registro.imagem)
            .then(function (success) {
    //            console.log('success');
    //            console.log(success);
                if(indice < atos_imagens.length){ 
                    defered.resolve(_buscaArquivos(atos_imagens, indice));
                }else{
                    setTimeout(_downloadArquivos, 600000);
                    defered.resolve(atos_imagens);
                }
            }, function (error) {
    //            console.log('error');
    //            console.log(error);
                var arquivo = $rootScope.urlFotos + registro.imagem;
                $rootScope.Download(arquivo,$rootScope.caminhoFotos).then(function(retorno){
                    if(retorno !== registro.imagem){
                        registro.imagem = retorno;
                        SQLiteAPIAbstract.insertOrUpdate ('atos_imagem', registro.id, registro, false);
                    }
                    if(indice < atos_imagens.length){ 
                        defered.resolve(_buscaArquivos(atos_imagens, indice));
                    }else{
                        setTimeout(_downloadArquivos, 600000);
                        defered.resolve(atos_imagens);
                    }
                }, function (error) {
                    if(indice < atos_imagens.length){ 
                        defered.resolve(_buscaArquivos(atos_imagens, indice));
                    }else{
                        setTimeout(_downloadArquivos, 600000);
                        defered.resolve(atos_imagens);
                    }
                });
            });
        }else{
            setTimeout(_downloadArquivos, 600000);
            defered.resolve(atos_imagens);
        }
        return promise;
    }
    
    
    var _excluiAntigos = function (dias) {
        var defered = $q.defer();
        var promise = defered.promise;
        var select = 'a.*';
        var query = _getQuery(select, dias);
        
        _getAtosImagensLimpar (query).then(function (data) {
            select = 'a.id';
//            query = _getQuery(select, dias);            
            query = "DELETE FROM atos_imagem WHERE id IN ( "+_getQuery(select, dias)+" )";
            defered.resolve($cordovaSQLite.execute($rootScope.db, query));
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    function _getQuery (select, dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT "+select+" FROM atos_imagem a \n\
                     JOIN atos b ON  b.id = a.atos \n\
                     JOIN atos_atendimento c ON c.atos = b.id \n\
                     JOIN atdc_ocorrencia d ON d.id = b.atdcOcorrencia \n\
                     ";
        query+= " WHERE d.atdcStatus = 6 \n\
                  AND b.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        return query;
    }
    
    
    function _getAtosImagensLimpar (query) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atos_imagens = [];
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atos_imagens.push(row);
            }
            if(atos_imagens.length > 0){
                defered.resolve(_excluirImagens(atos_imagens, 0));
            }else{
                defered.resolve(atos_imagens);
            }
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    function _excluirImagens (atos_imagens,indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = atos_imagens[indice];
        indice++;
        _iniciaTabela(); 
                
        $cordovaFile.checkFile($rootScope.caminhoFotos,registro.imagem).then(function (success) {
            $cordovaFile.removeFile($rootScope.caminhoFotos,registro.imagem).then(function (success) {
                if(indice < atos_imagens.length){
                    defered.resolve(_excluirImagens(atos_imagens, indice));
                }else{
                    defered.resolve(atos_imagens);
                }
            }, function (error) {
                if(indice < atos_imagens.length){
                    defered.resolve(_excluirImagens(atos_imagens, indice));
                }else{
                    defered.resolve(atos_imagens);
                }
            });
        }, function (error) {
            if(indice < atos_imagens.length){
                defered.resolve(_excluirImagens(atos_imagens, indice));
            }else{
                defered.resolve(atos_imagens);
            }
        });
        
        return promise;
    }
    
    
    
    
    return {
        deleteAtosImagens: _deleteAtosImagens,
        downloadArquivos: _downloadArquivos,
        buscaAtosImagens: _buscaAtosImagens,
        getAtosImagensRestantes: _getAtosImagensRestantes,
        getAtosImagens: _getAtosImagens,
        setAtosImagens: _setAtosImagens,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});