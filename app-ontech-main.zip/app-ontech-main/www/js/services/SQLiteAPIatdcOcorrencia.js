angular.module("starter").factory("SQLiteAPIatdcOcorrencia", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, AtdcOcorrenciaAPI, SQLiteAPIatdcOcorrenciaLog, SQLiteAPIAbstract) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_ocorrencia \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atdc integer, \n\
            itadauUsuario integer, \n\
            atdcStatus integer, \n\
            atdcPrioridade integer, \n\
            atdcEndereco integer, \n\
            atdcGrupoReprovacao integer, \n\
            tipo text, \n\
            data DATETIME, \n\
            descricao text, \n\
            observacao text, \n\
            procede text, \n\
            procedeJustificativa text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
        
    
    var _buscaAtdcOcorrencias = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_ocorrencia', data);
    };
    
    var _getAtdcOcorrencias = function () {
        _iniciaTabela();
        var query = "SELECT * FROM atdc_ocorrencia";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtdcOcorrencia = function (id) {
        _iniciaTabela();
        var query = "SELECT * FROM atdc_ocorrencia WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteAtdcOcorrencias = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_ocorrencia";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtdcOcorrencias = function (atdcOcorrencias) {
        _iniciaTabela();
////        _deleteAtdcOcorrencias();
//        var query = "INSERT INTO atdc_ocorrencia ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        atdc, \n\
//                        itadauUsuario, \n\
//                        atdcStatus, \n\
//                        atdcPrioridade, \n\
//                        atdcEndereco, \n\
//                        atdcGrupoReprovacao, \n\
//                        tipo, \n\
//                        data, \n\
//                        descricao, \n\
//                        observacao, \n\
//                        procede, \n\
//                        procedeJustificativa,\n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
//        angular.forEach(atdcOcorrencias, function (atdcOcorrencia,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atdcOcorrencia.id, 
//                atdcOcorrencia.id, 
//                atdcOcorrencia.atdc, 
//                atdcOcorrencia.itadauUsuario, 
//                atdcOcorrencia.atdcStatus, 
//                atdcOcorrencia.atdcPrioridade, 
//                atdcOcorrencia.atdcEndereco, 
//                atdcOcorrencia.atdcGrupoReprovacao, 
//                atdcOcorrencia.tipo, 
//                $rootScope.trataDataNull(atdcOcorrencia.data), 
//                atdcOcorrencia.descricao, 
//                atdcOcorrencia.observacao, 
//                atdcOcorrencia.procede, 
//                atdcOcorrencia.procedeJustificativa,
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAtdcOcorrencias2(atdcOcorrencias, 0, 'atdc_ocorrencia').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atdcOcorrenciaValido'] = new Date(valido);
            $window.localStorage['atdcOcorrenciaAtualizado'] = new Date();
            $window.localStorage['atdcOcorrenciaQtde'] = Object.keys(atdcOcorrencias).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setAtdcOcorrencias2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setAtdcOcorrencias2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    function _getAtdcOcorrenciasParaSincronizar () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencias = [];
        var query = "SELECT * FROM atdc_ocorrencia WHERE sincronizado = 0 OR sincronizado = null";
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdc_ocorrencias.push(row);
            }
            defered.resolve(atdc_ocorrencias);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    function _enviaAtdcOcorrencias (atdc_ocorrencias) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela(); 
        $http.post($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia?sync=enviar', atdc_ocorrencias).then(function (data) {
            _retiraAtdcOcorrenciaSincronizacao(data.data, 0).then(function (data) {
                defered.resolve(data);
            }, function (err) {
                defered.reject(err);
            });
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    var _retiraAtdcOcorrenciaSincronizacao = function (retorno, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var id = retorno[indice].id;
        indice++;
        
        var query = "UPDATE atdc_ocorrencia set sincronizado = 1 WHERE id = ?";
        
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function (data) {
            if(indice < retorno.qtde){
                return _retiraAtdcOcorrenciaSincronizacao(retorno, indice);
            }else{
                defered.resolve(retorno);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _excluiAntigos = function (dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT a.id FROM atdc_ocorrencia a \n\
                     JOIN atos b ON  b.atdcOcorrencia = a.id \n\
                     ";
        query+= " WHERE a.atdcStatus = 6 \n\
                  AND b.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        
        query = "DELETE FROM atdc_ocorrencia WHERE id IN ( "+query+" )";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    return {
        enviaAtdcOcorrencias: _enviaAtdcOcorrencias,
        getAtdcOcorrenciasParaSincronizar: _getAtdcOcorrenciasParaSincronizar,
        deleteAtdcOcorrencias: _deleteAtdcOcorrencias,
        buscaAtdcOcorrencias: _buscaAtdcOcorrencias,
        getAtdcOcorrencias: _getAtdcOcorrencias,
        getAtdcOcorrencia: _getAtdcOcorrencia,
        setAtdcOcorrencias: _setAtdcOcorrencias,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});