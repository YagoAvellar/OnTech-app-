angular.module("starter").factory("SQLiteAPIatos", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    SQLiteAPIAbstract, SQLiteAPIatdcOcorrenciaLog) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atos \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atdcOcorrencia integer, \n\
            tipo text, \n\
            abertura datetime, \n\
            encerramento datetime, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
    
    var _buscaAtos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atos', data);
    };
    
    var _getAtos = function () {
        _iniciaTabela();
        var query = "SELECT * FROM atos";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _deleteAtos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atos";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtos = function (atos) {
        _iniciaTabela();
//        _deleteAtos();
//        var query = "INSERT INTO atos ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        atdcOcorrencia, \n\
//                        tipo, \n\
//                        abertura, \n\
//                        encerramento, \n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?)";
//        angular.forEach(atos, function (os,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                os.id, 
//                os.id, 
//                os.atdcOcorrencia, 
//                os.tipo, 
//                $rootScope.trataDataNull(os.abertura), 
//                $rootScope.trataDataNull(os.encerramento),
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAtos2(atos, 0, 'atos').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atosValido'] = new Date(valido);
            $window.localStorage['atosAtualizado'] = new Date();
            $window.localStorage['atosQtde'] = Object.keys(atos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setAtos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            registro.abertura = $rootScope.trataDataNull(registro.abertura);
            registro.encerramento = $rootScope.trataDataNull(registro.encerramento);
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
    //                
            //caso id inserido na API for diferente do aplicativo
            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAtos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    function _finalizarAtos (atendimento) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        var atos = {
            'encerramento' : atendimento.dataFim
        };
        SQLiteAPIAbstract.update('atos', atendimento.atos, atos).then(function(data){
            var atdcOcorrenciaEncerramento = {
                'atdcOcorrencia' : atendimento.atdcOcorrencia,
                'itadauUsuario' : atendimento.itadauUsuario,
                'atdcEncerramento' : 5,
                'data' : atendimento.dataFim,
                'observacao' : atendimento.observacao,
                'dataAlteracao' : atendimento.dataFim,
                'sincronizado' : 0
            };
            retorno['atos'] = data;
            return SQLiteAPIAbstract.insert('atdc_ocorrencia_encerramento',atdcOcorrenciaEncerramento);
        }).then(function(data){
            retorno['atdcOcorrenciaEncerramento'] = data;
            defered.resolve(retorno);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });

        return promise;
    }
    
    
    function _getAtosParaSincronizar () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atos = [];
        var query = "SELECT * FROM atos WHERE sincronizado = 0 OR sincronizado = null";
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atos.push(row);
            }
            defered.resolve(atos);
        }, function (err) {
            defered.reject(err);
        });

        return promise;
    }
    
    function _enviaAtos (atos) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela(); 
        $http.post($rootScope.configEmpresa.baseUrl + '/atos?sync=enviar', atos).then(function (data) {
            _retiraAtosSincronizacao(data.data, 0).then(function (data) {
                defered.resolve(data);
            }, function (err) {
                defered.reject(err);
            });
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    var _retiraAtosSincronizacao = function (retorno, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var id = retorno[indice].id;
        indice++;
        
        var query = "UPDATE atos set sincronizado = 1 WHERE id = ?";
        
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function (data) {
            if(indice < retorno.qtde){
                return _retiraAtosSincronizacao(retorno, indice);
            }else{
                defered.resolve(retorno);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _excluiAntigos = function (dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT b.id FROM atos b \n\
                     LEFT JOIN atdc_ocorrencia d ON d.id = b.atdcOcorrencia \n\
                     ";
        query+= " WHERE (d.atdcStatus = 6 OR d.atdcStatus IS NULL) \n\
                  AND b.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND b.sincronizado = 1";
        
        query = "DELETE FROM atos_atendimento WHERE id IN ( "+query+" )";
        return $cordovaSQLite.execute($rootScope.db, query);
    };    
    
    
    return {
        enviaAtos: _enviaAtos,
        getAtosParaSincronizar: _getAtosParaSincronizar,
        finalizarAtos: _finalizarAtos,
        deleteAtos: _deleteAtos,
        buscaAtos: _buscaAtos,
        getAtos: _getAtos,
        setAtos: _setAtos,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});