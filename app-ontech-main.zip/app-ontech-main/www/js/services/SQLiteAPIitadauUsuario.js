angular.module("starter").factory("SQLiteAPIitadauUsuario", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    SQLiteAPIAbstract, $localStorage) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE itadau_usuario").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _criaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE itadau_usuario");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS itadau_usuario \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            itad integer, \n\
            itadauPerfil integer, \n\
            nome text, \n\
            sexo text, \n\
            telefone text, \n\
            email text, \n\
            foto text, \n\
            senha text, \n\
            salt text, \n\
            active text, \n\
            activeKey text, \n\
            acessaApp text, \n\
            assinaturaDigital BLOB, \n\
            registroPush text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
    
     _iniciaTabela = function () {
        _criaTabela().then(function (data) {
            return SQLiteAPIAbstract.adicionaColunaSeNaoExiste('itadau_usuario','registroPush','text');
        }, function(err){
            $rootScope.geraLog(err);
        });
    };
    
    var _buscaItadauUsuarios = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('itadau_usuario', data);
    };
    
    var _getItadauUsuarios = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM itadau_usuario";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getItadauUsuario = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM itadau_usuario WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteItadauUsuarios = function () {
        _iniciaTabela();
        var query = "DELETE FROM itadau_usuario";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setItadauUsuarios = function (itadauUsuarios) {
        _iniciaTabela();
    
        _setItadauUsuarios2(itadauUsuarios, 0, 'atos_status').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['itadauUsuarioValido'] = new Date(valido);
            $window.localStorage['itadauUsuarioAtualizado'] = new Date();
            $window.localStorage['itadauUsuarioQtde'] = Object.keys(itadauUsuarios).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setItadauUsuarios2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.at;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
    //                
            //caso id inserido na API for diferente do aplicativo
            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setItadauUsuarios2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    function _getUsuarioParaSincronizar () {
        return SQLiteAPIAbstract.getRegistrosParaSincronizar('itadau_usuario');
    }
    
    
    
    return {
        getUsuarioParaSincronizar: _getUsuarioParaSincronizar,
        deleteItadauUsuarios: _deleteItadauUsuarios,
        buscaItadauUsuarios: _buscaItadauUsuarios,
        getItadauUsuarios: _getItadauUsuarios,
        getItadauUsuario: _getItadauUsuario,
        setItadauUsuarios: _setItadauUsuarios,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});