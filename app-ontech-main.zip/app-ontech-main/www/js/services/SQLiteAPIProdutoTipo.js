angular.module("starter").factory("SQLiteAPIProdutoTipo", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, ProdutoTipoAPI, SQLiteAPIAbstract, $cordovaFile) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdb_produto_tipo").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdb_produto_tipo");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdb_produto_tipo \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            descricao text, \n\
            status text, \n\
            dataAlteracao DATETIME)");
    };
    
    var _buscaProdutoTipos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdb_produto_tipo', data);
    };
    
    var _getTiposProduto = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdb_produto_tipos = {};
        var query = "SELECT * FROM atdb_produto_tipo WHERE status = 't' ";
        
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdb_produto_tipos[row.descricao] = row.descricao;
            }
            defered.resolve(atdb_produto_tipos);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
        
    };
    
    var _getProdutoTipos = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdb_produto_tipo";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getProdutoTipo = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdb_produto_tipo WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteProdutoTipos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdb_produto_tipo";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    var _setProdutoTipos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setProdutoTipos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    var _setProdutoTipos = function (produtoTipos) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela();
        _setProdutoTipos2(produtoTipos, 0, 'atdb_produto_tipo').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['produtoTipoValido'] = new Date(valido);
            $window.localStorage['produtoTipoAtualizado'] = new Date();
            $window.localStorage['produtoTipoQtde'] = Object.keys(produtoTipos).length;
            defered.resolve(produtoTipos);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    
    
    return {
        getTiposProduto: _getTiposProduto,
        deleteProdutoTipos: _deleteProdutoTipos,
        buscaProdutoTipos: _buscaProdutoTipos,
        getProdutoTipos: _getProdutoTipos,
        getProdutoTipo: _getProdutoTipo,
        setProdutoTipos: _setProdutoTipos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});