angular.module("starter").factory("SQLiteAPICliente", function ($http, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    $q, clientesAPI, SQLiteAPIAbstract) {
    
    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            itadauUsuario integer, \n\
            codigo text, \n\
            nome text, \n\
            documentoFederal text, \n\
            documentoEstadual text, \n\
            email text, \n\
            telefone text, \n\
            telefone2 text, \n\
            celular text, \n\
            celular2 text, \n\
            contato text, \n\
            dataAlteracao DATETIME)");
    }; 
    
    var _buscaClientes = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc', data);
    };
    
    var _getClientes = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getCliente = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _getClienteEndereco = function (atdcEndereco) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc A JOIN atdc_endereco B ON B.atdc = A.id WHERE B.id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[atdcEndereco]);
    };
    var _deleteClientes = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setClientes = function (clientes) {
        _iniciaTabela();
//        _deleteClientes();
//        var query = "INSERT INTO atdc ( \n\
//                        id, \n\
//                        itadauUsuario, \n\
//                        codigo, \n\
//                        nome, \n\
//                        documentoFederal, \n\
//                        documentoEstadual, \n\
//                        email, \n\
//                        telefone, \n\
//                        telefone2, \n\
//                        celular, \n\
//                        celular2, \n\
//                        contato) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
//        angular.forEach(clientes, function (cliente,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                cliente.id, 
//                cliente.itadauUsuario, 
//                cliente.codigo, 
//                cliente.nome, 
//                cliente.documentoFederal, 
//                cliente.documentoEstadual, 
//                cliente.email, 
//                cliente.telefone, 
//                cliente.telefone2, 
//                cliente.celular, 
//                cliente.celular2, 
//                cliente.contato]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
         _setClientes2(clientes, 0, 'atdc').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['clienteValido'] = new Date(valido);
            $window.localStorage['clienteAtualizado'] = new Date();
            $window.localStorage['clienteQtde'] = Object.keys(clientes).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setClientes2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;
            delete registro._links;
            delete registro.status;
            delete registro.dataCadastro;
    //        delete registro.dataAlteracao;
            delete registro.at;
            delete registro.sincronizado;
    //        delete registro.idAPI;
    //        registro.sincronizado = 1;
    //        registro.idAPI = registro.id;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setClientes2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
//    var _excluiAntigos = function (dias) {
//        if(dias === undefined){
//            dias = 30;
//        }
//        var dataLimite = new Date();
//        dataLimite.setDate(dataLimite.getDate() - dias);
//        
//        var query = "SELECT a.id FROM atdc a \n\
//                     JOIN atdc_endereco e ON  e.atdc = a.id \n\
//                     JOIN atdc_ocorrencia f ON  f.atdcEndereco = e.id \n\
//                     JOIN atos b ON  b.atdcOcorrencia = f.id \n\
//                     JOIN atos_atendimento c ON c.atos = b.id \n\
//                     JOIN atdc_ocorrencia d ON d.id = b.atdcOcorrencia \n\
//                     ";
//        query+= " WHERE d.atdcStatus = 6 \n\
//                  AND b.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
//                  AND a.sincronizado = 1";
//        
//        query = "DELETE FROM atdc WHERE id IN ( "+query+" )";
//        return $cordovaSQLite.execute($rootScope.db, query);
//    };
    
    
    return {
        deleteClientes: _deleteClientes,
//        excluiAntigos: _excluiAntigos,
        buscaClientes: _buscaClientes,
        getClientes: _getClientes,
        getCliente: _getCliente,
        getClienteEndereco: _getClienteEndereco,
        setClientes: _setClientes,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});