angular.module("starter").factory("NotificationPush", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    atosStatusAPI, SQLiteAPIAbstract, $ionicPlatform) {

    var _interacao = function (dados) {
//        var defered = $q.defer();
//        var promise = defered.promise;
        var dados2 = dados.additionalData.dados;
        
        var mensagem = "<b>"+dados2.usuarioNome+"</b><br/>"+dados2.data+"<br/><br/>"+dados2.descricao;
        
        $rootScope.showAlertTitulo(dados.title, mensagem);
        if($rootScope.buscando === false){
            $rootScope.buscaRegistros(false);
        }
            //verifica se existe ocorrência e insere interação
//            SQLiteAPIAbstract.find(dados.atdcOcorrencia, 'atdc_ocorrencia').then(function (retorno) {
//                if(retorno === null){
//                    return retorno;
//                }else{
//                    return SQLiteAPIAbstract.insertOrUpdate('atdc_ocorrencia_interacao', dados.id, dados)
//                }
//            }).then(function (retorno) {
//                defered.resolve(retorno);
//            }, function(err){
//                console.error(err); 
//                defered.reject(err);
//            });
//        defered.resolve('OK');
//        return promise;
    };
    
    var _nova = function (data) {
//        console.log(data);
//        var defered = $q.defer();
//        var promise = defered.promise;
        if(data.additionalData.tipo === "interacao"){
            _interacao(data);
//            defered.resolve(_interacao(data));
        }
//        return promise;
    };
    
    var _atualizaRegistro = function (data) {
        if($rootScope.usuarioLogado){            
            $rootScope.registroPush = data.registrationId;
            var dadosAtualiza = {
                id : $rootScope.usuarioLogado.id,
                registroPush : $rootScope.registroPush,
                sincronizado : 0
            };
            SQLiteAPIAbstract.adicionaColunaSeNaoExiste('itadau_usuario','registroPush','text').then(function (retorno) {
                return SQLiteAPIAbstract.find(dadosAtualiza.id, 'itadau_usuario');
            }).then(function (retorno) {
                if(retorno === null){
                        $rootScope.usuarioLogado.registroPush = $rootScope.registroPush;
                        var registroInsert = angular.copy($rootScope.usuarioLogado);
                        registroInsert.sincronizado = 0;
                        delete registroInsert.empresaLogin;
                        SQLiteAPIAbstract.insert('itadau_usuario', registroInsert );
                }else{
                    SQLiteAPIAbstract.update('itadau_usuario', dadosAtualiza.id, dadosAtualiza);
                }
            }, function(err){
                $rootScope.geraLog(err);
    //            console.error(err); 
            });
        }else{
            setTimeout(function() {
                _atualizaRegistro(data);
            }, 60000);
        }
    };
    
    return {
        nova: _nova,
        atualizaRegistro: _atualizaRegistro
    };
});