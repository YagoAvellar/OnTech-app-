angular.module("starter").factory("SQLiteAPIatdcOcorrenciaLog", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, AtdcOcorrenciaLogAPI, SQLiteAPIAbstract, $localStorage) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_log").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_log");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_ocorrencia_log \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atdcOcorrencia integer, \n\
            itadauUsuario integer, \n\
            data DATETIME, \n\
            tipo text, \n\
            titulo text, \n\
            descricao text, \n\
            informacao text, \n\
            icone text, \n\
            cor text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
        
    var _buscaAtdcOcorrenciaLogs = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_ocorrencia_log', data);
    };
    
    var _getAtdcOcorrenciaLogs = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_log";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtdcOcorrenciaLog = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_log WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteAtdcOcorrenciaLogs = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_ocorrencia_log";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtdcOcorrenciaLogs = function (atdcOcorrenciaLogs) {
        _iniciaTabela();
////        _deleteAtdcOcorrenciaLogs();
//        var query = "INSERT INTO atdc_ocorrencia_log ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        atdcOcorrencia, \n\
//                        itadauUsuario, \n\
//                        data, \n\
//                        tipo, \n\
//                        titulo, \n\
//                        descricao, \n\
//                        informacao, \n\
//                        icone, \n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?,?,?,?,?)";  
//        
//        angular.forEach(atdcOcorrenciaLogs, function (atdcOcorrenciaLog,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atdcOcorrenciaLog.id,
//                atdcOcorrenciaLog.id,
//                atdcOcorrenciaLog.atdcOcorrencia,
//                atdcOcorrenciaLog.itadauUsuario,
//                $rootScope.trataDataNull(atdcOcorrenciaLog.data),
//                atdcOcorrenciaLog.tipo,
//                atdcOcorrenciaLog.titulo,
//                atdcOcorrenciaLog.descricao,
//                atdcOcorrenciaLog.informacao,
//                atdcOcorrenciaLog.icone,
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAtdcOcorrenciaLogs2(atdcOcorrenciaLogs, 0, 'atdc_ocorrencia_log').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atdcOcorrenciaLogValido'] = new Date(valido);
            $window.localStorage['atdcOcorrenciaLogAtualizado'] = new Date();
            $window.localStorage['atdcOcorrenciaLogQtde'] = Object.keys(atdcOcorrenciaLogs).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setAtdcOcorrenciaLogs2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            registro.sincronizado = 1;
    //        delete registro.dataAlteracao;
    //        delete registro._embedded;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setAtdcOcorrenciaLogs2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    var $info = {
        'abertura' : {
            'tipo' : 'geral',
            'titulo' : 'Abertura',
            'descricao' : 'Abertura de Ocorrência',
            'icone' : 'fa-file-o',
            'cor' : 'success'
        },
        'atualizacao' : {
            'tipo' : 'geral',
            'titulo' : 'Atualização',
            'descricao' : 'Ocorrência foi atualizada',
            'icone' : 'fa-refresh',
            'cor' : 'success'
        },
        'addProduto' : {
            'tipo' : 'geral',
            'titulo' : 'Inclusão de Produto',
            'descricao' : 'A lista de produtos inclusa nesta ocorrência foi atualizada',
            'icone' : 'fa-plus',
            'cor' : 'success'
        },
//        'editProduto' : {
//            'tipo' : 'geral',
//            'titulo' : 'Edição de Produto',
//            'descricao' : 'A lista de produtos inclusa nesta ocorrência foi atualizada',
//            'icone' : 'produto'
//        },
        'remProduto' : {
            'tipo' : 'geral',
            'titulo' : 'Exclusão de Produto',
            'descricao' : 'A lista de produtos inclusa nesta ocorrência foi atualizada',
            'icone' : 'fa-remove',
            'cor' : 'danger'
        },
        'interacao' : {
            'tipo' : 'geral',
            'titulo' : 'Nova Interação',
            'descricao' : 'Foi criado uma nova interação para a ocorrência',
            'icone' : 'fa-arrow-right',
            'cor' : 'primary'
        },
        'agendamento' : {
            'tipo' : 'geral',
            'titulo' : 'Agendamento de visita',
            'descricao' : 'Foi gerado uma visita para esta ocorrência',
            'icone' : 'fa-book',
            'cor' : 'primary'
        },
        'reagendamento' : {
            'tipo' : 'geral',
            'titulo' : 'Reagendamento de visita',
            'descricao' : 'Foi gerado uma visita para esta ocorrência',
            'icone' : 'fa-book',
            'cor' : 'primary'
        },
        'solicitacaoPeca' : {
            'tipo' : 'geral',
            'titulo' : 'Solicitação de peça',
            'descricao' : 'Foi solicitado a peça para a fábrica',
            'icone' : 'fa-exchange',
            'cor' : 'warning'
        },
        'pecaRecebida' : {
            'tipo' : 'geral',
            'titulo' : 'Peça recebida',
            'descricao' : 'A peça deu entrada na assitência técnica',
            'icone' : 'fa-check-circle-o',
            'cor' : 'success'
        },
        'qualidade' : {
            'tipo' : 'geral',
            'titulo' : 'Controle de Qualidade',
            'descricao' : 'Laudo',
            'icone' : 'fa-eye',
            'cor' : 'danger'
        },
        'encerrar' : {
            'tipo' : 'geral',
            'titulo' : 'Finalizada',
            'descricao' : 'A ocorrência foi encerrada',
            'icone' : 'fa-check',
            'cor' : 'success'
        },
        'remAtividade' : {
            'tipo' : 'geral',
            'titulo' : 'Exclusão de Atividade',
            'descricao' : 'A lista de atividades inclusa nesta ocorrência foi atualizada',
            'icone' : 'fa-remove',
            'cor' : 'danger'
        },
        'encAtividade' : {
            'tipo' : 'geral',
            'titulo' : 'Finalizada',
            'descricao' : 'A Atividade foi finalizada',
            'icone' : 'fa-check',
            'cor' : 'success'
        },
        'encAtendimento' : {
            'tipo' : 'geral',
            'titulo' : 'Finalizado',
            'descricao' : 'O Atendimento foi finalizado',
            'icone' : 'fa-check',
            'cor' : 'success'
        }
    };


    var _add = function($ocorrencia, $tipo, $informacao /*= null, $objUsuario /*= null*/)
    {
        _iniciaTabela();
        var defered = $q.defer();
        var promise = defered.promise;
        var $tt;
//        var $objUsuario = '';

        var dtAlteracao = new Date();
        var dataAlteracao = $rootScope.converteObjetoDataPost(dtAlteracao);

        if ($tipo in $info) {
            $tt = $info[$tipo];
        } else {
            var ret = [false, "O tipo de log não definido."];
            defered.resolve(ret);
        }
        
//        if (is_null($objUsuario)) {
//            var ret = [false, "Não foi localizado um usuário válido para salvar o log."];
//            defered.resolve(ret);
//        }

        
//        if (!is_object($objOcorrencia = $this->getAtdcOcorrencia($ocorrencia))) {
//            return [false, "Ocorrência não foi localizada."];
//        }


        var $ii = null;
        if (typeof $informacao === "string") {
            $ii = $informacao.substring(0, 500);
        }

        var $data = {
            'tipo' : $tt['tipo'],
            'titulo' : $tt['titulo'],
            'descricao' : $tt['descricao'],
            'informacao' : $ii,
            'icone' : $tt['icone'],
            'atdcOcorrencia' : $ocorrencia,
            'itadauUsuario' : $rootScope.usuarioLogado.id,
            'data' : dataAlteracao,
            'dataAlteracao' : dataAlteracao,
            'sincronizado' : 0
        };
//        var_dump($data);
//        exit;

        SQLiteAPIAbstract.insert('atdc_ocorrencia_log', $data).then(function(data){
            defered.resolve(data);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _excluiAntigos = function (dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT a.id FROM atdc_ocorrencia_log a \n\
                     JOIN atdc_ocorrencia b ON  b.id = a.atdcOcorrencia \n\
                     JOIN atos c ON  c.atdcOcorrencia = b.id \n\
                     ";
        query+= " WHERE b.atdcStatus = 6 \n\
                  AND c.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        
        query = "DELETE FROM atdc_ocorrencia_log WHERE id IN ( "+query+" )";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    
    return {
        add: _add,
        iniciaTabela: _iniciaTabela,
        deleteAtdcOcorrenciaLogs: _deleteAtdcOcorrenciaLogs,
        buscaAtdcOcorrenciaLogs: _buscaAtdcOcorrenciaLogs,
        getAtdcOcorrenciaLogs: _getAtdcOcorrenciaLogs,
        getAtdcOcorrenciaLog: _getAtdcOcorrenciaLog,
        setAtdcOcorrenciaLogs: _setAtdcOcorrenciaLogs,
        excluiAntigos: _excluiAntigos,
        apagaTabela: _apagaTabela
    };
});