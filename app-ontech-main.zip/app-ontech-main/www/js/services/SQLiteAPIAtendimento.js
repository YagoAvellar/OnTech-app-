angular.module("starter").factory("SQLiteAPIAtendimento", function ($ionicPlatform, $http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, AtendimentoAPI, SQLiteAPIAbstract, SQLiteAPIatosAtividade, SQLiteAPIatosServico, SQLiteAPIatos, SQLiteAPIatdcOcorrenciaLog, $timeout, OAuth) {

//$ionicPlatform.ready(function () {
//    
//    
//});
//alert('teste'); 
    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_atendimento").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _criaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_atendimento");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atos_atendimento \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atosAvaliacao integer, \n\
            itadauUsuario integer, \n\
            atdcEndereco integer, \n\
            atdcOcorrencia integer, \n\
            atos integer, \n\
            descricao text, \n\
            dataAgendamento DATETIME, \n\
            distancia integer, \n\
            endereco text, \n\
            localizacao text, \n\
            periodo text, \n\
            dataInicio DATETIME, \n\
            dataFim DATETIME, \n\
            atosStatus integer, \n\
            tipo text, \n\
            observacao text, \n\
            assinaturaDigital BLOB, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            excluido integer, \n\
            sincronizado integer)");
    };
    
    var _iniciaTabela = function () {
        _criaTabela().then(function (data) {
            return SQLiteAPIAbstract.adicionaColunaSeNaoExiste('atos_atendimento','assinaturaDigital','BLOB');
        }).then(function (data) {
            return SQLiteAPIAbstract.adicionaColunaSeNaoExiste('atos_atendimento','atosAvaliacao','integer');
        }, function(err){
            $rootScope.geraLog(err);
        });
    };
    
    
    var _buscaAtendimentos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atos_atendimento', data);
    };
    
    var _getAtendimentos = function (buscaAtendimento) {
        _iniciaTabela(); 
        var query = "SELECT A.*, \n\
                            B.descricao as status, \n\
                            C.cep, \n\
                            C.rua, \n\
                            C.numero, \n\
                            C.complemento, \n\
                            C.bairro, \n\
                            C.cidade, \n\
                            C.estado, \n\
                            C.referencia, \n\
                            C.localizacao, \n\
                            E.tipo AS siglaTipo \n\
                     FROM atos_atendimento A \n\
                     JOIN atos_status B ON B.id = A.atosStatus \n\
                     JOIN atdc_endereco C ON C.id = A.atdcEndereco  \n\
                     JOIN atos D ON D.id = A.atos  \n\
                     JOIN atdc_ocorrencia E ON E.id = A.atdcOcorrencia";
        if(buscaAtendimento.atosStatus === null || buscaAtendimento.atosStatus == 1){
            query += " WHERE atosStatus  not in (5,6,7,11,12,13,14,16) AND D.encerramento IS NULL";
        }else{
            query += " WHERE atosStatus = "+buscaAtendimento.atosStatus;
        }
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    var _getAtendimentos2 = function (buscaAtendimento) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atendimentos = [];
        
//        console.log('buscaAtendimento');
//        console.log(buscaAtendimento);
        
//        if($rootScope.buscando === true && OAuth.isAuthenticated()){
//            $rootScope.abrirCarregando('Aguarde enquanto busca por novos registros...');
//            $timeout(function() {
//                defered.resolve(_getAtendimentos2(buscaAtendimento));
//            }, 1000);
//        }else{
            _getAtendimentos(buscaAtendimento).then(function (res) {
                for (var i = 0; i < res.rows.length; i++) {
                    var row = res.rows.item(i);
                    if(row.localizacao){
                        row.distancia = $rootScope.calculaDistancia($rootScope.localizacaoUsuario, row.localizacao);
                    }else{
                        row.distancia = null;
                    }
                    atendimentos.push(row);
                }
                defered.resolve(atendimentos);
            }, function(err){
                $rootScope.fecharCarregando();
                console.error(err); 
                defered.reject(err);
            });
//        }
        
        return promise;
    };
    var _getAtendimentoAtual = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atos_atendimento WHERE atosStatus = 4";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtendimento = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atos_atendimento WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteAtendimentos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atos_atendimento";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtendimentos = function (atendimentos) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela();
//        _deleteAtendimentos();
//        var query = "INSERT INTO atos_atendimento ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        itadauUsuario, \n\
//                        atdcEndereco, \n\
//                        atdcOcorrencia, \n\
//                        atos, \n\
//                        descricao, \n\
//                        dataAgendamento, \n\
//                        dataInicio, \n\
//                        dataFim, \n\
//                        distancia, \n\
//                        endereco, \n\
//                        localizacao, \n\
//                        periodo, \n\
//                        atosStatus, \n\
//                        tipo,\n\
//                        observacao,\n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"; 
//        angular.forEach(atendimentos, function (atendimento,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atendimento.id,
//                atendimento.id,
//                atendimento.itadauUsuario,
//                atendimento.atdcEndereco,
//                atendimento.atdcOcorrencia,
//                atendimento.atos,
//                atendimento.descricao,
//                $rootScope.trataDataNull(atendimento.dataAgendamento),
//                $rootScope.trataDataNull(atendimento.dataInicio),
//                $rootScope.trataDataNull(atendimento.dataFim),
//                atendimento.distancia,
//                atendimento.endereco,
//                atendimento.localizacao,
//                atendimento.periodo,
//                atendimento.atosStatus,
//                atendimento.tipo,
//                atendimento.observacao,
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAtendimentos2(atendimentos, 0, 'atos_atendimento').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atendimentoValido'] = new Date(valido);
            $window.localStorage['atendimentoAtualizado'] = new Date();
            $window.localStorage['atendimentoQtde'] = Object.keys(atendimentos).length;
            defered.resolve(atendimentos);
//            console.log('atendimentos.....');
//            console.log(atendimentos);
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    
    
    var _setAtendimentos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.status;
            delete registro.abertura;
            delete registro.encerramento;
            delete registro.distancia;
    //        delete registro['$$hashKey'];
    //        console.log(registro);
            registro.dataAgendamento = $rootScope.trataDataNull(registro.dataAgendamento);
            registro.dataInicio = $rootScope.trataDataNull(registro.dataInicio);
            registro.dataFim = $rootScope.trataDataNull(registro.dataFim);
            registro.sincronizado = 1;
            registro.idAPI = registro.id;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAtendimentos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    var _realizarCheckin = function (atendimento) {
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        var dataInicio = $rootScope.converteObjetoDataPost(timeNow);
        
        var query = "UPDATE atos_atendimento SET \n\
                    dataInicio = '"+dataInicio+"',  dataAlteracao = '"+dataInicio+"',  sincronizado = 0, atosStatus = 4\n\
                    WHERE id = ? ";
        
        $cordovaSQLite.execute($rootScope.db, query,[atendimento.id]).then(function (data) {
            
            var query = "UPDATE atdc_ocorrencia SET \n\
                        dataAlteracao = '"+dataInicio+"',  sincronizado = 0, atdcStatus = 4 \n\
                        WHERE id = ? ";
            
            $cordovaSQLite.execute($rootScope.db, query,[atendimento.atdcOcorrencia]).then(function (data) {
                $rootScope.fecharCarregando();
                defered.resolve(data);
            }, function (err) {
                console.error(err);
                defered.reject(err);
                $rootScope.fecharCarregando();
            });
        }, function (err) {
            defered.reject(err);
            $rootScope.fecharCarregando();
        });
        
        return promise;
    };    
    
    var _realizarCheckout = function (atendimento, atosAtendimento) {
        var defered = $q.defer();
        var promise = defered.promise;
        
        if(atendimento.atosStatus == 5){
            _reagendarAtendimento(atendimento, atosAtendimento).then(function(){
                var dadosOcorrencia = {
                    'atdcStatus' : 3,
                    'procede' : atendimento.naoProcede == 'true' ? 'f' : 't',
                    'procedeJustificativa' : atendimento.observacao
                };
                return SQLiteAPIAbstract.update('atdc_ocorrencia', atosAtendimento.atdcOcorrencia, dadosOcorrencia);
            }).then(function(data){
                if(atendimento.finalizarAtividades == 'true'){
                    atendimento.dataInicio = atosAtendimento.dataInicio;
                    return SQLiteAPIatosAtividade.finalizarAtividades(atendimento);
                }else{
                    return data;
                }
            }).then(function(data){
//                console.log('finalizarServicos');
//                console.log(atendimento);
                if(atendimento.finalizarServicos == 'true'){
                    atendimento.dataInicio = atosAtendimento.dataInicio;
                    defered.resolve(SQLiteAPIatosServico.finalizarServicos(atendimento));
                }else{
                    defered.resolve(data);
                }
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
            
        }else
        if(atendimento.atosStatus == 6 || atendimento.atosStatus == 13 || atendimento.atosStatus == 16){
            var arrayStatus = { 6 : 5, 13 : 11 , 16 : 12 };
            var status = arrayStatus[atendimento.atosStatus];
            
            _finalizarAtendimento(atendimento, atosAtendimento).then(function(){
                var dadosOcorrencia = {
                    'atdcStatus' : status,
                    'procede' : atendimento.naoProcede == 'true' ? 'f' : 't',
                    'procedeJustificativa' : atendimento.observacao
                };
                return SQLiteAPIAbstract.update('atdc_ocorrencia', atosAtendimento.atdcOcorrencia, dadosOcorrencia);
            }).then(function(data){
                var descricao = 'Status da ocorrência alterado para '+$rootScope.atosStatusFinalizar[atendimento.atosStatus]['descricao'];
                SQLiteAPIatdcOcorrenciaLog.add(atendimento.atdcOcorrencia,'atualizacao', descricao);
                if(atendimento.finalizarAtividades == 'true'){
                    atendimento.dataInicio = atosAtendimento.dataInicio;
                    return SQLiteAPIatosAtividade.finalizarAtividades(atendimento);
                }else{
                    return data;
                }
            }).then(function(data){
//                console.log('finalizarServicos');
//                console.log(atendimento);
                if(atendimento.finalizarServicos == 'true'){
                    atendimento.dataInicio = atosAtendimento.dataInicio;
                    defered.resolve(SQLiteAPIatosServico.finalizarServicos(atendimento));
                }else{
                    defered.resolve(data);
                }
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else
        if(atendimento.atosStatus == 7 || atendimento.atosStatus == 12 || atendimento.atosStatus == 14){
            var arrayStatus = {
                7 : atendimento.naoProcede == 'true' ? 6 : 9 , 
                12 : 10, 
                14 : 6 
            };
            var status = arrayStatus[atendimento.atosStatus];
            _finalizarAtendimento(atendimento, atosAtendimento).then(function(){
                var dadosOcorrencia = {
                    'atdcStatus' : status,
                    'procede' : atendimento.naoProcede == 'true' ? 'f' : 't',
                    'procedeJustificativa' : atendimento.observacao
                };
                return SQLiteAPIAbstract.update('atdc_ocorrencia', atosAtendimento.atdcOcorrencia, dadosOcorrencia);
            }).then(function(data){
                if(atendimento.finalizarAtividades == 'true'){
                    atendimento.dataInicio = atosAtendimento.dataInicio;
                    return SQLiteAPIatosAtividade.finalizarAtividades(atendimento);
                }else{
                    return data;
                }
            }).then(function(data){
//                console.log('finalizarServicos');
//                console.log(atendimento);
                if(atendimento.finalizarServicos == 'true'){
                    atendimento.dataInicio = atosAtendimento.dataInicio;
                    return SQLiteAPIatosServico.finalizarServicos(atendimento);
                }else{
                    return data;
                }
            }).then(function(data){
                return SQLiteAPIatos.finalizarAtos(atendimento);
            }).then(function(data){
                defered.resolve(data);
                SQLiteAPIatdcOcorrenciaLog.add(atosAtendimento.atdcOcorrencia,'encerrar', atendimento.observacao);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
            
//            $data->id = $id;
//            $this->repository = $this->getServiceManager()->get('OrdemServico\\V2\\Rest\\AtosAtendimento\\AtosAtendimentoRepository');
//            if(atendimento.naoProcede == 'true'){
//                $retorno = $this->repository->finalizarAtendimento($data);
//            }else{
//                $retorno = $this->repository->finalizarAtendimento($data,9);
//            }
//            if (!($retorno instanceof ApiProblem)) {
//                $informacao = $data->observacao;
//                $this->setLog($retorno->getAtos()->getAtdcOcorrencia()->getId(), 'encerrar', $informacao);
//            }
        }
//        else{
//            var arrayStatus = { 6 : 5, 12 : 10, 13 : 11, 14 : 6 }
//            var status = arrayStatus[atendimento.atosStatus];
//            _finalizarAtendimento(atendimento, atosAtendimento).then(function(){
//                var dadosOcorrencia = {
//                    'atdcStatus' : status,
//                    'procede' : atendimento.naoProcede == 'true' ? 'f' : 't',
//                    'procedeJustificativa' : atendimento.observacao
//                };
//                return SQLiteAPIAbstract.update('atdc_ocorrencia', atosAtendimento.atdcOcorrencia, dadosOcorrencia);
//            }).then(function(data){
//                if(atendimento.finalizarAtividades == 'true'){
//                    atendimento.dataInicio = atosAtendimento.dataInicio;
//                    defered.resolve(SQLiteAPIatosAtividade.finalizarAtividades(atendimento));
//                }else{
//                    defered.resolve(data);
//                }
//            }, function(err){
//                console.error(err);
//                defered.reject(err);
//            });
//        }
        
        return promise;
    };
    
    
    function _reagendarAtendimento (atendimento, atosAtendimento) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        var atos_atendimento = {
            'atosStatus' : atendimento.atosStatus,
            'observacao' : atendimento.observacao,
            'assinaturaDigital' : atosAtendimento.assinaturaDigital,
            'atosAvaliacao' : atosAtendimento.atosAvaliacao,
            'dataFim' : atendimento.dataFim
        };
        
        var atos_atendimento_novo = angular.copy(atosAtendimento);
        atos_atendimento_novo.atosStatus = 2;
        atos_atendimento_novo.descricao = 'Reagendamento';
        atos_atendimento_novo.periodo = atendimento.periodoReagendamento;
        atos_atendimento_novo.dataAgendamento = $rootScope.converteObjetoDataPost(atendimento.dataReagendamento);
        atos_atendimento_novo.sincronizado = 0;
        atos_atendimento_novo.dataAlteracao = atendimento.dataFim;
        delete atos_atendimento_novo.id;
        delete atos_atendimento_novo.idAPI;
        delete atos_atendimento_novo.dataInicio;
        delete atos_atendimento_novo.assinaturaDigital;
        delete atos_atendimento_novo.atosAvaliacao;
        
        SQLiteAPIAbstract.update('atos_atendimento', atendimento.id, atos_atendimento).then(function(data){
            retorno[data.id] = data;
            return SQLiteAPIAbstract.insert('atos_atendimento', atos_atendimento_novo);
        }).then(function(data){
            retorno[data.id] = data;
            defered.resolve(retorno);
            
            var dataReagendamento = $rootScope.converteDataString(atendimento.dataReagendamento, 2);
            var info = 'Foi reagendado a visita para <b>'+dataReagendamento+'</b>';
            SQLiteAPIatdcOcorrenciaLog.add(atosAtendimento.atdcOcorrencia,'reagendamento', info);
            
        }, function(err){
            console.error(err);
            defered.reject(err);
        });

        return promise;
    }
    
    
    function _finalizarAtendimento (atendimento, atosAtendimento) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        var atos_atendimento = {
            'atosStatus' : atendimento.atosStatus,
            'observacao' : atendimento.observacao,
            'assinaturaDigital' : atosAtendimento.assinaturaDigital,
            'atosAvaliacao' : atosAtendimento.atosAvaliacao,
            'dataFim' : atendimento.dataFim
        };
        
        SQLiteAPIAbstract.update('atos_atendimento', atendimento.id, atos_atendimento).then(function(data){
            retorno[data.id] = data;
            defered.resolve(retorno);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });

        return promise;
    }
    
    
    function _getAtendimentosParaSincronizar () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atos_atendimento = [];
        var query = "SELECT * FROM atos_atendimento WHERE sincronizado = 0 OR sincronizado = null";
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atos_atendimento.push(row);
            }
            defered.resolve(atos_atendimento);
        }, function (err) {
            defered.reject(err);
        });

        return promise;
    }
    
    
    function _enviaAtendimentos (atos_atendimentos) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela(); 
        $http.post($rootScope.configEmpresa.baseUrl + '/atos-atendimento?sync=enviar', atos_atendimentos).then(function (data) {
            _retiraAtendimentoSincronizacao(data.data, 0).then(function (data) {
                defered.resolve(data);
            }, function (err) {
                defered.reject(err);
            });
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    var _retiraAtendimentoSincronizacao = function (retorno, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var id = retorno[indice].id;
        indice++;
        
        var query = "UPDATE atos_atendimento set sincronizado = 1 WHERE id = ?";
        
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function (data) {
            if(indice < retorno.qtde){
                return _retiraAtendimentoSincronizacao(retorno, indice);
            }else{
                defered.resolve(retorno);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    
    var _excluiAntigos = function (dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT c.id FROM atos_atendimento c \n\
                     JOIN atos b ON  b.id = c.atos \n\
                     JOIN atdc_ocorrencia d ON d.id = b.atdcOcorrencia \n\
                     ";
        query+= " WHERE d.atdcStatus = 6 \n\
                  AND b.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND c.sincronizado = 1";
        
        query = "DELETE FROM atos_atendimento WHERE id IN ( "+query+" )";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    
    
    return {
        realizarCheckout: _realizarCheckout,
        enviaAtendimentos: _enviaAtendimentos,
        getAtendimentosParaSincronizar: _getAtendimentosParaSincronizar,
        realizarCheckin: _realizarCheckin,
        deleteAtendimentos: _deleteAtendimentos,
        buscaAtendimentos: _buscaAtendimentos,
        getAtendimentoAtual: _getAtendimentoAtual,
        getAtendimentos2: _getAtendimentos2,
        getAtendimentos: _getAtendimentos,
        getAtendimento: _getAtendimento,
        setAtendimentos: _setAtendimentos,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});