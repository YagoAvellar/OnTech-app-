angular.module("starter").factory("SQLiteAPIitadauUsuarioLocalizacao", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, ItadauUsuarioLocalizacaoAPI, SQLiteAPIAbstract, $localStorage) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE itadau_usuario_localizacao").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE itadau_usuario_localizacao");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS itadau_usuario_localizacao \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            itadauUsuario integer, \n\
            localizacao text, \n\
            data DATETIME, \n\
            observacao text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
    
    
    var _buscaItadauUsuarioLocalizacoes = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('itadau_usuario_localizacao', data);
    };
    
    var _getItadauUsuarioLocalizacoes = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM itadau_usuario_localizacao";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getItadauUsuarioLocalizacao = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM itadau_usuario_localizacao WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteItadauUsuarioLocalizacoes = function () {
        _iniciaTabela();
        var query = "DELETE FROM itadau_usuario_localizacao";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setItadauUsuarioLocalizacoes = function (itadauUsuarioLocalizacoes) {
        _iniciaTabela();
////        _deleteItadauUsuarioLocalizacoes();
//        var query = "INSERT INTO itadau_usuario_localizacao ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        itadauUsuario, \n\
//                        localizacao, \n\
//                        data, \n\
//                        observacao, \n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?,?,?,?,?)";  
//                
//        angular.forEach(itadauUsuarioLocalizacoes, function (itadauUsuarioLocalizacao,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                itadauUsuarioLocalizacao.id,
//                itadauUsuarioLocalizacao.id,
//                itadauUsuarioLocalizacao.itadauUsuario,
//                itadauUsuarioLocalizacao.localizacao,
//                $rootScope.trataDataNull(itadauUsuarioLocalizacao.data),
//                itadauUsuarioLocalizacao.observacao,
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
    
        _setItadauUsuarioLocalizacoes2(itadauUsuarioLocalizacoes, 0, 'atos_status').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['itadauUsuarioLocalizacaoValido'] = new Date(valido);
            $window.localStorage['itadauUsuarioLocalizacaoAtualizado'] = new Date();
            $window.localStorage['itadauUsuarioLocalizacaoQtde'] = Object.keys(itadauUsuarioLocalizacoes).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setItadauUsuarioLocalizacoes2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.at;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
    //                
            //caso id inserido na API for diferente do aplicativo
            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setItadauUsuarioLocalizacoes2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    function _getUsuarioLocalizacaoParaSincronizar () {
        return SQLiteAPIAbstract.getRegistrosParaSincronizar('itadau_usuario_localizacao');
    }
    
    
    
    return {
        getUsuarioLocalizacaoParaSincronizar: _getUsuarioLocalizacaoParaSincronizar,
        deleteItadauUsuarioLocalizacoes: _deleteItadauUsuarioLocalizacoes,
        buscaItadauUsuarioLocalizacoes: _buscaItadauUsuarioLocalizacoes,
        getItadauUsuarioLocalizacoes: _getItadauUsuarioLocalizacoes,
        getItadauUsuarioLocalizacao: _getItadauUsuarioLocalizacao,
        setItadauUsuarioLocalizacoes: _setItadauUsuarioLocalizacoes,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});