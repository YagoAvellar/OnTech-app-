angular.module("starter").factory("SQLiteAPIatosAtividadeTipo", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    atosAtividadeTipoAPI, SQLiteAPIAbstract) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_atividade_tipo").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atos_atividade_tipo"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atos_atividade_tipo \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            descricao text, \n\
            status text, \n\
            dataAlteracao DATETIME)");
    };
    
    var _buscaAtosAtividadeTipo = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atos_atividade_tipo', data);
    };
    var _getAtosAtividadeTipo = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela();
        var query = "SELECT * FROM atos_atividade_tipo";
        var atos_atividade_tipos = [];
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atos_atividade_tipos[row.id] = row;
            }
            defered.resolve(atos_atividade_tipos);
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    var _deleteAtosAtividadeTipo = function () {
        _iniciaTabela();
        var query = "DELETE FROM atos_atividade_tipo";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtosAtividadeTipo = function (atosAtividadeTipo) {
        _iniciaTabela();
////        _deleteAtosAtividadeTipo(); 
//        var query = "INSERT INTO atos_atividade_tipo ( \n\
//                        id, \n\
//                        descricao, \n\
//                        status) VALUES (?,?,?)";
//        angular.forEach(atosAtividadeTipo, function (atividadeTipo,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atividadeTipo.id, 
//                atividadeTipo.descricao, 
//                atividadeTipo.status]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAtosAtividadeTipo2(atosAtividadeTipo, 0, 'atos_atividade_tipo').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 15);
            $window.localStorage['atosAtividadeTipoValido'] = new Date(valido);
            $window.localStorage['atosAtividadeTipoAtualizado'] = new Date();
            $window.localStorage['atosAtividadeTipoQtde'] = Object.keys(atosAtividadeTipo).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    
    var _setAtosAtividadeTipo2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.at;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setAtosAtividadeTipo2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    return {
        deleteAtosAtividadeTipo: _deleteAtosAtividadeTipo,
        buscaAtosAtividadeTipo: _buscaAtosAtividadeTipo,
        getAtosAtividadeTipo: _getAtosAtividadeTipo,
        setAtosAtividadeTipo: _setAtosAtividadeTipo,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});