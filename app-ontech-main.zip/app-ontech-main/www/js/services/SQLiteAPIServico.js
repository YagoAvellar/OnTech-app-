angular.module("starter").factory("SQLiteAPIServico", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, SQLiteAPIAbstract) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdb_servico").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdb_servico"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdb_servico \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            linhaTipo text, \n\
            linhaDescricao text, \n\
            servicoCodigo text, \n\
            servicoDescricao text, \n\
            valorServico float, \n\
            dataAlteracao DATETIME)");
    };
    
       
    var _buscaServicos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdb_servico', data);
    };
    
    var _getServicos = function (dados) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        var query = "SELECT * FROM atdb_servico";
        if(dados != undefined){
            query+= " WHERE linhaTipo = '"+dados.p1+"' AND  linhaDescricao = '"+dados.p2+"'";
        }
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                var linha = consulta.rows.item(i);
                retorno[linha.id] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    
    var _getServicoTipos = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT linhaTipo, count(linhaTipo) as quantidade FROM atdb_servico GROUP BY linhaTipo";
        var retorno = {};
        
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                var linha = consulta.rows.item(i);
                retorno[linha.linhaTipo] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    var _getServicoLinhas = function (linhaTipo) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        var query = "SELECT linhaDescricao, count(linhaDescricao) as quantidade FROM atdb_servico \n\
                     WHERE linhaTipo = '"+linhaTipo+"'\n\
                     GROUP BY linhaDescricao";
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                var linha = consulta.rows.item(i);
                retorno[linha.linhaDescricao] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    var _getServicoFamilias = function (linhaTipo, linhaDescricao) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        var query = "SELECT familia, count(familia) as quantidade FROM atdb_servico \n\
                     WHERE linhaTipo = '"+linhaTipo+"' AND linhaDescricao = '"+linhaDescricao+"'\n\
                     GROUP BY familia";
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                var linha = consulta.rows.item(i);
                retorno[linha.familia] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    var _deleteServicos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdb_servico";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setServicos = function (servicos) {
        _iniciaTabela();
////        _deleteServicos();
//        var query = "INSERT INTO atdb_servico ( \n\
//                        id, \n\
//                        linhaTipo, \n\
//                        linhaDescricao, \n\
//                        familia, \n\
//                        servicoCodigo, \n\
//                        servicoDescricao) VALUES (?,?,?,?,?,?)";
//        angular.forEach(servicos, function (servico,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                servico.id, 
//                servico.linhaTipo, 
//                servico.linhaDescricao, 
//                servico.familia, 
//                servico.servicoCodigo, 
//                servico.servicoDescricao]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//                if(index == 100){
//                  console.error(err);
//                }
//            });
//        });
        _setServicos2(servicos, 0, 'atdb_servico').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['servicoValido'] = new Date(valido);
            $window.localStorage['servicoAtualizado'] = new Date();
            $window.localStorage['servicoQtde'] = Object.keys(servicos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setServicos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setServicos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    return {
        buscaServicos: _buscaServicos,
        deleteServicos: _deleteServicos,
        getServicoFamilias: _getServicoFamilias,
        getServicoLinhas: _getServicoLinhas,
        getServicoTipos: _getServicoTipos,
        getServicos: _getServicos,
        setServicos: _setServicos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});