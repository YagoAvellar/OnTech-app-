angular.module("starter").factory("SQLiteAPIatdcOcorrenciaExpositor", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI,  SQLiteAPIAbstract, $cordovaFile) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_expositor").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_expositor");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_ocorrencia_expositor \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atdcOcorrencia integer, \n\
            codigoExpositor integer, \n\
            numeroPedido text, \n\
            dataFaturamento DATETIME, \n\
            anexoLayoutVisao text, \n\
            anexoLayoutProposto text, \n\
            dataAtualizacao DATETIME, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
    
    var _buscaAtdcOcorrenciaExpositores = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_ocorrencia_expositor', data);
    };
    
    var _getExpositoresOcorrencia = function (atdcOcorrencia) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_expositores = [];
        var query = "SELECT * FROM atdc_ocorrencia_expositor WHERE atdcOcorrencia = ?";
        
        $cordovaSQLite.execute($rootScope.db, query, [atdcOcorrencia]).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                row.caminhoAnexo = $rootScope.caminhoLayoutProposto + row.anexoLayoutProposto;
                atdc_ocorrencia_expositores.push(row);
            }
            defered.resolve(atdc_ocorrencia_expositores);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
        
    };
    
    var _getAtdcOcorrenciaExpositores = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_expositor";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtdcOcorrenciaExpositor = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_expositor WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteAtdcOcorrenciaExpositores = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_ocorrencia_expositor";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    function _downloadArquivos () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_expositores = [];
        
        if($rootScope.excluindoAntigos){
            setTimeout(_downloadArquivos, 6000);
            defered.resolve(atdc_ocorrencia_expositores);
        }else{
            var query = "SELECT id, anexoLayoutProposto FROM atdc_ocorrencia_expositor WHERE anexoLayoutProposto IS NOT NULL";
            _iniciaTabela(); 
            $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
                for (var i = 0; i < data.rows.length; i++) {
                    var row = data.rows.item(i);
                    atdc_ocorrencia_expositores.push(row);
                }
    //            console.log('atdc_ocorrencia_expositores');
    //            console.log(atdc_ocorrencia_expositores);
    //        console.log(atdc_ocorrencia_expositores.length);
                if(atdc_ocorrencia_expositores.length > 0){
                    defered.resolve(_buscaArquivos(atdc_ocorrencia_expositores, 0));
                }else{
                    defered.resolve(atdc_ocorrencia_expositores);
                }
            }, function (err) {
                defered.reject(err);
            });
        }
        
        return promise;
    }
    
    function _buscaArquivos (atdc_ocorrencia_expositores, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = atdc_ocorrencia_expositores[indice];
        indice++;
        
        $rootScope.verificaArquivo($rootScope.caminhoLayoutProposto, registro.anexoLayoutProposto)
        .then(function (success) {
            if(indice < atdc_ocorrencia_expositores.length){ 
                defered.resolve(_buscaArquivos(atdc_ocorrencia_expositores, indice));
            }else{
                setTimeout(_downloadArquivos, 600000);
                defered.resolve(atdc_ocorrencia_expositores);
            }
        }, function (error) {
            var arquivo = $rootScope.urlLayoutProposto + registro.anexoLayoutProposto;
            $rootScope.Download(arquivo,$rootScope.caminhoLayoutProposto).then(function(retorno){
                if(retorno !== registro.anexoLayoutProposto){
                    registro.anexoLayoutProposto = retorno;
                    SQLiteAPIAbstract.insertOrUpdate ('atdc_ocorrencia_expositor', registro.id, registro);
                }
                if(indice < atdc_ocorrencia_expositores.length){ 
                    defered.resolve(_buscaArquivos(atdc_ocorrencia_expositores, indice));
                }else{
                    setTimeout(_downloadArquivos, 600000);
                    defered.resolve(atdc_ocorrencia_expositores);
                }
            }, function (error) {
                console.error(error);
                if(indice < atdc_ocorrencia_expositores.length){ 
                    defered.resolve(_buscaArquivos(atdc_ocorrencia_expositores, indice));
                }else{
                    setTimeout(_downloadArquivos, 600000);
                    defered.resolve(atdc_ocorrencia_expositores);
                }
            });
        });
        return promise;
    }
    
    var _excluiAntigos = function (dias) {
        var defered = $q.defer();
        var promise = defered.promise;
        var select = 'a.*';
        var query = _getQuery(select, dias);
        
        _getAtdcOcorrenciaExpositoresLimpar (query).then(function (data) {
            select = 'a.id';
//            query = _getQuery(select, dias);            
            query = "DELETE FROM atdc_ocorrencia_expositor WHERE id IN ( "+_getQuery(select, dias)+" )";
            defered.resolve($cordovaSQLite.execute($rootScope.db, query));
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    function _getQuery (select, dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        
        var query = "SELECT "+select+" FROM atdc_ocorrencia_expositor a \n\
                     JOIN atdc_ocorrencia b ON  b.id = a.atdcOcorrencia \n\
                     JOIN atos c ON  c.atdcOcorrencia = b.id \n\
                     ";
        query+= " WHERE b.atdcStatus = 6 \n\
                  AND c.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        
        return query;
    }
    
    
    function _getAtdcOcorrenciaExpositoresLimpar (query) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_expositores = [];
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdc_ocorrencia_expositores.push(row);
            }
            if(atdc_ocorrencia_expositores.length > 0){
                defered.resolve(_excluirAnexos(atdc_ocorrencia_expositores, 0));
            }else{
                defered.resolve(atdc_ocorrencia_expositores);
            }
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    function _excluirAnexos (atdc_ocorrencia_expositores,indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = atdc_ocorrencia_expositores[indice];
        indice++;
        _iniciaTabela(); 
                
        $cordovaFile.checkFile($rootScope.caminhoLayoutProposto,registro.anexoLayoutProposto).then(function (success) {
            $cordovaFile.removeFile($rootScope.caminhoLayoutProposto,registro.anexoLayoutProposto).then(function (success) {
                if(indice < atdc_ocorrencia_expositores.length){
                    defered.resolve(_excluirAnexos(atdc_ocorrencia_expositores, indice));
                }else{
                    defered.resolve(atdc_ocorrencia_expositores);
                }
            }, function (error) {
                if(indice < atdc_ocorrencia_expositores.length){
                    defered.resolve(_excluirAnexos(atdc_ocorrencia_expositores, indice));
                }else{
                    defered.resolve(atdc_ocorrencia_expositores);
                }
            });
        }, function (error) {
            if(indice < atdc_ocorrencia_expositores.length){
                defered.resolve(_excluirAnexos(atdc_ocorrencia_expositores, indice));
            }else{
                defered.resolve(atdc_ocorrencia_expositores);
            }
        });
        
        return promise;
    }
    
    
    return {
        downloadArquivos: _downloadArquivos,
        getExpositoresOcorrencia: _getExpositoresOcorrencia,
        deleteAtdcOcorrenciaExpositores: _deleteAtdcOcorrenciaExpositores,
        buscaAtdcOcorrenciaExpositores: _buscaAtdcOcorrenciaExpositores,
        getAtdcOcorrenciaExpositores: _getAtdcOcorrenciaExpositores,
        getAtdcOcorrenciaExpositor: _getAtdcOcorrenciaExpositor,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});