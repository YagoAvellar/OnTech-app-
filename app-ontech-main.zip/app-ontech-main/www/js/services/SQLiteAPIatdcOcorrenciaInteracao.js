angular.module("starter").factory("SQLiteAPIatdcOcorrenciaInteracao", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, AtdcOcorrenciaInteracaoAPI, SQLiteAPIatdcOcorrenciaLog, SQLiteAPIAbstract) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_interacao").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_interacao");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_ocorrencia_interacao \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atdcOcorrencia integer, \n\
            itadauUsuario integer, \n\
            nomeUsuario text, \n\
            data DATETIME, \n\
            descricao text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
    
    var _buscaAtdcOcorrenciaInteracoes = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_ocorrencia_interacao', data);
    };
    
    var _getInteracoesOcorrencia = function (atdcOcorrencia) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_interacoes = [];
        var query = "SELECT * FROM atdc_ocorrencia_interacao WHERE atdcOcorrencia = ?";
        
        $cordovaSQLite.execute($rootScope.db, query, [atdcOcorrencia]).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdc_ocorrencia_interacoes.push(row);
            }
            defered.resolve(atdc_ocorrencia_interacoes);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
        
    };
    
    var _getAtdcOcorrenciaInteracoes = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_interacao";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtdcOcorrenciaInteracao = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_interacao WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteAtdcOcorrenciaInteracoes = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_ocorrencia_interacao";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtdcOcorrenciaInteracoes = function (atdcOcorrenciaInteracoes) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela();
        _setAtdcOcorrenciaInteracoes2(atdcOcorrenciaInteracoes, 0, 'atdc_ocorrencia_interacao').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atdcOcorrenciaInteracaoValido'] = new Date(valido);
            $window.localStorage['atdcOcorrenciaInteracaoAtualizado'] = new Date();
            $window.localStorage['atdcOcorrenciaInteracaoQtde'] = Object.keys(atdcOcorrenciaInteracoes).length;
            defered.resolve(atdcOcorrenciaInteracoes);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _setAtdcOcorrenciaInteracoes2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
            registro.data = $rootScope.trataDataNull(registro.data);

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setAtdcOcorrenciaInteracoes2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    function _getAtdcOcorrenciaInteracoesParaSincronizar () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_interacoes = [];
        var query = "SELECT * FROM atdc_ocorrencia_interacao WHERE sincronizado = 0 OR sincronizado = null";
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdc_ocorrencia_interacoes.push(row);
            }
            defered.resolve(atdc_ocorrencia_interacoes);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    function _enviaAtdcOcorrenciaInteracoes (atdc_ocorrencia_interacoes) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela(); 
        $http.post($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia?sync=enviar', atdc_ocorrencia_interacoes).then(function (data) {
            _retiraAtdcOcorrenciaInteracaoSincronizacao(data.data, 0).then(function (data) {
                defered.resolve(data);
            }, function (err) {
                defered.reject(err);
            });
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    var _retiraAtdcOcorrenciaInteracaoSincronizacao = function (retorno, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var id = retorno[indice].id;
        indice++;
        
        var query = "UPDATE atdc_ocorrencia_interacao set sincronizado = 1 WHERE id = ?";
        
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function (data) {
            if(indice < retorno.qtde){
                return _retiraAtdcOcorrenciaInteracaoSincronizacao(retorno, indice);
            }else{
                defered.resolve(retorno);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _excluiAntigos = function (dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT a.id FROM atdc_ocorrencia_interacao a \n\
                     JOIN atdc_ocorrencia b ON  b.id = a.atdcOcorrencia \n\
                     JOIN atos c ON  c.atdcOcorrencia = b.id \n\
                     ";
        query+= " WHERE b.atdcStatus = 6 \n\
                  AND c.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        
        query = "DELETE FROM atdc_ocorrencia_interacao WHERE id IN ( "+query+" )";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
        
    var _adicionaInteracao = function (ocorrenciaInteracao) {
        var defered = $q.defer();
        var promise = defered.promise;
        var timeNow = new Date();
        var interacao = {
            'atdcOcorrencia'    : ocorrenciaInteracao.atdcOcorrencia,
            'data'              : $rootScope.converteObjetoDataPost(timeNow),
            'itadauUsuario'     : ocorrenciaInteracao.itadauUsuario,
            'nomeUsuario'       : ocorrenciaInteracao.nomeUsuario,
            'descricao'         : ocorrenciaInteracao.descricao
        };
        SQLiteAPIAbstract.insert('atdc_ocorrencia_interacao', interacao).then(function(data){
            SQLiteAPIatdcOcorrenciaLog.add(interacao.atdcOcorrencia,'interacao', interacao.descricao);
            defered.resolve((data)); 
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        return promise;
    }; 
    
    return {
        getInteracoesOcorrencia: _getInteracoesOcorrencia,
        enviaAtdcOcorrenciaInteracoes: _enviaAtdcOcorrenciaInteracoes,
        getAtdcOcorrenciaInteracoesParaSincronizar: _getAtdcOcorrenciaInteracoesParaSincronizar,
        deleteAtdcOcorrenciaInteracoes: _deleteAtdcOcorrenciaInteracoes,
        buscaAtdcOcorrenciaInteracoes: _buscaAtdcOcorrenciaInteracoes,
        getAtdcOcorrenciaInteracoes: _getAtdcOcorrenciaInteracoes,
        getAtdcOcorrenciaInteracao: _getAtdcOcorrenciaInteracao,
        setAtdcOcorrenciaInteracoes: _setAtdcOcorrenciaInteracoes,
        adicionaInteracao: _adicionaInteracao,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});