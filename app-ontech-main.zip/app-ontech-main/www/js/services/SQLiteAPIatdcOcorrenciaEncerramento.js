angular.module("starter").factory("SQLiteAPIatdcOcorrenciaEncerramento", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, AtdcOcorrenciaEncerramentoAPI, SQLiteAPIatdcOcorrenciaLog, SQLiteAPIAbstract) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_encerramento").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_ocorrencia_encerramento");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_ocorrencia_encerramento \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            atdcOcorrencia integer, \n\
            itadauUsuario integer, \n\
            atdcEncerramento integer, \n\
            data DATETIME, \n\
            observacao text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
    
    
    var _buscaAtdcOcorrenciaEncerramentos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_ocorrencia_encerramento', data);
    };
    
    var _getAtdcOcorrenciaEncerramentos = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_encerramento";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtdcOcorrenciaEncerramento = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_ocorrencia_encerramento WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteAtdcOcorrenciaEncerramentos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_ocorrencia_encerramento";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtdcOcorrenciaEncerramentos = function (atdcOcorrenciaEncerramentos) {
        _iniciaTabela();
//        _deleteAtdcOcorrenciaEncerramentos();
//        var query = "INSERT INTO atdc_ocorrencia_encerramento ( \n\
//                        id, \n\
//                        idAPI, \n\
//                        atdcOcorrencia, \n\
//                        itadauUsuario, \n\
//                        atdcEncerramento, \n\
//                        data, \n\
//                        observacao, \n\
//                        sincronizado) VALUES (?,?,?,?,?,?,?,?)";        
//        
//        angular.forEach(atdcOcorrenciaEncerramentos, function (atdcOcorrenciaEncerramento,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atdcOcorrenciaEncerramento.id, 
//                atdcOcorrenciaEncerramento.id, 
//                atdcOcorrenciaEncerramento.atdcOcorrencia, 
//                atdcOcorrenciaEncerramento.itadauUsuario, 
//                atdcOcorrenciaEncerramento.atdcEncerramento, 
//                $rootScope.trataDataNull(atdcOcorrenciaEncerramento.data), 
//                atdcOcorrenciaEncerramento.observacao,
//                1 ]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAtdcOcorrenciaEncerramentos2(atdcOcorrenciaEncerramentos, 0, 'atdc_ocorrencia_encerramento').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atdcOcorrenciaEncerramentoValido'] = new Date(valido);
            $window.localStorage['atdcOcorrenciaEncerramentoAtualizado'] = new Date();
            $window.localStorage['atdcOcorrenciaEncerramentoQtde'] = Object.keys(atdcOcorrenciaEncerramentos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setAtdcOcorrenciaEncerramentos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;
        
            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;
            registro.data = $rootScope.trataDataNull(registro.data);

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setAtdcOcorrenciaEncerramentos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err);
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    function _getAtdcOcorrenciaEncerramentosParaSincronizar () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdc_ocorrencia_encerramentos = [];
        var query = "SELECT * FROM atdc_ocorrencia_encerramento WHERE sincronizado = 0 OR sincronizado = null";
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdc_ocorrencia_encerramentos.push(row);
            }
            defered.resolve(atdc_ocorrencia_encerramentos);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    function _enviaAtdcOcorrenciaEncerramentos (atdc_ocorrencia_encerramentos) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela(); 
        $http.post($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia?sync=enviar', atdc_ocorrencia_encerramentos).then(function (data) {
            _retiraAtdcOcorrenciaEncerramentoSincronizacao(data.data, 0).then(function (data) {
                defered.resolve(data);
            }, function (err) {
                defered.reject(err);
            });
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    var _retiraAtdcOcorrenciaEncerramentoSincronizacao = function (retorno, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var id = retorno[indice].id;
        indice++;
        
        var query = "UPDATE atdc_ocorrencia_encerramento set sincronizado = 1 WHERE id = ?";
        
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function (data) {
            if(indice < retorno.qtde){
                return _retiraAtdcOcorrenciaEncerramentoSincronizacao(retorno, indice);
            }else{
                defered.resolve(retorno);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _excluiAntigos = function (dias) {
        if(dias === undefined){
            dias = 30;
        }
        var dataLimite = new Date();
        dataLimite.setDate(dataLimite.getDate() - dias);
        
        var query = "SELECT a.id FROM atdc_ocorrencia_encerramento a \n\
                     JOIN atdc_ocorrencia b ON  b.id = a.atdcOcorrencia \n\
                     JOIN atos c ON  c.atdcOcorrencia = b.id \n\
                     ";
        query+= " WHERE b.atdcStatus = 6 \n\
                  AND c.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
                  AND a.sincronizado = 1";
        
        query = "DELETE FROM atdc_ocorrencia_encerramento WHERE id IN ( "+query+" )";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    
    
    return {
        enviaAtdcOcorrenciaEncerramentos: _enviaAtdcOcorrenciaEncerramentos,
        getAtdcOcorrenciaEncerramentosParaSincronizar: _getAtdcOcorrenciaEncerramentosParaSincronizar,
        deleteAtdcOcorrenciaEncerramentos: _deleteAtdcOcorrenciaEncerramentos,
        buscaAtdcOcorrenciaEncerramentos: _buscaAtdcOcorrenciaEncerramentos,
        getAtdcOcorrenciaEncerramentos: _getAtdcOcorrenciaEncerramentos,
        getAtdcOcorrenciaEncerramento: _getAtdcOcorrenciaEncerramento,
        setAtdcOcorrenciaEncerramentos: _setAtdcOcorrenciaEncerramentos,
        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});