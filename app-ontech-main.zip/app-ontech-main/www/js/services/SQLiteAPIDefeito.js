angular.module("starter").factory("SQLiteAPIDefeito", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, SQLiteAPIAbstract) {
    
    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_grupo_defeito").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_grupo_defeito"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_grupo_defeito \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            atdcGrupo integer, \n\
            descricao text, \n\
            sla text, \n\
            status text, \n\
            dataAlteracao DATETIME)");
    };
    
    
    
    var _buscaDefeitos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_grupo_defeito', data);
    };
    
    var _getDefeitos = function (atdcGrupo) {
        var defered = $q.defer();
        var promise = defered.promise;
        var opcoesDefeito = {};
        var query = "SELECT A.*, B.descricao as atdcGrupoDescricao \n\
                     FROM atdc_grupo_defeito A JOIN atdc_grupo B ON B.id = a.atdcGrupo";
        if(atdcGrupo !== undefined && atdcGrupo > 0){
            query += " WHERE atdcGrupo = "+atdcGrupo;
        }
        
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                opcoesDefeito[row.id] = row;
            }
            defered.resolve(opcoesDefeito);
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _getDefeito = function (id) {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT A.*, B.descricao as atdcGrupoDescricao \n\
                     FROM atdc_grupo_defeito A JOIN atdc_grupo B ON B.id = a.atdcGrupo\n\
                     WHERE A.id = "+id;
        
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            if(data.rows.length > 0){
                defered.resolve(data.rows.item(0));
            }else{
                defered.reject("defeito não encontrado");
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    var _deleteDefeitos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_grupo_defeito";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setDefeitos = function (defeitos) {
        _iniciaTabela();
//        _deleteDefeitos();
//        var query = "INSERT INTO atdc_grupo_defeito ( \n\
//                        id, \n\
//                        atdcGrupo, \n\
//                        descricao, \n\
//                        sla, \n\
//                        status) VALUES (?,?,?,?,?)";
//        angular.forEach(defeitos, function (defeito,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                defeito.id, 
//                defeito.atdcGrupo, 
//                defeito.descricao, 
//                defeito.sla, 
//                defeito.status]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setDefeitos2(defeitos, 0, 'atdc_grupo_defeito').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 15);
            $window.localStorage['defeitoValido'] = new Date(valido);
            $window.localStorage['defeitoAtualizado'] = new Date();
            $window.localStorage['defeitoQtde'] = Object.keys(defeitos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setDefeitos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.dataAlteracao;
            delete registro.sincronizado;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setDefeitos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.log(registro);
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    return {
        deleteDefeitos: _deleteDefeitos,
        buscaDefeitos: _buscaDefeitos,
        getDefeitos: _getDefeitos,
        getDefeito: _getDefeito,
        setDefeitos: _setDefeitos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});