angular.module("starter").factory("SQLiteAPIProdutoAjuda", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, ProdutoAjudaAPI, SQLiteAPIAbstract, $cordovaFile) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdb_produto_ajuda").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdb_produto_ajuda");
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdb_produto_ajuda \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            idAPI integer, \n\
            idApp integer, \n\
            produtoCodigo integer, \n\
            descricao text, \n\
            anexo text, \n\
            dataAlteracao DATETIME, \n\
            dataSincronizacao DATETIME, \n\
            sincronizado integer)");
    };
    
    var _buscaProdutoDocumentacoes = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdb_produto_ajuda', data);
    };
    
    var _getDocumentacoesProduto = function (produtoCodigo) {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdb_produto_documentacoes = [];
        var query = "SELECT * FROM atdb_produto_ajuda WHERE produtoCodigo = ?";
        
        $cordovaSQLite.execute($rootScope.db, query, [produtoCodigo]).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                row.caminhoDocumentacao = $rootScope.caminhoDocumentacao + produtoCodigo + '/' + row.anexo;
                atdb_produto_documentacoes.push(row);
            }
            defered.resolve(atdb_produto_documentacoes);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
        
    };
    
    var _getProdutoDocumentacoes = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdb_produto_ajuda";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getProdutoAjuda = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdb_produto_ajuda WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteProdutoDocumentacoes = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdb_produto_ajuda";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setProdutoDocumentacoes = function (produtoDocumentacoes) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela();
        _setProdutoDocumentacoes2(produtoDocumentacoes, 0, 'atdb_produto_ajuda').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['produtoAjudaValido'] = new Date(valido);
            $window.localStorage['produtoAjudaAtualizado'] = new Date();
            $window.localStorage['produtoAjudaQtde'] = Object.keys(produtoDocumentacoes).length;
            defered.resolve(produtoDocumentacoes);
        }, function(err){
            console.error(err);
            defered.reject(err);
        });
        
        return promise;
    };
    
    var _setProdutoDocumentacoes2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
    //        delete registro.dataAlteracao;
            delete registro._embedded;
            registro.sincronizado = 1;
            registro.idAPI = registro.id;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setProdutoDocumentacoes2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    function _getProdutoDocumentacoesParaSincronizar () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdb_produto_documentacoes = [];
        var query = "SELECT * FROM atdb_produto_ajuda WHERE sincronizado = 0 OR sincronizado = null";
        _iniciaTabela(); 
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdb_produto_documentacoes.push(row);
            }
            defered.resolve(atdb_produto_documentacoes);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    function _enviaProdutoDocumentacoes (atdb_produto_documentacoes) {
        var defered = $q.defer();
        var promise = defered.promise;
        _iniciaTabela(); 
        $http.post($rootScope.configEmpresa.baseUrl + '/atdc-ocorrencia?sync=enviar', atdb_produto_documentacoes).then(function (data) {
            _retiraProdutoAjudaSincronizacao(data.data, 0).then(function (data) {
                defered.resolve(data);
            }, function (err) {
                defered.reject(err);
            });
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    var _retiraProdutoAjudaSincronizacao = function (retorno, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var id = retorno[indice].id;
        indice++;
        
        var query = "UPDATE atdb_produto_ajuda set sincronizado = 1 WHERE id = ?";
        
        $cordovaSQLite.execute($rootScope.db, query,[id]).then(function (data) {
            if(indice < retorno.qtde){
                return _retiraProdutoAjudaSincronizacao(retorno, indice);
            }else{
                defered.resolve(retorno);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    function _downloadArquivos () {
        var defered = $q.defer();
        var promise = defered.promise;
        var atdb_produto_documentacoes = [];
        var query = "SELECT id, produtoCodigo, anexo FROM atdb_produto_ajuda";
        _iniciaTabela(); 
//        console.log('teste123');
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atdb_produto_documentacoes.push(row);
            }
            defered.resolve(_buscaArquivos(atdb_produto_documentacoes, 0));
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    }
    
    function _buscaArquivos (atdb_produto_documentacoes, indice) {
        var defered = $q.defer();
        var promise = defered.promise;
        var registro = atdb_produto_documentacoes[indice];
//        console.log(atdb_produto_documentacoes);
        indice++;
        if(registro){
            $cordovaFile.checkFile($rootScope.caminhoDocumentacao+registro.produtoCodigo+'/', registro.anexo)
            .then(function (success) {
//                console.log('success');
//                console.log(success);
                if(indice < atdb_produto_documentacoes.length){ 
                    defered.resolve(_buscaArquivos(atdb_produto_documentacoes, indice));
                }else{
                    setTimeout(_downloadArquivos, 600000);
                    defered.resolve(atdb_produto_documentacoes);
                }
            }, function (error) {
//                console.log('error');
//                console.log(error);
                var arquivo = $rootScope.urlDocumentacao+registro.produtoCodigo+'/' + registro.anexo;
                var caminhoUrl = $rootScope.caminhoDocumentacao+registro.produtoCodigo+'/';
//                console.log(caminhoUrl);
                $rootScope.Download(arquivo,caminhoUrl).then(function(retorno){
                    if(retorno !== registro.anexo){
                        registro.anexo = retorno;
                        SQLiteAPIAbstract.insertOrUpdate ('atdb_produto_ajuda', registro.id, registro, false);
                    }
                    if(indice < atdb_produto_documentacoes.length){ 
                        defered.resolve(_buscaArquivos(atdb_produto_documentacoes, indice));
                    }else{
                        setTimeout(_downloadArquivos, 600000);
                        defered.resolve(atdb_produto_documentacoes);
                    }
                }, function (error) {
                    if(indice < atdb_produto_documentacoes.length){ 
                        defered.resolve(_buscaArquivos(atdb_produto_documentacoes, indice));
                    }else{
                        setTimeout(_downloadArquivos, 600000);
                        defered.resolve(atdb_produto_documentacoes);
                    }
                });
            });
        }else{
            defered.resolve(atdb_produto_documentacoes);
        }
        return promise;
    }
    
    return {
        downloadArquivos: _downloadArquivos,
        getDocumentacoesProduto: _getDocumentacoesProduto,
        enviaProdutoDocumentacoes: _enviaProdutoDocumentacoes,
        getProdutoDocumentacoesParaSincronizar: _getProdutoDocumentacoesParaSincronizar,
        deleteProdutoDocumentacoes: _deleteProdutoDocumentacoes,
        buscaProdutoDocumentacoes: _buscaProdutoDocumentacoes,
        getProdutoDocumentacoes: _getProdutoDocumentacoes,
        getProdutoAjuda: _getProdutoAjuda,
        setProdutoDocumentacoes: _setProdutoDocumentacoes,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});