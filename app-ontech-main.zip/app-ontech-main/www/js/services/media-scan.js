angular.module("cordova.file.media", []).service('Media', ['$q', '$rootScope', '$cordovaFile', function ($q, $rootScope, $cordovaFile) {

        var d = new Date();
        d.setDate(d.getDate() - 30);
        var limiteExcluirAntigos = d.getTime();

            
        //var permission =undefined;
        var _permission = function (callback)
        {
            var READ, WRITE = undefined;
            var permissionType = undefined;

            if (window.cordova)
            {
                /*Request Runtime PErmissions*/
                cordova.plugins.diagnostic.requestRuntimePermissions(function (statuses)
                {
                    for (var permission in statuses)
                    {
                        switch (statuses[permission])
                        {
                            case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                            {
                                //	permission ="GRANTED";
                                console.log("Permission granted to use " + permission);
                                if (permission == "WRITE_EXTERNAL_STORAGE")
                                {
                                    WRITE = true;
                                    //defer.resolve(fileTypeCollection);
                                }
                                if (permission == "READ_EXTERNAL_STORAGE")
                                {
                                    READ = true;
                                    //defer.resolve(fileTypeCollection);
                                }
                                break;
                                /*Case Ends*/
                            }


                            case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                            {
                                console.log("Permission to use " + permission + " has not been requested yet");
                                permissionType = "NOT_REQUESTED";
                                break;
                            }
                            case cordova.plugins.diagnostic.permissionStatus.DENIED:
                            {
                                permissionType = "DENIED";
                                console.log("Permission denied to use " + permission + " - ask again?");
                                break;
                            }
                            case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                            {
                                permissionType = "DENIED_ALWAYS";
                                console.log("Permission permanently denied to use " + permission + " - guess we won't be using it then!");
                                break;
                            }
                        }
                    }

                    /*Check Permission*/
                    if (WRITE && READ)
                    {
                        permissionType = "GRANTED";
                        callback(permissionType);
                    } else
                    {
                        callback(permissionType);
                    }


                }, function (error)
                {
                    console.error("The following error occurred: " + error);
                    callback(error);
                },
                        [
                            cordova.plugins.diagnostic.runtimePermission.WRITE_EXTERNAL_STORAGE,
                            cordova.plugins.diagnostic.runtimePermission.READ_EXTERNAL_STORAGE
                        ]);
                console.log("EO Permission Scan in Cordova ENV");
            } else
            {
                console.log("No Cordova Installed.Cannot Seek Permission");
                callback();
            }

            console.log("Permission ENDS");

        };

        var _scan = function (url, fileType)
        {
            var defer = $q.defer();

            if (window.cordova)
            {

                var fileTypeCollection = [];

                url.forEach(function (element, index)
                {
                    //requestLocalFileSystemURL
//                    console.log(element);
                    window.resolveLocalFileSystemURL(element, onRequestFileSystem, fail);

//                    console.log("Ends resolve");
                });


                function onRequestFileSystem(fileSystem)
                {
//                    console.log(fileSystem.toURL());
//                    console.log(fileSystem.toInternalURL());
                    var directoryReader = fileSystem.createReader();
                    directoryReader.readEntries(onReadEntries, fail);


                } /*onRequestFile Ends*/

                function onReadEntries(entries)
                {
                    
                    if(entries.length > 0){
                        entries.forEach(function (element, index)
                        {

                            if (element.isDirectory === true)
                            {
                                // Recursive -- call back into this subdirectory
                                onRequestFileSystem(element);
                            } else if (element.isFile == true)
                            {

                                fileType.forEach(function (type)
                                {
                                    if (element.name.indexOf(type) != -1)
                                    {
    //                                    console.log(element.toURL());
                                        fileTypeCollection.push(element);
                                        defer.resolve(fileTypeCollection);
                                        //callback(fileTypeCollection);
                                    }
                                });
                            } /*is File ENds*/

                        });  /*Entries For Each Ends*/
                    }else{
                        defer.resolve(fileTypeCollection);
                    }

                }  /*OnRead Ends*/

                function fail(resp)
                {

//                    console.log(resp);
                    defer.resolve(fileTypeCollection);

                }  /*Fail Ends*/

            } else
            {
                console.log("No Cordova Installed.Cannot Seek File");
                defer.reject();
                //callback(undefined);

            }
//            console.log(fileTypeCollection);
//            console.log("Before Resolve");
            return  defer.promise;

        };  //Scan Function Ends


        var _removeDuplicates = function (originalArray, prop)
        {
            var newArray = [];
            var lookupObject = {};

            for (var i in originalArray) {
                lookupObject[originalArray[i][prop]] = originalArray[i];
            }

            for (i in lookupObject) {
                newArray.push(lookupObject[i]);
            }
            return newArray;
        };  //Remove Ends
        
        var _folderSize = function (pasta)
        {
            var defered = $q.defer();
            var promise = defered.promise;
            var url = [pasta];
            var fileType = ['.'];
            _scan(url,fileType).then(function(arquivos)
            {
//                console.log('arquivos');
//                console.log(arquivos);
                if(arquivos.length > 0){
                    defered.resolve(_tamanho(arquivos,0,0)); 
                }else{
                    defered.resolve(0);
                }

            },function (error){
                console.error(error);
            });
            
            return promise;
            
        }; 
        
        
        var _buscarMaisAntigos = function(array, arrayRetorno, indice){
            var defered = $q.defer();
            var promise = defered.promise;
            var arquivo = array[indice];
            indice++;
            
            arquivo.file(function (success) {
                if(limiteExcluirAntigos > success.lastModifiedDate){
                    arrayRetorno.push(arquivo);
                }
                if(indice < array.length){
                    defered.resolve(_buscarMaisAntigos(array, arrayRetorno, indice));
                }else{
                    defered.resolve(arrayRetorno);
                }
            }, function (error) {
                $rootScope.geraLog(error, new Error());
                defered.resolve(arrayRetorno);
            });
            
            return promise;
        };
        
        var _excluirArquivos = function(array, arrayRetorno, indice){
            var defered = $q.defer();
            var promise = defered.promise;
            var arquivo = array[indice];
            indice++;
//            console.log('array.length');
//            console.log(array.length);
//            console.log('indice');
//            console.log(indice);
//            
//            console.log('arquivo');
//            console.log(arquivo);
            var url = arquivo.nativeURL.toString();
            var caminho = url.substring(0, parseInt(url.lastIndexOf('/'))+1);
            var arquivo2 = url.substring(url.lastIndexOf('/')+1, url.length);
//            console.log('url');
//            console.log(url);
//            console.log('caminho');
//            console.log(caminho);
//            
//            console.log('arquivo2');
//            console.log(arquivo2);
//            
//            console.log('arquivo');
//            console.log(arquivo.nativeURL);
            
            
            $cordovaFile.removeFile(caminho,arquivo2).then(function (success) {
                arrayRetorno.push(success);
                if(indice < array.length){
                    defered.resolve(_excluirArquivos(array, arrayRetorno, indice));
                }else{
                    defered.resolve(arrayRetorno);
                }
            }, function (error) { 
                arrayRetorno.push(error);
                if(indice < array.length){
                    defered.resolve(_excluirArquivos(array, arrayRetorno, indice));
                }else{
                    defered.resolve(arrayRetorno);
                }
                console.error(error);
//                $rootScope.geraLog(error, new Error());
            });
            
            
            
            return promise;
        };

        
        var _excluiAntigos = function (pasta)
        {
            var defered = $q.defer();
            var promise = defered.promise;
            var url = [pasta];
            var fileType = ['.'];
            
            _scan(url,fileType).then(function(arquivos)
            {
//                console.log('arquivos');
//                console.log(arquivos);
                if(arquivos.length > 0){
                    _buscarMaisAntigos(arquivos,[],0).then(function(arquivosExcluir)
                    {
//                    console.log('arquivosExcluir');
//                    console.log(arquivosExcluir);
                        if(arquivosExcluir.length > 0){
                            defered.resolve(_excluirArquivos(arquivosExcluir, [], 0));
                        }else{
                            defered.resolve(arquivosExcluir);
                        }

                    });
                }else{
                    defered.resolve(arquivos);
                }

            });
            
            return promise;
            
        }; 
        
        var _tamanho = function(array, tamanho, indice){
            var defered = $q.defer();
            var promise = defered.promise;
            var arquivo = array[indice];
            indice++;
            
//            console.log(indice +' < '+array.length);
//            console.log('indice < array.length');
//            console.log(indice < array.length);
            
            arquivo.file(function (success) {
//                console.log('infoArquivo');
//                console.log(success.lastModifiedDate);
                
//                var timeNow = new Date(success.lastModifiedDate);
//                var texto = "Data: "+$filter('date')(timeNow, 'dd/MM/yyyy HH:mm:ss')+"\n";
//                console.log(texto);
                
                
                tamanho+= success.size;
//                console.log('tamanho');
//                console.log(tamanho);
                if(indice < array.length){
                    defered.resolve(_tamanho(array, tamanho, indice));
                }else{
                    defered.resolve(tamanho);
                }
            }, function (error) {
                $rootScope.geraLog(error, new Error());
                defered.resolve(tamanho);
            });
            
            return promise;
        };


        return {
            permission: _permission,
            scan: _scan, //Scan Function Ends
            removeDuplicates: _removeDuplicates,  //Remove Ends
            folderSize : _folderSize,
            excluiAntigos : _excluiAntigos

        };  //Return Ends

    }]);
