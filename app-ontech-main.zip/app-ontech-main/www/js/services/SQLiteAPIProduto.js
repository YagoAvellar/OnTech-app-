angular.module("starter").factory("SQLiteAPIProduto", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, produtosAPI, SQLiteAPIAbstract) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdb_produto").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdb_produto"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdb_produto \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            linhaTipo text, \n\
            linhaDescricao text, \n\
            familia text, \n\
            produtoCodigo text, \n\
            produtoDescricao text, \n\
            dataAlteracao DATETIME)");
    };
    
       
    var _buscaProdutos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdb_produto', data);
    };
    
    var _getProdutos = function (dados) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        var query = "SELECT * FROM atdb_produto";
        if(dados != undefined){
            query+= " WHERE linhaTipo = '"+dados.p1+"' AND  linhaDescricao = '"+dados.p2+"' AND  familia = '"+dados.p3+"'";
        }
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                var linha = consulta.rows.item(i);
                retorno[linha.id] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    
    var _getProdutoTipos = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT linhaTipo, count(linhaTipo) as quantidade FROM atdb_produto GROUP BY linhaTipo";
        var retorno = {};
        
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                var linha = consulta.rows.item(i);
                retorno[linha.linhaTipo] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    var _getProdutoLinhas = function (linhaTipo) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        var query = "SELECT linhaDescricao, count(linhaDescricao) as quantidade FROM atdb_produto \n\
                     WHERE linhaTipo = '"+linhaTipo+"'\n\
                     GROUP BY linhaDescricao";
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                var linha = consulta.rows.item(i);
                retorno[linha.linhaDescricao] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    var _getProdutoFamilias = function (linhaTipo, linhaDescricao) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
        var query = "SELECT familia, count(familia) as quantidade FROM atdb_produto \n\
                     WHERE linhaTipo = '"+linhaTipo+"' AND linhaDescricao = '"+linhaDescricao+"'\n\
                     GROUP BY familia";
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                var linha = consulta.rows.item(i);
                retorno[linha.familia] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    var _deleteProdutos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdb_produto";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setProdutos = function (produtos) {
        _iniciaTabela();
////        _deleteProdutos();
//        var query = "INSERT INTO atdb_produto ( \n\
//                        id, \n\
//                        linhaTipo, \n\
//                        linhaDescricao, \n\
//                        familia, \n\
//                        produtoCodigo, \n\
//                        produtoDescricao) VALUES (?,?,?,?,?,?)";
//        angular.forEach(produtos, function (produto,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                produto.id, 
//                produto.linhaTipo, 
//                produto.linhaDescricao, 
//                produto.familia, 
//                produto.produtoCodigo, 
//                produto.produtoDescricao]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//                if(index == 100){
//                  console.error(err);
//                }
//            });
//        });
        _setProdutos2(produtos, 0, 'atdb_produto').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 30);
            $window.localStorage['produtoValido'] = new Date(valido);
            $window.localStorage['produtoAtualizado'] = new Date();
            $window.localStorage['produtoQtde'] = Object.keys(produtos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setProdutos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setProdutos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    return {
        buscaProdutos: _buscaProdutos,
        deleteProdutos: _deleteProdutos,
        getProdutoFamilias: _getProdutoFamilias,
        getProdutoLinhas: _getProdutoLinhas,
        getProdutoTipos: _getProdutoTipos,
        getProdutos: _getProdutos,
        setProdutos: _setProdutos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});