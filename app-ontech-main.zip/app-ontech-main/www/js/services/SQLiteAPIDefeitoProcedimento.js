angular.module("starter").factory("SQLiteAPIDefeitoProcedimento", function ($http, $q, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, SQLiteAPIAbstract) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_grupo_defeito_procedimento").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_grupo_defeito_procedimento"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_grupo_defeito_procedimento \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            atdcGrupoDefeito integer, \n\
            descricao text, \n\
            status text, \n\
            dataAlteracao DATETIME)");
    };
    
    
    var _buscaDefeitoProcedimentos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_grupo_defeito_procedimento', data);
    };
    
    var _getDefeitoProcedimentos = function (defeito) {
        var defered = $q.defer();
        var promise = defered.promise;
        var retorno = {};
//        console.log('defeito');
//        console.log(defeito);
        var query = "SELECT * FROM atdc_grupo_defeito_procedimento";
        if(defeito !== undefined && defeito > 0){
            query += " WHERE atdcGrupoDefeito = "+defeito;
        }
//        console.log(query);
        $cordovaSQLite.execute($rootScope.db, query).then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                retorno[row.id] = row;
            }
            defered.resolve(retorno);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    };
    var _deleteDefeitoProcedimentos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_grupo_defeito_procedimento";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setDefeitoProcedimentos = function (defeitoProcedimentos) {
        _iniciaTabela();
////        _deleteDefeitoProcedimentos();
//        var query = "INSERT INTO atdc_grupo_defeito_procedimento ( \n\
//                        id, \n\
//                        atdcGrupoDefeito, \n\
//                        descricao, \n\
//                        status) VALUES (?,?,?,?)";
//        angular.forEach(defeitoProcedimentos, function (defeitoProcedimento,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                defeitoProcedimento.id, 
//                defeitoProcedimento.atdcGrupoDefeito, 
//                defeitoProcedimento.descricao, 
//                defeitoProcedimento.status]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        
        _setDefeitoProcedimentos2(defeitoProcedimentos, 0, 'atdc_grupo_defeito_procedimento').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 15);
            $window.localStorage['defeitoProcedimentoValido'] = new Date(valido);
            $window.localStorage['defeitoProcedimentoAtualizado'] = new Date();
            $window.localStorage['defeitoProcedimentoQtde'] = Object.keys(defeitoProcedimentos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setDefeitoProcedimentos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.dataAlteracao;
            delete registro.sincronizado;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){ 
                    defered.resolve(_setDefeitoProcedimentos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    
    return {
        deleteDefeitoProcedimentos: _deleteDefeitoProcedimentos,
        buscaDefeitoProcedimentos: _buscaDefeitoProcedimentos,
        getDefeitoProcedimentos: _getDefeitoProcedimentos,
        setDefeitoProcedimentos: _setDefeitoProcedimentos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});