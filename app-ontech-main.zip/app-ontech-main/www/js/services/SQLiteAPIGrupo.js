angular.module("starter").factory("SQLiteAPIGrupo", function ($q, $http, config, $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, SQLiteAPIAbstract) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_grupo").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_grupo"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_grupo \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            tipo text, \n\
            descricao text, \n\
            status text, \n\
            dataAlteracao DATETIME)");
    };
    
    var _getGruposAPI = function () {
        return $http.get($rootScope.configEmpresa.baseUrl + '/atdc-grupo');
    };    
    
    
    var _buscaGrupos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_grupo', data);
    };
    
    var _getGrupos = function () {
        return SQLiteAPIAbstract.fetchAll('atdc_grupo');
    };
    
    var _getGruposAtivos = function (tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        var query = "SELECT DISTINCT g.* FROM atdc_grupo g JOIN atdc_grupo_defeito d ON d.atdcGrupo = g.id";
        var retorno = {};
        var linha = {};
        $cordovaSQLite.execute($rootScope.db, query).then(function(consulta){
            for (var i = 0; i < consulta.rows.length; i++) {
                linha = consulta.rows.item(i);
                retorno[linha.id] = linha;
            }
            defered.resolve(retorno);
        }, function(err){
            defered.reject(err);
        });
        return promise;
    };
    
    var _deleteGrupos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_grupo";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setGrupos = function (defeitos) {
        _iniciaTabela();
////        _deleteGrupos();
//        var query = "INSERT INTO atdc_grupo ( \n\
//                        id, \n\
//                        tipo, \n\
//                        descricao, \n\
//                        status) VALUES (?,?,?,?)";
//        angular.forEach(defeitos, function (defeito,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                defeito.id, 
//                defeito.tipo, 
//                defeito.descricao, 
//                defeito.status]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setGrupos2(defeitos, 0, 'atdc_grupo').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 15);
            $window.localStorage['grupoDefeitoValido'] = new Date(valido);
            $window.localStorage['grupoDefeitoAtualizado'] = new Date();
            $window.localStorage['grupoDefeitoQtde'] = Object.keys(defeitos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setGrupos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
            delete registro._embedded;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setGrupos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
    return {
        getGruposAtivos: _getGruposAtivos,
        deleteGrupos: _deleteGrupos,
        buscaGrupos: _buscaGrupos,
        getGrupos: _getGrupos,
        setGrupos: _setGrupos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});