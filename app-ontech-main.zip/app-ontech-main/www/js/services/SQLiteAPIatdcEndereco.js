angular.module("starter").factory("SQLiteAPIatdcEndereco", function ($http, $q, config,  $rootScope, $httpParamSerializer, $cordovaSQLite, $window, 
    ordemServicoAPI, AtdcEnderecoAPI, SQLiteAPIAbstract) {

    var _apagaTabela = function () {
        var defered = $q.defer();
        var promise = defered.promise;
        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_endereco").then(function (data) {
            defered.resolve(_iniciaTabela());
        }, function(err){
            console.error(err); 
            defered.reject(err);
        });
        return promise;
    };
    var _iniciaTabela = function () {
//        $cordovaSQLite.execute($rootScope.db, "DROP TABLE atdc_endereco"); 
        return $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS atdc_endereco \n\
            (id INTEGER NOT NULL PRIMARY KEY, \n\
            atdc integer, \n\
            tipo text, \n\
            cep text, \n\
            rua text, \n\
            numero text, \n\
            complemento text, \n\
            bairro text, \n\
            cidade text, \n\
            estado text, \n\
            referencia text, \n\
            localizacao text, \n\
            dataAlteracao DATETIME)");
    };
    
    var _buscaAtdcEnderecos = function (data) {
        _iniciaTabela();
        return SQLiteAPIAbstract.getRegistrosAPI('atdc_endereco', data);
    };
    
    var _getAtdcEnderecos = function () {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_endereco";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _getAtdcEndereco = function (id) {
        _iniciaTabela(); 
        var query = "SELECT * FROM atdc_endereco WHERE id = ?";
        return $cordovaSQLite.execute($rootScope.db, query,[id]);
    };
    var _deleteAtdcEnderecos = function () {
        _iniciaTabela();
        var query = "DELETE FROM atdc_endereco";
        return $cordovaSQLite.execute($rootScope.db, query);
    };
    var _setAtdcEnderecos = function (atdcEnderecos) {
        _iniciaTabela();
////        _deleteAtdcEnderecos();
//        var query = "INSERT INTO atdc_endereco ( \n\
//                        id, \n\
//                        atdc, \n\
//                        tipo, \n\
//                        cep, \n\
//                        rua, \n\
//                        numero, \n\
//                        complemento, \n\
//                        bairro, \n\
//                        cidade, \n\
//                        estado, \n\
//                        referencia, \n\
//                        localizacao) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
//        angular.forEach(atdcEnderecos, function (atdcEndereco,index){
//            $cordovaSQLite.execute($rootScope.db, query, [
//                atdcEndereco.id, 
//                atdcEndereco.atdc, 
//                atdcEndereco.tipo, 
//                atdcEndereco.cep, 
//                atdcEndereco.rua, 
//                atdcEndereco.numero, 
//                atdcEndereco.complemento, 
//                atdcEndereco.bairro, 
//                atdcEndereco.cidade, 
//                atdcEndereco.estado, 
//                atdcEndereco.referencia, 
//                atdcEndereco.localizacao]).then(function(res) {
////              console.log("insertId: " + res.insertId);
//            }, function (err) {
//              console.error(err);
//            });
//        });
        _setAtdcEnderecos2(atdcEnderecos, 0, 'atdc_endereco').then(function(){
            var valido = new Date();
            valido.setDate(valido.getDate() + 1);
            $window.localStorage['atdcEnderecoValido'] = new Date(valido);
            $window.localStorage['atdcEnderecoAtualizado'] = new Date();
            $window.localStorage['atdcEnderecoQtde'] = Object.keys(atdcEnderecos).length;
        }, function(err){
            console.error(err); 
        });
    };
    
    var _setAtdcEnderecos2 = function (retorno, indice, tabela) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(retorno.length > 0){
            var registro = retorno[indice];
            indice++;

            delete registro._links;
            delete registro.dataAlteracao;
            delete registro.sincronizado;
            delete registro._embedded;

            SQLiteAPIAbstract.insertOrUpdate(tabela, registro.id, registro).then(function (data) {
                if(indice < retorno.length){
                    defered.resolve(_setAtdcEnderecos2(retorno, indice, tabela));
                }else{
                    defered.resolve(retorno);
                }
                defered.resolve(retorno);
            }, function(err){
                console.error(err); 
                defered.reject(err);
            });
        }else{
            defered.resolve(retorno);
        }
        
        return promise;
    };
    
//    var _excluiAntigos = function (dias) {
//        if(dias === undefined){
//            dias = 30;
//        }
//        var dataLimite = new Date();
//        dataLimite.setDate(dataLimite.getDate() - dias);
//        
//        var query = "SELECT a.id FROM atdc_endereco a \n\
//                     JOIN atdc_ocorrencia e ON  e.atdc = a.atdc \n\
//                     JOIN atos b ON  b.atdcOcorrencia = e.id \n\
//                     JOIN atos_atendimento c ON c.atos = b.id \n\
//                     JOIN atdc_ocorrencia d ON d.id = b.atdcOcorrencia \n\
//                     ";
//        query+= " WHERE d.atdcStatus = 6 \n\
//                  AND b.encerramento < '"+$rootScope.converteObjetoDataPost(dataLimite)+"' \n\
//                  AND a.sincronizado = 1";
//        
//        query = "DELETE FROM atdc_endereco WHERE id IN ( "+query+" )";
//        return $cordovaSQLite.execute($rootScope.db, query);
//    };
    
    
    return {
        deleteAtdcEnderecos: _deleteAtdcEnderecos,
        buscaAtdcEnderecos: _buscaAtdcEnderecos,
        getAtdcEnderecos: _getAtdcEnderecos,
        getAtdcEndereco: _getAtdcEndereco,
        setAtdcEnderecos: _setAtdcEnderecos,
//        excluiAntigos: _excluiAntigos,
        iniciaTabela: _iniciaTabela,
        apagaTabela: _apagaTabela
    };
});