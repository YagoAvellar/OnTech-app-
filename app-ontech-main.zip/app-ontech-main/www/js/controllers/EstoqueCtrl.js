angular.module("starter").controller("EstoqueCtrl", function ($scope, estoqueAPI, $ionicModal, SQLiteEstoque, $window) {

    var _getEstoque = function () {
        estoqueAPI.getEstoque().success(function (data) {
            $scope.estoque = data._embedded.atdp_estoque;
        });
    };

//    console.log('estoque');
//    console.log($window.localStorage['estoqueValido']);
//    
//    
//    var today = new Date('2016-05-31 23:00:00');
//    var teste = new Date();
//    console.log(today);
//    console.log(teste);
//    console.log(teste < $window.localStorage['estoqueValido']);
//    today.setDate(today.getDate() + 1);
//    var formattedDate = new Date(today);
//    console.log(teste > today);
//    console.log(today);
//    console.log(formattedDate);
    
    $scope.doRefresh = function () {
        _getEstoque();
        $scope.$broadcast('scroll.refreshComplete');

    };

    _getEstoque();

//	$scope.onOrderDelete = function (id) {
//		estoqueAPI.deleteOrder(id).success(function () {
//			_getOrders();
//		});
//	};

    var _addPeca = function (atdp) {
        estoqueAPI.addPecaEstoque(atdp).then(function (data) {
//            console.log(data);
            $scope.modalAddPeca.hide();
//            alert(data);
        });
    };

    $ionicModal.fromTemplateUrl('templates/modal-addpeca.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalAddPeca = modal;

    });
    $scope.openModalAddPeca = function () {
        $scope.modalAddPeca.show();
        var hoje = new Date();
        var validoAte = new Date($window.localStorage['estoqueValido']);
        var consulta = !(validoAte instanceof Date) || hoje > validoAte || $window.localStorage['estoqueValido'] == null;
//        var consulta = +hoje > +$window.localStorage['estoqueValido'];
        
//        console.log('consulta');
//        console.log(consulta);
//        console.log(hoje.getDate());
//        console.log(validoAte.getDate());
        
        var pecas = new Array();
        SQLiteEstoque.getPecas().then(function (res) {
            for (var i = 0; i < res.rows.length; i++) {
                var row = res.rows.item(i);
                pecas.push(row);
//                if (i == res.rows.length - 1) {
//                    console.log("WebSQL Data: " + JSON.stringify(pecas));
//                }
            }
            $scope.Pecas = pecas;
//            console.log(pecas.length);
//            console.log(res);
            if(res.rows.length == 0 || consulta){
                SQLiteEstoque.deletePecas().then(function (data) {
                    estoqueAPI.getPecas().success(function (data) {
                        $scope.Pecas = data._embedded.atdp;
                        SQLiteEstoque.setPecas($scope.Pecas);
                    });
                });
            }
        }, function (err) {
            estoqueAPI.getPecas().success(function (data) {
                $scope.Pecas = data._embedded.atdp;
                SQLiteEstoque.setPecas($scope.Pecas);
            });
            console.error(err);
        });
//        console.log($scope.Pecas);
        
    };
    $scope.closeModalAddPeca = function () {
        $scope.modalAddPeca.hide();
    };
    $scope.addPeca = function (requisicao) {
        _addPeca(requisicao);
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modalAddPeca !== undefined && $scope.modalAddPeca.isShown()) {
            event.preventDefault();
            $scope.closeModalAddPeca();
        }
    });


});