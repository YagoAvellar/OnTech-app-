angular.module("starter").controller("AccountCtrl", function ($scope) {
  $scope.settings = {
    enableFriends: true
  };
});