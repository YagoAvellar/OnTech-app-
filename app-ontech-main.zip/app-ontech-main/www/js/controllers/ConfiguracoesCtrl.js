angular.module("starter").controller("ConfiguracoesCtrl", function ($q, $rootScope, $scope, $stateParams, $localStorage, $ionicPopup, $filter, $ionicPlatform,
    $ionicModal, config, configuracoesAPI, SQLiteOrdemServico, ordemServicoAPI, clientesAPI, produtosAPI, $window, SQLiteAPIAbstract, SQLiteAPIatosAtividade,
    $cordovaEmailComposer, $cordovaFile, $compile, SQLiteAPIat, SQLiteAPIatdcOcorrenciaProduto) {
        
    $scope.config = config;
    $scope.mostraSincronizacoes = false;
    $scope.erroTrocaSenha = '';
    $scope.trocaSenha = {
        'atual' : '',
        'senha' : '',
        'confirmacao' : ''
    };
    $rootScope.confirmaReset = {
        'senha' : ''
    };
    $rootScope.opcoesBuscaRegistros = {
        'buscaProdutos' : false,
        'buscaConfiguracoes' : false
    };
    
    $scope.doRefresh = function () {
        
        let configEmpresa = $localStorage.getObject('configEmpresa');
        $scope.permitirAssinaturaOcorrencia = 'f';
        $scope.API = 'Servidor ';
        if('nome' in configEmpresa){
            $scope.API += configEmpresa.nome;
        }else{
            $scope.API += "ONCLICK";
        }
        if($rootScope.configEmpresa.baseUrl === "https://ontech-api.sasazaki.com.br/v2"){
            $scope.API = 'Servidor Sasazaki';
        }
        SQLiteOrdemServico.verificaRegistrosParaAtualizar().then(function (data) {
            $scope.registrosSincronizar = data;
            _atualizaSincronismo();
            console.log(data);
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
        SQLiteAPIat.getAt().then(function (data) {
            var indice = Object.keys(data)[0];
            if(data[indice] != undefined){
                $scope.permitirAssinaturaOcorrencia = data[indice].permitirAssinaturaOcorrencia;
            }
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
        var timeNow = new Date();
        var nome = $filter('date')(timeNow, 'yyyy-MM-dd');
        var arquivo = nome+".log";
        $scope.arquivoLog = null;
        $scope.tamanhoLog = 0;
        $cordovaFile.checkFile($rootScope.caminhoLog,arquivo).then(function (success) {
            success.file(function (success) {
                var tamanho = success.size;
                $scope.tamanhoLog = tamanho;
            }, function (error) {
                $rootScope.geraLog(error, new Error());
            });
            $scope.arquivoLog = arquivo;
        }, function (error) {
//            $rootScope.geraLog(error, new Error());
        });
        
        $scope.$broadcast('scroll.refreshComplete');

    };
    $ionicPlatform.ready(function () {
        $scope.limiteUtilizadoApp = 209715200;
//        $scope.limiteUtilizadoApp = 2485760;
        $scope.infoAparelho = {};
        
        
        
        $rootScope.getInfoAparelho().then(function (success) {
            $scope.infoAparelho = success;
            console.log($scope.infoAparelho);
//            $scope.infoAparelho.utilizadoApp = 209715200;
//            $scope.infoAparelho.freeDiskSpace = 1610450;
            $scope.doRefresh();
        }, function (error) {
            $scope.doRefresh();
        });
    });
    
    
    $ionicModal.fromTemplateUrl('templates/modal-troca_senha.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalTrocaSenha = modal;

    });
    $scope.openModalTrocaSenha = function () {
        $scope.modalTrocaSenha.show();
    };
    $scope.closeModalTrocaSenha = function () {
        $scope.modalTrocaSenha.hide();
    };
    $scope.AlterarSenha = function (trocaSenha) {
        $scope.erroTrocaSenha = '';
        if(trocaSenha.senha.length == 0 || trocaSenha.confirmacao.length == 0){
            $scope.erroTrocaSenha = 'Favor preencher todos os campos!';
        }else
        if(trocaSenha.senha === trocaSenha.confirmacao){
//            console.log(trocaSenha);
            $rootScope.abrirCarregando();
            configuracoesAPI.alterarSenha($rootScope.usuarioLogado.id, trocaSenha).then(function (data) {
    //            console.log(data);
                $scope.modalTrocaSenha.hide();
    //            alert(data);
                $rootScope.fecharCarregando();
            }, function (err) {
                $rootScope.geraLog(err, new Error());
//                console.log(err.data);
                if('detail' in err.data){
//                    console.log(err.data);
                    $scope.erroTrocaSenha = err.data.detail;
                }
                $rootScope.fecharCarregando();
            });
        }else{
            $scope.erroTrocaSenha = 'Senha não confere!';
        }
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modalTrocaSenha !== undefined && $scope.modalTrocaSenha.isShown()) {
            event.preventDefault();
            $scope.closeModalTrocaSenha();
        }
    });

    var _atualizaSincronismo = function (){
        $scope.tempoSincronismo = {
            'atdcOcorrenciaLog' : $rootScope.converteDataString($window.localStorage['atdcOcorrenciaLogAtualizado']),
            'atdcOcorrenciaEncerramento' : $rootScope.converteDataString($window.localStorage['atdcOcorrenciaEncerramentoAtualizado']),
            'atos' : $rootScope.converteDataString($window.localStorage['atosAtualizado']),
            'atosStatus' : $rootScope.converteDataString($window.localStorage['atosStatusAtualizado']),
            'atosAtividade' : $rootScope.converteDataString($window.localStorage['atosAtividadeAtualizado']),
            'atosAtividadeTipo' : $rootScope.converteDataString($window.localStorage['atosAtividadeTipoAtualizado']),
            'atosImagem' : $rootScope.converteDataString($window.localStorage['atosImagemAtualizado']),
            'atdcOcorrenciaProduto' : $rootScope.converteDataString($window.localStorage['atdcOcorrenciaProdutoAtualizado']),
            'cliente' : $rootScope.converteDataString($window.localStorage['clienteAtualizado']),
            'produto' : $rootScope.converteDataString($window.localStorage['produtoAtualizado']),
            'grupoDefeito' : $rootScope.converteDataString($window.localStorage['grupoDefeitoAtualizado']),
            'defeito' : $rootScope.converteDataString($window.localStorage['defeitoAtualizado']),
            'defeitoProcedimento' : $rootScope.converteDataString($window.localStorage['defeitoProcedimentoAtualizado']),
            'atendimento' : $rootScope.converteDataString($window.localStorage['atendimentoAtualizado']),
            'atdcOcorrencia' : $rootScope.converteDataString($window.localStorage['atdcOcorrenciaAtualizado']),
            'atdcEndereco' : $rootScope.converteDataString($window.localStorage['atdcEnderecoAtualizado']),
            'estoque' : $rootScope.converteDataString($window.localStorage['estoqueAtualizado'])
        };
        $scope.SyncQtde = {
            'atdcOcorrenciaLog' : ($window.localStorage['atdcOcorrenciaLogQtde']),
            'atdcOcorrenciaEncerramento' : ($window.localStorage['atdcOcorrenciaEncerramentoQtde']),
            'atos' : ($window.localStorage['atosQtde']),
            'atosStatus' : ($window.localStorage['atosStatusQtde']),
            'atosAtividade' : ($window.localStorage['atosAtividadeQtde']),
            'atosAtividadeTipo' : ($window.localStorage['atosAtividadeTipoQtde']),
            'atosImagem' : ($window.localStorage['atosImagemQtde']),
            'atdcOcorrenciaProduto' : ($window.localStorage['atdcOcorrenciaProdutoQtde']),
            'cliente' : ($window.localStorage['clienteQtde']),
            'produto' : ($window.localStorage['produtoQtde']),
            'grupoDefeito' : ($window.localStorage['grupoDefeitoQtde']),
            'defeito' : ($window.localStorage['defeitoQtde']),
            'defeitoProcedimento' : ($window.localStorage['defeitoProcedimentoQtde']),
            'atendimento' : ($window.localStorage['atendimentoQtde']),
            'atdcOcorrencia' : ($window.localStorage['atdcOcorrenciaQtde']),
            'atdcEndereco' : ($window.localStorage['atdcEnderecoQtde']),
            'estoque' : ($window.localStorage['estoqueQtde'])
        };
    };
    _atualizaSincronismo();
    
    $scope.sincronizaClientes = function () {
        SQLiteOrdemServico.buscaClientes();
//        _getClientes();
    };

    $scope.sincronizaGrupoDefeitos = function () {
        SQLiteOrdemServico.buscaGrupoDefeitos();
    };
    
    $scope.sincronizaDefeitos = function () {
        SQLiteOrdemServico.buscaDefeitos();
    };
    
    $scope.sincronizaAtendimentos = function () {
        SQLiteOrdemServico.buscaAtendimentos();
    };
    
    $scope.sincronizaAtdcOcorrencias = function () {
        SQLiteOrdemServico.buscaAtdcOcorrencias();
    };
    
    $scope.enviaAtdcOcorrencias = function () {
        SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atdc_ocorrencias,'atdc_ocorrencia').then(function (data) {
            $rootScope.fecharCarregando();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });
    };
    
    
    $scope.enviaAtendimentos = function () {
        $rootScope.abrirCarregando("Enviando Atendimentos...");
        SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atos_atendimentos,'atos_atendimento').then(function (data) {
//        SQLiteOrdemServico.enviaAtendimentos($scope.registrosSincronizar.atos_atendimentos).then(function (data) {
            $rootScope.fecharCarregando();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });
    };
    
    $scope.enviaAtos = function () {
        $rootScope.abrirCarregando("Enviando Atos...");
        SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atos,'atos').then(function (data) {
            $rootScope.fecharCarregando();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });
    };
    
    $scope.enviaAtosAtividades = function () {
        $rootScope.abrirCarregando("Enviando atosAtividades...");
        SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atos_atividades,'atos_atividade').then(function (data) {
            $rootScope.fecharCarregando();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });
    };
    
    $scope.enviaAtosImagens = function () {
        $rootScope.abrirCarregando("Enviando atosImagens...");
        SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atos_imagens,'atos_imagem').then(function (data) {
            $rootScope.fecharCarregando();
            
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });
    };
    
    $scope.enviaAtdcOcorrenciaEncerramentos = function () {
        $rootScope.abrirCarregando("Enviando AtdcOcorrenciaEncerramento...");
        SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atdc_ocorrencia_encerramentos,'atdc_ocorrencia_encerramento').then(function (data) {
            $rootScope.fecharCarregando();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });
    };
    
    $scope.enviaAtdcOcorrenciaLogs = function () {
        $rootScope.abrirCarregando("Enviando AtdcOcorrenciaLog...");
        SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atdc_ocorrencia_logs,'atdc_ocorrencia_log').then(function (data) {
            $rootScope.fecharCarregando();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });
    };
    
    var porcentagem = function(valor1, valor2){
        return "Enviando: "+$filter('number')(parseFloat(valor1/valor2)*100, 2)+'%';
    };
    
    $scope.enviaAlteracoes = function () {
        if($rootScope.enviando === true){
            var confirmPopup = $ionicPopup.confirm({
                title: 'Enviando em Segundo Plano',
                template: "Registros estão sendo sincronizados em segundo plano, tem certeza que deseja enviar manualmente?"
            });
            confirmPopup.then(function (res) {
                if (res) {
                    $scope.enviaAlteracoes2();
                }
            });
        }else{
            $scope.enviaAlteracoes2();
        }
    };    
    
    $scope.enviaAlteracoes2 = function () {
        var timeNow = new Date();
        var total = 11;
        var concluido = 0;
        $rootScope.enviando = true;
        $rootScope.erroEnviando = [];
        $rootScope.dataEnviando = $rootScope.converteObjetoDataPost(timeNow);
        
        var retornoProduto = {'atividade' : [], 'servico' : []};
        
        SQLiteOrdemServico.verificaRegistrosParaAtualizar().then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            $scope.registrosSincronizar = data;
            _atualizaSincronismo();
            return SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atos_atendimentos,'atos_atendimento');
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atos,'atos');
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atdc_ocorrencias,'atdc_ocorrencia');
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atdc_ocorrencia_encerramentos,'atdc_ocorrencia_encerramento');
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIatdcOcorrenciaProduto.enviaAtdcOcorrenciaProdutos($scope.registrosSincronizar.atdc_ocorrencia_produtos);
//            return _enviaAtdcOcorrenciaProdutos($scope.registrosSincronizar.atdc_ocorrencia_produtos);
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            if('erro' in data && data.erro){
                return data;
            }else{
                retornoProduto = data;
                var atos_atividades = retornoProduto.atividade.length > 0 ? retornoProduto.atividade : $scope.registrosSincronizar.atos_atividades;
                return SQLiteAPIAbstract.enviaRegistros(atos_atividades,'atos_atividade');
            }
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            if('erro' in data && data.erro){
                return data;
            }else{
                var atos_servicos = retornoProduto.servico.length > 0 ? retornoProduto.servico : $scope.registrosSincronizar.atos_servicos;
                return SQLiteAPIAbstract.enviaRegistros(atos_servicos,'atos_servico');
            }
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atdc_ocorrencia_logs,'atdc_ocorrencia_log');
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.atos_imagens,'atos_imagem');
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            concluido++;
            return SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.itadau_usuario,'itadau_usuario');
        }).then(function (data) {
            $rootScope.abrirCarregando(porcentagem(concluido,total));
            return SQLiteAPIAbstract.enviaRegistros($scope.registrosSincronizar.itadau_usuario_localizacao,'itadau_usuario_localizacao');
        }).then(function (data) {
            $rootScope.enviando = false;
            $rootScope.dataEnviando = null;
            $rootScope.fecharCarregando();
            verificaErroSolicitaEnvio();
        }, function (err) {
            $rootScope.enviando = false;
            $rootScope.dataEnviando = null;
            verificaErroSolicitaEnvio();
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });
    };
    
    verificaErroSolicitaEnvio = function () {
        if($rootScope.erroEnviando.length > 0){
            var confirmPopup = $ionicPopup.confirm({
                title: 'Erro ao Enviar dados',
                template: 'Deseja enviar um log para analise?'
            });
            confirmPopup.then(function (res) {
                if (res) {
                    var timeNow = new Date();
                    var dataAlteracao = $rootScope.converteDataLog(timeNow);
                    var nomeArquivo = "logErro-"+dataAlteracao+".txt";
//                    console.log(nomeArquivo);

                    $cordovaFile.writeFile(cordova.file.externalCacheDirectory, nomeArquivo, $rootScope.erroEnviando, true)
                    .then(function (success) {
                        var anexo = cordova.file.externalCacheDirectory+nomeArquivo;
//                        console.log(anexo);
                        var arrayAnexo = [anexo];
    //                        var arrayAnexo = [anexo.replace('file://', '')]; // utilizado com o plugin antigo
                        var assunto = 'Erro ao enviar dados';
                        var conteudo = "Segue log de erro do aplicativo ao enviar sincronização";
                        $rootScope.sendEmail(assunto,conteudo, arrayAnexo);

                    }, function (error) {
                        console.log(error);
                    });

                }
            });
        }
    };
    
    $scope.enviaAtdcOcorrenciaProdutos = function () {
        $rootScope.abrirCarregando("Enviando AtdcOcorrenciaProduto...");
        _enviaAtdcOcorrenciaProdutos($scope.registrosSincronizar).then(function (data) {
            $rootScope.fecharCarregando();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });
    };
    
    $scope.enviaLogEmail = function () {
        
        var confirmPopup = $ionicPopup.confirm({
                title: 'Envio de Log',
                template: 'Deseja enviar o log com os erros do dia?'
            });
            confirmPopup.then(function (res) {
                if (res) {
                    var timeNow = new Date();
                    var nome = $filter('date')(timeNow, 'yyyy-MM-dd');
                    var anexo = $rootScope.caminhoLog+nome+".log";
                    console.log(anexo);
                    var arrayAnexo = [anexo];
                    var assunto = 'Arquivo de log do dia';
                    var conteudo = "Segue log de erros do aplicativo";
                    $rootScope.sendEmail(assunto,conteudo, arrayAnexo);
                }
            });
    };
    
    
    $scope.excluirLog = function () {
        
        var confirmPopup = $ionicPopup.confirm({
                title: 'Excluir Log',
                template: 'Deseja excluir o log com os erros do dia?'
            });
            confirmPopup.then(function (res) {
                if (res) {
                    var timeNow = new Date();
                    var nome = $filter('date')(timeNow, 'yyyy-MM-dd');
                    var arquivo = nome+".log";
                    $cordovaFile.removeFile($rootScope.caminhoLog,arquivo).then(function (success) {
                        $scope.arquivoLog = arquivo;
                        $scope.tamanhoLog = 0;
                        $scope.doRefresh();
                    }, function (error) {
                        $rootScope.geraLog(error, new Error());
                        $scope.doRefresh();
                    });
                }
            });
    };
    
    
    var _enviaAtdcOcorrenciaProdutos = function (registrosSincronizar) {
        var defered = $q.defer();
        var promise = defered.promise;
        SQLiteAPIAbstract.enviaRegistros(registrosSincronizar,'atdc_ocorrencia_produto').then(function (data) {
            var atualizaProduto = [];
            angular.forEach(data, function (ocorrenciaProduto,index){
                if(ocorrenciaProduto.id != ocorrenciaProduto.idApp){
                    atualizaProduto.push({'de':ocorrenciaProduto.idApp,'para':ocorrenciaProduto.id,'atdcOcorrencia':ocorrenciaProduto.atdcOcorrencia});
                }
            });
            if(atualizaProduto.length > 0){
                SQLiteAPIatosAtividade.atualizaProdutoAtividade(atualizaProduto,0).then(function (data) {
                    defered.resolve(data);
                }, function (err) {
                    defered.reject(err);
                });
            }else{
                defered.resolve(data);
            }
        }, function (err) {
            defered.reject(err);
        });
        
        return promise;
    };
    
    $scope.sincronizaAtdcEnderecos = function () {
        SQLiteOrdemServico.buscaAtdcEnderecos();
    };
    
    $scope.sincronizaDefeitoProcedimentos = function () {
        SQLiteOrdemServico.buscaDefeitoProcedimentos();
    };
    
    $scope.sincronizaAtosStatus = function () {
        SQLiteOrdemServico.buscaAtosStatus();
    };
    
    $scope.sincronizaAtos = function () {
        SQLiteOrdemServico.buscaAtos();
    };
    
    $scope.resetarTabelas = function () {
//        $rootScope.confirmaReset.senha = 'teste';
        var confirmPopup = $ionicPopup.confirm({
            title: '<b>Limpar dados locais</b>',
            template: 'Ao confirmar os <b class="assertive" >dados locais serão excluidos</b> e será necessário buscar novos dados<br/><br/>\n\
                        Informe a senha por segurança:<br/><input type="password" name="senha" ng-model="confirmaReset.senha" /><br/>\n\
                        * Dados não enviados serão perdidos'
        });

        confirmPopup.then(function (res) {
            if (res) {
//                console.log($rootScope.confirmaReset.senha);
//                console.log($rootScope.usuarioLogado.senha);
                if($rootScope.usuarioLogado.senha == $rootScope.confirmaReset.senha){
//                    console.log("apagando...");
                    SQLiteOrdemServico.resetarTabelas();
                }else{
                    $rootScope.showAlert('Senha não confere!');
                }
                
            }
            
        });
    };
    $scope.modalBuscaRegistros = function () {
//        $rootScope.confirmaReset.senha = 'teste';
        var confirmPopup = $ionicPopup.confirm({
            title: '<b>Buscar Dados Servidor</b>',
            template: '<ion-checkbox class="item-text-wrap" ng-model="opcoesBuscaRegistros.buscaConfiguracoes">Incluir arquivos de configuração</ion-checkbox>\n\
                       <ion-checkbox class="item-text-wrap" ng-model="opcoesBuscaRegistros.buscaProdutos">Incluir lista de produtos</ion-checkbox>'
        });

        confirmPopup.then(function (res) {
            if (res) {
                SQLiteOrdemServico.buscaRegistros($rootScope.opcoesBuscaRegistros.buscaConfiguracoes, $rootScope.opcoesBuscaRegistros.buscaProdutos).then(function (success) {
                    $scope.doRefresh();
                }, function (error) {
                    $rootScope.geraLog(error, new Error());
                    $scope.doRefresh();
                });
            }else{
                console.log($rootScope.busca);
            }
            
        });
    };
    
    $rootScope.openModalAssinaturaTecnico = function () {
        screen.lockOrientation('landscape');
        setTimeout(function() {
            $rootScope.getAlturaLargura();
            $rootScope.modalAssinaturaTecnico.show();
            if($rootScope.signaturePadTecnico === undefined){
                var canvas = document.getElementById('signatureCanvasTecnico');
                console.log('signatureCanvasTecnico');
                console.log(canvas);
                $rootScope.signaturePadTecnico = new SignaturePad(canvas);
            }
        }, 100);
    };
    $rootScope.closeModalAssinaturaTecnico = function () {
        screen.unlockOrientation();
        $rootScope.modalAssinaturaTecnico.hide();
        $rootScope.signaturePadTecnico.clear();
        $rootScope.signaturePadTecnico = undefined;
    };        
    $rootScope.limpaAssinaturaTecnico = function() {
        $rootScope.signaturePadTecnico.clear();
    };
    
    $rootScope.atualizarAssinaturaTecnico = function() {
        if($rootScope.signaturePadTecnico.isEmpty()){
            $rootScope.showAlert('Assinatura invalida');
        }else{
            var sigImg = $rootScope.signaturePadTecnico.toDataURL();
            $rootScope.usuarioLogado.assinaturaDigital = sigImg;
            
            SQLiteAPIAbstract.update('itadau_usuario', $rootScope.usuarioLogado.id, $rootScope.usuarioLogado, false, false).then(function (data) {
                console.log('data itadau_usuario');
                console.log(data);
                $localStorage.setObject('usuarioLogado', $rootScope.usuarioLogado);
                $rootScope.fecharCarregando();
                $rootScope.closeModalAssinaturaTecnico();
            }, function (data) {
                $rootScope.geraLog(data, new Error());
    //                    console.log(data);
                $rootScope.fecharCarregando();
            });
        }
    };
     
    
    $scope.sincronizaAtdcOcorrenciaEncerramentos = function () {
        SQLiteOrdemServico.buscaAtdcOcorrenciaEncerramentos();
    };
    
    $scope.sincronizaAtosAtividades = function () {
        SQLiteOrdemServico.buscaAtosAtividades();
    };
    
    $scope.sincronizaAtosAtividadeTipo = function () {
        SQLiteOrdemServico.buscaAtosAtividadeTipo();
    };
    
    
    $scope.sincronizaAtosImagem = function () {
        SQLiteOrdemServico.buscaAtosImagens();
    };
    
    $scope.sincronizaAtdcOcorrenciaProdutos = function () {
        SQLiteOrdemServico.buscaAtdcOcorrenciaProdutos();
    };

    $scope.sincronizaProdutos = function () {
        SQLiteOrdemServico.buscaProdutos();
    };

});