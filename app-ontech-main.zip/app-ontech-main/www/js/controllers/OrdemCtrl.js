angular.module("starter").controller("OrdemCtrl", function ($scope, $stateParams, ordemServicoAPI, ocorrenciaAPI, $ionicPopup) {
    var _getOrdem = function () {
        ordemServicoAPI.getOrdem($stateParams.id).success(function (data) {
            $scope.ordem = data;
            $scope.ocorrenciaProdutos = data._embedded.atdcOcorrencia.atdcOcorrenciaProdutos;
            $scope.ocorrenciaDefeitos = data._embedded.atdcOcorrencia.atdcOcorrenciaDefeitos;
//            console.log(data._embedded.atdcOcorrencia);
//            ocorrenciaAPI.getOcorrenciaProdutos($stateParams.id).success(function (ocorrenciaProdutos) {
//                $scope.ocorrenciaProdutos = ocorrenciaProdutos._embedded.atdc_ocorrencia_produto;
//            });
        });
    };

    $scope.doRefresh = function () {
        _getOrdem($stateParams.id);
        $scope.$broadcast('scroll.refreshComplete');

    };
    
    $scope.fazerCheckin = function() {
        var confirmPopup = $ionicPopup.confirm({
          title: 'Confirmar Check-in',
          template: 'Fazer Check-in agora?'
        });

        confirmPopup.then(function(res) {
          if(res) {
            console.log('You are sure');
          } else {
            console.log('You are not sure');
          }
        });
    };

    _getOrdem($stateParams.id);

});