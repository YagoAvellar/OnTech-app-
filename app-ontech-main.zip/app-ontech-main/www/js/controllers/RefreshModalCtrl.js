angular.module("starter").controller('RefreshModalCtrl', [
    '$rootScope', '$scope', 'OAuth', 'authService', '$timeout', '$state', 'OAuthToken', 'logout',
    function ($rootScope, $scope, OAuth, authService, $timeout, $state, OAuthToken, logout) {

        function destroyModal() {
            if ($rootScope.modal) {
                $rootScope.modal.hide();
                $rootScope.modal = false;
            }
        }

        $scope.$on('event:auth-loginConfirmed', function () {
            destroyModal();
        });

        $scope.$on('event:auth-loginCancelled', function () {
            destroyModal();
            $rootScope.fecharCarregando();
            logout.logout();
        });

        $scope.$on('$stateChangeStart',
                function (event, toState, toParams, fromState, fromParams) {
                    if ($rootScope.modal) {
                        $rootScope.fecharCarregando();
                        authService.loginCancelled();
                        event.preventDefault();
                        $state.go('login');
                    }
                });

        OAuth.getRefreshToken().then(function (retorno) {
            if(angular.isObject(retorno.data) && retorno.data.access_token){
                $timeout(function () {
                    authService.loginConfirmed();
                }, 1000);
            }else{
                authService.loginCancelled();
                $rootScope.fecharCarregando();
                $state.go('login');
            }
        }, function () {
            authService.loginCancelled();
            $rootScope.fecharCarregando();
            $state.go('login');
        });
    }]);