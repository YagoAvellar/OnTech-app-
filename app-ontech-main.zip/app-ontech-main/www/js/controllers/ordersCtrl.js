//angular.module("starter").controller("ordersCtrl", function ($scope, ordersAPI, $cordovaSQLite) {
angular.module("starter").controller("ordersCtrl", function ($scope, ordersAPI) {

//var db = null;
//
//            db = $cordovaSQLite.openDB("my.db");
//            $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS people (id integer primary key, firstname text, lastname text)");

	var _getOrders = function () {
		ordersAPI.getOrders().success(function (data) {
		$scope.orders = data._embedded.atdc_ocorrencia;
//                alert("teste");
	});};

	$scope.doRefresh = function () {
		_getOrders();
		$scope.$broadcast('scroll.refreshComplete');

	};

//        $scope.insert = function(firstname, lastname) {
//            var query = "INSERT INTO people (firstname, lastname) VALUES (?,?)";
//            $cordovaSQLite.execute(db, query, [firstname, lastname]).then(function(res) {
//                $scope.teste.insert = ("INSERT ID -> " + res.insertId);
//                console.log("INSERT ID -> " + res.insertId);
//            }, function (err) {
//                console.error(err);
//            });
//        }
//
//        $scope.select = function(lastname) {
//            var query = "SELECT firstname, lastname FROM people WHERE lastname = ?";
//            $cordovaSQLite.execute(db, query, [lastname]).then(function(res) {
//                if(res.rows.length > 0) {
//                    $scope.teste.select = ("SELECTED -> " + res.rows.item(0).firstname + " " + res.rows.item(0).lastname);
//                    console.log("SELECTED -> " + res.rows.item(0).firstname + " " + res.rows.item(0).lastname);
//                } else {
//                    console.log("No results found");
//                }
//            }, function (err) {
//                console.error(err);
//            });
//        }
	_getOrders();

	$scope.onOrderDelete = function (id) {
		ordersAPI.deleteOrder(id).success(function () {
			_getOrders();
		});
	};
});