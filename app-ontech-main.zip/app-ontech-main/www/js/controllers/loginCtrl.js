angular.module("starter.controllers").controller('loginCtrl', function ($rootScope, $scope, $window, config, $state, OAuth, OAuthToken, configuracoesAPI, $localStorage,
        SQLiteOrdemServico, SQLiteAPIAbstract, $ionicPlatform) {
    
//    $scope.dadosLogin = {};
    
    $ionicPlatform.ready(function () {
        $scope.dadosLogin = {};
        if($rootScope.usuarioLogado && 'empresaLogin' in $rootScope.usuarioLogado){
            $scope.dadosLogin.empresa = $rootScope.usuarioLogado.empresaLogin;
        }
    });
    
    $rootScope.fecharCarregando();
    $scope.login = function (login) {
        let empresa = (login.empresa).toUpperCase();
        if (empresa in config) {
            $rootScope.configEmpresa = config[empresa];
            $localStorage.setObject('configEmpresa', $rootScope.configEmpresa);
            if (login.username === 'p' || login.username === 'P') {
                login.username = "pedro.lobo@onclick.com.br";
            } else
            if (login.username === 'u' || login.username === 'U') {
                login.username = "usuario5@onclick.com.br";
            } else
            if (login.username.indexOf('@') < 0) {
                if ($rootScope.configEmpresa.imageUrl === "https://ontech-api.sasazaki.com.br") {
                    login.username += "@sasazaki.com.br";
                } else {
                    login.username += "@onclick.com.br";
                }
            }
//            console.log(OAuth.config);
//            console.log($rootScope.configEmpresa);
            
            var configOAuthProvider = $localStorage.getObject('configOAuthProvider');
            configOAuthProvider.baseUrl = $rootScope.configEmpresa.baseUrlOauth;                    
            $localStorage.setObject('configOAuthProvider', configOAuthProvider);
            
//            OAuthToken.alteraUrlOauth($rootScope.configEmpresa.baseUrlOauth);
            OAuth.config.baseUrl = $rootScope.configEmpresa.baseUrlOauth;
            
//            OAuth.config = {
//                baseUrl: $rootScope.configEmpresa.baseUrlOauth,
//                clientId: 'clientpedro',
//                clientSecret: 'testpass',
//                grantPath: '/oauth',
//                revokePath: '/oauth'
//            };
//            console.log(OAuth);
        

            //        ontech.sasazaki.com.br
            //        ontech-api.sasazaki.com.br


            let senha = login.password;
            $rootScope.errorLogin = '';
            $rootScope.abrirCarregando();
            OAuth.getAccessToken(login).then(function () {
                SQLiteAPIAbstract.getRegistrosAPI('itadau_usuario').then(function (dataTemp) {
                    var data = dataTemp[0];
                    data.senha = senha;
                    if ($rootScope.usuarioLogado === null || $rootScope.usuarioLogado.id !== data.id) {
                        //                    console.log("apagando...");
                        SQLiteOrdemServico.limparSincronizados();
                        console.log('limparSincronizados');
                    }
                    data.registroPush = $rootScope.registroPush;
                    data.empresaLogin = login.empresa;
                    //                 data.sincronizado = 0;
                    $rootScope.usuarioLogado = data;
                    $localStorage.setObject('usuarioLogado', data);
                    //                $window.localStorage['usuarioLogado'] =  data;
                    //                console.log($window.localStorage['usuarioLogado']);
                    $state.go('tabs.atendimentoatual');
                    $rootScope.buscaRegistros(false);
                }, function (data) {
                    $rootScope.geraLog(data, new Error());
                    $rootScope.errorLogin = "Ocorreu um erro ao buscar as informações do usuário";
                    $rootScope.fecharCarregando();
                });

            }, function (err) {
                $rootScope.geraLog(err, new Error());
                $rootScope.errorLogin = "Usuário e/ou senha inválido(s)";
            });
        } else {
            $rootScope.geraLog(login, new Error());
            $rootScope.errorLogin = "Favor informe uma empresa válida";
            $rootScope.fecharCarregando();
        }
    };
});