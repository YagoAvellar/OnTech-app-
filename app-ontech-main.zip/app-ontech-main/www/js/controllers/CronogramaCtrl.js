angular.module("starter").controller("CronogramaCtrl", function ($q, $rootScope, $scope, ordemServicoAPI, $cordovaGeolocation, ocorrenciaAPI, 
    SQLiteOrdemServico, $window, $ionicPlatform, SQLiteAPIAbstract, $compile, SQLiteAPIAtendimento, $ionicScrollDelegate, $localStorage) {
    /*
     var _getOrdens = function () {
     ordemServicoAPI.getOrdens().success(function (data) {
     $scope.ordens = data._embedded.atos;
     });};
     
     $scope.doRefresh = function () {
     _getOrdens();
     $scope.$broadcast('scroll.refreshComplete');
     
     };
     
     _getOrdens();
     */    
    
    $scope.arrayMarkers = new Array();
    $scope.orderBy = 'dataAgendamento';
    $scope.tipoVisualizacao = 1;
    $scope.mostraBusca = 0;
    $scope.visualizaStatusGPS = 0;
    $scope.buscaAtendimento = {'atosStatus': null, 'orderBy' : 'dataAgendamento', 'tipo': null};
    $scope.atosTipos = [
        {'id' : 'a','descricao' : 'Assistência'},
        {'id' : 'm','descricao' : 'Expositor'},
        {'id' : 's','descricao' : 'Serviço'}
    ];
    
    $scope.alternaStatusGPS = function () {
        $scope.visualizaStatusGPS = $scope.visualizaStatusGPS === 1 ? 0 : 1;
        if($scope.visualizaStatusGPS === 1){
            $ionicScrollDelegate.scrollTop();
        }
    };
    
    $scope.alternaBusca = function () {
        $scope.mostraBusca = $scope.mostraBusca === 1 ? 0 : 1;
        if($scope.mostraBusca === 1){
            $ionicScrollDelegate.scrollTop();
        }
    };
    
    $scope.atualizaLocalizacao = function () {
        $rootScope.getLocalizacao()
        .then(function (position) {
            $scope.doRefresh();
        }, function (err) {
            $rootScope.geraLog(err, new Error()); 
//                                console.log(err);
        });
    };
    var _getCronograma2 = function (buscaAtendimento, ignoraLocalizacao) {
        var localizacaoTemp = $localStorage.getObject('localizacaoUsuario');
        $rootScope.localizacaoUsuario = localizacaoTemp.posicao;
        if(ignoraLocalizacao === undefined){
            ignoraLocalizacao = false;
        }
        
        $scope.TempoLocalizacao = $rootScope.tempoLocalizacao(localizacaoTemp.dataAtualizacao);
        if($scope.TempoLocalizacao.tipo > 0 && ignoraLocalizacao === false){
            $rootScope.abrirCarregando('Buscando Localização...');
            return $rootScope.getLocalizacao()
                    .then(function (position) {
                        _getCronograma2(buscaAtendimento);
                    }, function (err) {
                        $rootScope.geraLog(err, new Error()); 
                        _getCronograma2(buscaAtendimento, true);
//                                console.log(err);
                });
        }
//        var dataTemp = new Date("2016-11-28T11:59:31");
//        $scope.TempoLocalizacao = $rootScope.tempoLocalizacao(dataTemp);
        if($scope.TempoLocalizacao.tipo === 2 || $scope.TempoLocalizacao.tipo === 3){
            $scope.visualizaStatusGPS = 1;
        }
        
        if(buscaAtendimento === undefined){
            buscaAtendimento = $scope.buscaAtendimento;
        }else{
            $scope.buscaAtendimento = buscaAtendimento;
        } 
        buscaAtendimento.localizacaoUsuario = $rootScope.localizacaoUsuario;
        var atosStatusAtendimento = new Array();
        SQLiteOrdemServico.getAtosStatusAtendimento().then(function (data) {
            for (var i = 0; i < data.rows.length; i++) {
                var row = data.rows.item(i);
                atosStatusAtendimento.push(row);
            }
//            console.log(data);
            $scope.atosStatusAtendimento = atosStatusAtendimento;
        }, function (err) {
            $rootScope.fecharCarregando();
            $rootScope.geraLog(err, new Error());
        });
        $rootScope.abrirCarregando();
        
        SQLiteAPIAtendimento.getAtendimentos2(buscaAtendimento).then(function (res) {
            $scope.cronograma = res;
            $rootScope.fecharCarregando();
            if($scope.tipoVisualizacao == 2){
                _carregaMapa();
            }else{
                angular.forEach(res, function (value, key) {
                    _buscaLocalizacao(value);
                });
            }
        }, function (err) {
            $rootScope.fecharCarregando();
//            ordemServicoAPI.getCronograma(buscaAtendimento).success(function (data) {
//                $scope.cronograma = data._embedded.atos_atendimento;
//                ordemServicoAPI.setAtendimentos($scope.cronograma);
//                $rootScope.fecharCarregando();
//            });
            $rootScope.geraLog(err, new Error());
        });
/*            
        ordemServicoAPI.getCronograma(buscaAtendimento).success(function (data) {
//            console.log(data);
            $scope.cronograma = data._embedded.atos_atendimento;
            $rootScope.fecharCarregando();
//            $rootScope.getLocalizacao();
            if($scope.tipoVisualizacao == 2){
                _carregaMapa();
            }
        }).error(function (data) {
            $rootScope.fecharCarregando();
        });
        */
    };
    
    $scope.alteraTipoVisualizacao = function (tipo) {
        $scope.tipoVisualizacao = tipo;
        if(tipo === 2 && $scope.map == undefined){
            _carregaMapa();
        }
    };

    _buscaLocalizacao = function (atendimento) {
        var defered = $q.defer();
        var promise = defered.promise;
        if(typeof google !== 'undefined'){
            var geocoder = new google.maps.Geocoder();
            var enderecoBusca = getEnderecoBusca(atendimento);
            var address = enderecoBusca.endereco;
            if(!enderecoBusca.localizacao || enderecoBusca.localizacao.length <= 1){
                geocoder.geocode({'address': address}, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        var latitude = results[0].geometry.location.lat();
                        var longitude = results[0].geometry.location.lng();
                        var atdcEndereco = {'localizacao': latitude+' | '+longitude };
                        SQLiteAPIAbstract.update('atdc_endereco', atendimento.atdcEndereco, atdcEndereco, true);
                        ocorrenciaAPI.atualizaLocalizacaoCliente(atendimento.atdcEndereco, atdcEndereco);
                        defered.resolve( atdcEndereco.localizacao.split(" | ") );
                    } else {
                        defered.reject(status);
                    }
                });
            }else{
                defered.resolve(enderecoBusca.localizacao);
            }
        }else{
            defered.reject('Google Maps não carregado');
        }
        return promise;
        
    };

    $scope.GetLocation = function (atendimento) {
        _buscaLocalizacao(atendimento).then(function (data) {
            addLatLng(data[0], data[1], atendimento);
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    
    var addLatLng = function (latitude, longitude, atendimento) { 
        
        if(typeof google !== 'undefined'){
                var enderecoBusca = getEnderecoBusca(atendimento);
                var address = enderecoBusca.endereco;
                var latLng = new google.maps.LatLng(latitude, longitude);
                var marker = new google.maps.Marker({
                    map: $scope.map,
                    animation: google.maps.Animation.DROP,
                    position: latLng,
                    icon: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'
                });

                address = address.replace("'"," ");
                
                var conteudo = $compile("<div><h4>Ordem de Serviço Nº "+atendimento.atdcOcorrencia+"</h4>"+address+"<br/>Data: "+$rootScope.converteObjetoData(atendimento.dataAgendamento)+" - "+atendimento.periodo+"\
                <br/><a href='#/tab/atendimento/"+atendimento.id+"'>Acessar</a> \n\
                <a href='#' ng-click='acessarGoogleMaps(\""+address+"\")'>Google Maps</a><div>")($scope);

                var infoWindow = new google.maps.InfoWindow({
                    content: conteudo[0]
                });
                
                $scope.arrayMarkers.push(marker);

                $scope.autoCenter();

                google.maps.event.addListener(marker, 'click', function () {
                    infoWindow.open($scope.map, marker);
                });

//                var markers = [];//some array
                var bounds = new google.maps.LatLngBounds();
                console.log(bounds.getCenter());
//                for (var i = 0; i < markers.length; i++) {
//                    bounds.extend(markers[i].getPosition());
//                }
//
//                $scope.map.setCenter(bounds.getCenter());

//                $scope.map.fitBounds(bounds);
        }



    };

    $scope.doRefresh = function (buscaAtendimento) {
        
        _getCronograma2(buscaAtendimento);
        $scope.$broadcast('scroll.refreshComplete');

    };
    
    $scope.autoCenter = function () {
        if(typeof google !== 'undefined'){
            var limits = new google.maps.LatLngBounds();
            angular.forEach($scope.arrayMarkers, function (marker,index){
                limits.extend(marker.position);
            });
            $scope.map.fitBounds(limits);
        }

    };
    
    $ionicPlatform.ready(function () {
        _getCronograma2();
    });

    var _carregaMapa = function () {

        var options = {timeout: 10000, enableHighAccuracy: false};
        $rootScope.getLocalizacao(options).then(function (position) {
            
            if(typeof google !== 'undefined'){
                var latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                var centro = new google.maps.LatLng(-22.2175846, -49.95052909999998);

                var mapOptions = {
                    center: centro,
                    zoom: 12,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };

                $scope.map = new google.maps.Map(document.getElementById("map"), mapOptions);


    //            var latlng = new google.maps.LatLng(lat, lng);
    //            geocoder.geocode({'latLng': latlng}


                google.maps.event.addListenerOnce($scope.map, 'idle', function () {

                    var marker = new google.maps.Marker({
                        map: $scope.map,
                        animation: google.maps.Animation.DROP,
                        position: latLng
                    });
                    $scope.arrayMarkers.push(marker);

                    var infoWindow = new google.maps.InfoWindow({
                        content: "Estou aqui!"
                    });

                    google.maps.event.addListener(marker, 'click', function () {
                        infoWindow.open($scope.map, marker);
                    });

    //            $scope.cronograma 

                    angular.forEach($scope.cronograma, function (value, key) {
                        $scope.GetLocation(value);
    //                    console.log(value);
                    });

                });            
            }

        }, function (error) {
            console.log("Nao foi possivel obter a localizaçao");
//            $rootScope.geraLog(error, new Error());
        });

    };

    var getEnderecoBusca = function (atendimento) {
        var enderecoBusca;
        var localizacao;
        enderecoBusca = atendimento.rua+', '+ atendimento.numero + ', ' + atendimento.cidade + ' - ' + atendimento.estado + ', ' + atendimento.cep;
        localizacao = atendimento.localizacao;
        
        if(localizacao){
            localizacao = localizacao.split(" | ");
        }
        
        return {'endereco': enderecoBusca, 'localizacao' : localizacao};
    };
    
    $scope.acessarGoogleMaps = function(endereco) {
        //apenas para Android
        var url = "geo:"+$rootScope.localizacaoUsuario.replace('|',',')+"?q="+encodeURIComponent(endereco);
//      var url = "google.navigation:?q="+encodeURIComponent(endereco);
        window.open(url, '_system', 'location=yes');
    };
//	$scope.onOcorrenciaDelete = function (id) {
//		ocorrenciaAPI.deleteOcorrencia(id).success(function () {
//			_getOrdens();
//		});
//	};
});
