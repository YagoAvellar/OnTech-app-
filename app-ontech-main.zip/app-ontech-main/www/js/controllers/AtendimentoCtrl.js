angular.module("starter").controller("AtendimentoCtrl", function ($ionicPlatform, $q, $rootScope, $scope, $stateParams, ordemServicoAPI, $cordovaFile, $filter, SQLiteAPIServico,
    estoqueAPI, $ionicPopup, $ionicModal, $cordovaCamera, config, $ionicPopover, SQLiteAPIGrupo, SQLiteAPIProduto, $window, $cordovaDatePicker, SQLiteAPIatdcOcorrenciaInteracao, 
    SQLiteOrdemServico, SQLiteAPIAtendimento, SQLiteAPIatosAtividade, SQLiteAPIatosServico, SQLiteAPIAbstract, SQLiteAPIatdcOcorrenciaProduto, $timeout, $cordovaFileTransfer,
    SQLiteAPIat, SQLiteAPIProdutoTipo) {
       
    // .fromTemplateUrl() method
    $ionicPopover.fromTemplateUrl('templates/atendimento-opcoes.html', {
      scope: $scope
    }).then(function(popover) {
      $scope.popover = popover;
    });
  
    $scope.abrirArquivo = function(link) {
        $cordovaFile.checkFile('',link).then(function (success) {
//            console.log('success');
//            console.log(success);
//            console.log(link);
            cordova.InAppBrowser.open(link,"_system","location=yes,enableViewportScale=yes,hidden=no");
        }, function (error) {
            console.log("Não Achou");
            link = link.substr(0, link.lastIndexOf(".")) + ".png";
            $cordovaFile.checkFile('',link).then(function (success) {
                cordova.InAppBrowser.open(link,"_system","location=yes,enableViewportScale=yes,hidden=no");
            }, function (error) {
                $rootScope.showAlert('Arquivo não encontrado!');
            });
        });
    };

    $scope.ligarPara = function(number) {
        var timeNow = new Date();
//        console.log(timeNow);
        var data = $filter('date')(timeNow, 'dd/MM/yyyy HH:mm');

        var ocorrenciaInteracao = {
          descricao : 'Ligação para o número '+number+' feita em '+data+'\n\n'
        };
        $scope.openModalInteracao(ocorrenciaInteracao);
//        console.log($scope.atendimento);
        cordova.InAppBrowser.open('tel:' + $filter('tel')(number), '_system');
    };

    $scope.navegarPara = function() {
        var endereco = $scope.contato.rua+', '+ $scope.contato.numero + ', ' + $scope.contato.cidade + ' - ' + $scope.contato.estado + ', ' + $scope.contato.cep;
        //apenas para Android
        var url = "geo:"+$rootScope.localizacaoUsuario.replace('|',',')+"?q="+encodeURIComponent(endereco);
//      var url = "google.navigation:?q="+encodeURIComponent(endereco);
        cordova.InAppBrowser.open(url, '_system', 'location=yes');
    };

  $scope.openOpcoesAtendimento = function($event) {
    $scope.popover.show($event);
  };
  $scope.closeOpcoesAtendimento = function() {
    $scope.popover.hide();
  };
  //Cleanup the popover when we're done with it!
  $scope.$on('$destroy', function() {
    $scope.popover.remove();
  });
    
    $scope.config = config;

    $scope.produtoEditar = [];
    $scope.atividadeEditar = [];
    $scope.servicoEditar = [];

    $scope.mostrarGrupo = {
        'atividades': false,
        'servicos': false,
        'imagens': false,
        'interacoes': true,
        'dados': true
    };

    $scope.toggleGroup = function (group) {
        if ($scope.isGroupShown(group)) {
            $scope.mostrarGrupo[group] = false;
        } else {
            $scope.mostrarGrupo[group] = true;
        }
    };
    $scope.isGroupShown = function (group) {
        return $scope.mostrarGrupo[group] === true;
    };

    if ($stateParams.id) {
        $scope.id_atendimento = $stateParams.id;
    } else {
        $scope.id_atendimento = null;
    }
    var _getAtendimento = function () {
        
        $scope.permitirAssinaturaOcorrencia = 'f';
        SQLiteAPIat.getAt().then(function (data) {
            var indice = Object.keys(data)[0];
            if(data[indice] != undefined){
                $scope.permitirAssinaturaOcorrencia = data[indice].permitirAssinaturaOcorrencia;
            }
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
        
        $rootScope.abrirCarregando();
        $scope.tituloPagina = "";
        if ($scope.id_atendimento) {
            _getAtendimentoID2();
        } else {
            SQLiteAPIAtendimento.getAtendimentoAtual().then(function (data) {
//                alert("teste");
                if(data.rows.length > 0){
                    $scope.id_atendimento = data.rows.item(0).id;
                    _getAtendimentoID2();
                }else{
                    $scope.tituloPagina = "Atual";
                    $scope.id_atendimento = null;
                    $rootScope.fecharCarregando();
                }
            }, function (err) {
                $rootScope.geraLog(err, new Error());
                $rootScope.fecharCarregando();
                $scope.closeModalReagendar();
            });
        }
    };
    var _getAtendimentoID = function () {
        ordemServicoAPI.getAtendimento($scope.id_atendimento).success(function (data) {
            _trataAtendimento(data);
            $rootScope.fecharCarregando();
            $scope.atosImagem = new Object();
//            $scope.atosImagem.imagem = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAEsASwDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDyJLRly0mQPp0pk0gEZx0rcknt9rAP93n5gCP/AK3/ANesfUPI2vtcYHzVq9DFGNGhludqjlj61t/ZiqhVB6fnVLQvszaiHvJFWJAWO44z7VsNqVluIUoFHr1qY2GymbV8EgfSmfZX7/j6VcOqWYPBQVD/AGpaqxO4de1PQWpCLQgnJqQQFBlRyenrTW1aD+FiR9KifVY8lgDn6U9AVyjfbhIQVIxUunQ7m3nBCj9aS/uYroK6BvM/j44qW1vltrNolgYuzhixHGB2/wA+lQtx9C+Yw3TqfbFKIPfB7A1Q/tJ9pAiIz1oOpOgw0bqfc1SaJ1L32UZGWzmhbcEngcetURq7Mf8AVbjThe3BX5Y8KR/eFNOIWZcktJJInwOQucVgspEu09s1pQ315FMsgj3EHoSOR6VUnilkuGlWHYpPC7s4H1qXYqJr6dbkQgn733sVfFmMHcAMc1jtfXJPFsqjCjAYdqet/evJ9xQzHs1XFxRLTNb7FGNw5z2A9M1IbCJSMjKgbj7j8uKxG1q5gyHgUHocMelNXW75xhdqqfWnzRJtI6NdOibd0UKobJPH51k65pRgt1mT5kb5focZx/n3qNdQ1IKCpt8fQn/P/wBeop7rVJ4Xt5ZY/LPbBFDaY4poy7KNp5BGAT9K9C07w/avZRyzzYkYZKlenoK4S2gubVy8MoRipXI9D1q+uqaquMXxAX0jX3qYOw5JvY7g+HdL2HEinHXJJJPp+dEXh7TthIZevUZ6VxP9qasQf+Jg54/uDpVSTW9XWQRm8kB7EcVXtLEqDPRBoGmJheqA8c7uKeNJ0lciQA/Lxhep5zxXniX+pTOBJqE/Xs1WCl4CcX93z1PmHk01MOUp+ILIWWpyIjbk3Ha3qK1PDGmpcXCS3C7oB8zjH5D8aoXGnPKBJPPcSdgz89PeofsWwEJNKB6bqz63LvdWPTCullcCIbOygkY9uPwqNk0/aD5act26GvNhb4/jkP1akkhGwlJpA46DPHvV87JUEek+VYgAbUHYkGmr/Z8fOyMc8gmvLIBJMzAyMPxq4lrH33H3LUlUY/Z2Os8Qw2U9i6wFVkQ5IHoc1w1rt84B2AH861INKN1uMNu8u3qqMS31x1xxUJsoVYjyyPbNKSbGrJHW2NxpdpYrC00DykbnLMM7vT6VKb3TmOVuoFHp5i1xn2WEDJT9TQIYuQEH4jNUnYlxGzabJDbW11JCRDchvKfdndtOG+nP86S90+SwnEFzD5chUOU3glQfXB4Psea29N1u1s9GSKWCSW+tZmlspGwyR7gAcj2I3D3xXPyzPNK8krs7uxZ3bksT3NYmnoNCxqc7QfwpyKpIAUAn0qMYH1qa1GZlPpzTC+hbltrYIQ0Yz6isy2C+Y25dwxwDV25l+T3rPh4ehsaL64VScGupfwiselm68+6Vo7L7U7GFfL3bd2zO7OfwNcvt+UqO4rYvfEVzdtPKLWzguJk8p544juKbdm35mOOOOB/M0CRiH7tISM0g+X8KMYJ6YoEOhUGZO2WqxfODGwPPHANQQD94pz055pl1NlCoP60AivbEbWHvWgh+QVlwkDJrVjH7tee1ERnVz6FZXE0C2G4SQJA13CW+8jKrNKvsN3Pp1rn9St0s9VvLSMsUhuJIlz1IDED+VMivrqC7juop5FuIsbJN3zLgYH4Y4x6cVHLLLczSTyvukkYu7EdSTzT6AMwAPehCN6/WlNMU/OOe9JCIL1wUIzyT0qGJgUHPamztvbHWmxMRxQPobtlN5UsE5RJPLZX2SD5Wweh9q7G80vTDr9xdt5cMVhKz3lo2OVHKFPVXyox2LfSuHtTmBe+KeR6HFUSa/iaNF1GK5hgS3iu7eKdI4+AAyDOP+BBqwzge1PJwD61G2cGgYoYgjBII6EVm3BJkD/hWgDjms6f7zA9QcUug0SpIRz6VvW9w8bRzIULgbhuQMPyPFc3Gc1sae+622/3TjFOIn3NrUtWOpRr58RSRD8gSQ+Wq+ioc47dDj2rIbjpVuOBHtJ5zOiGNlVY8/M+c9B6DH6iqjenr1qgIj06+9RNkq3bipWFMU9cjPHFSwM6NttyT2Jq2snTkZqncKY5zUiPletTsPoatrOYZd+yI+nmpvUe+Oh/WnXV5PeTtNdSNJI38R9PYdh7VRgJZCpNW0aIQvnzPOyuwg8Y5zkflVomxGeeo6etNJ6dOnc0pJpMA9aARUK4GaaQ3HWtdtFvCgk2ptPqwpg0i52ksgxjJ+btUpDMnZjrjmrEA8tXb/gPFaI0qNWTzblFQn58DnHtVSYKA0UePkPH+1SAz7h9xPPFMtxl1HvTGOc5NaehWRu7ojGQqljxk9CePf+uKRXQdTCPxxV1oYFXBbEnPB4/xqIKpViGyR15pklUgjOcUwqfSre1Om7qfyppEHGc7upDdP0oAgjAUM3oKpytuJzWiJkY7NgCNxxWbKhR2X0oGhqVqoMRKM9qo2EBnuY41AJLAYNaN7PHHdSR253RIdoYjr70LYGIB1pccd6rC6IH3FP1zQLs/3E/WgRYPQHpSRr869+RUAu2IP3f++alt7zZKDKN8eeU6cd8ehpoDNfOTTUOMVe1K38m5cqwZDyGXoR61TiQuQB1JxUj6GrY5NuxPTd1NT+vP6UrLHYtFCSjFUDOB2J52n9PzNW49VhCEG3hOR/FErf57frWiRDZnMBzzSYPPWtVdTtA242cO7ofk4/n9amj1u1jiUfZYPNR9yyeUoI+vHt/OnZBcyIrO6uX8uG3kkY8YVc1nX8LRTkMCCex/WutTxXcxoqpJgKMBRwP/AK3asbW5U1AyXi/61m+b3PrSaVgizBU4rX0qKSRiqDJchQKyIl3ttHJPrXT2N1Hpkq7dpZV2nnoT1/z9amJTJ30rUU3ZsrggfxLEWH5jimDSNU2lhp11tHU+Q1XR4lkByZHBz2kNQt4mKkkO4x6Mea00IVyodG1Qkf6BcgnpmJqmj8M6nJsPlIqs23LSqCv1Gc0//hJEJG5pGI/2/WmL4jXEgIOOMA80lYNTI1nTJLKYxMVcqudy9D3/AK1mofw+lbeoanFf25RlKuP4vzrDgUu4QcselZs0T0NPT7ZrmZUjzvkIVfT61sP4du13DzIiV7An/CqFhqMGnOSAWO3ZuAzgdz/n+takOtJIhZWx61cSWVm0K8UjiIgnHEg4/wA/0pp0S9zwsZHb5xVt9UjXc7NweRxz/wDXqi2uHJCJ8o4+9inoTqZzakzcljn60z7exyGZz+NaP9n2oyFhBH+felW0tjnECH6rWdzRKxlfbOvFMNzlgwGCPTvWyLWAf8sYx6/JSraQ4OIYx0/hFIaOeudpcsn3W5qeC5+z2xRcEydeOlbn2aPJHlqD/u0eSmCoHrjigdjBNwTk/wAqYLhsY6V0apjoBkdSKAv1oEonNmVzmgM/J2nP0rplQZ6igLyec/hRcLHM4lPIVvwFSTpJOgfyn8wcNwefeuix2HSgL2U9KLjsc9ax3ECs6xSBzwPlNM+z3OSTDJ/3ya6MgYOKXBPUChBY5z7JcnpBJ/3zQLK6I/1D10oHqc/SmgAUJhynPLZXmceU1KLK7HSI/mK6AAkHI5ox17Ci4cpitaXksQjePO3odwptvp9xHIHZF47bq3NoKmgLjIHX6UXDlMh7W8ld3dl3Ock7uppo066P8SfnWyE5/ixS7T/EefencOUxxp91/wA9I8fWlGmTd5VH0FaxUZ460bMrnPT2pKQcqMldNcZ3TgfhT1011Unzuv8As1pFD0zn8OaMMARk0XBRM2301YJQ28tj/ZqC6D253D5gR1rXx1B4NUr3gKevJGKEDRkLI8g2qD+dWrW3Dyjecgc4qnE2wkZrQtWxKj9t1Aki59miVR8kfPsKd9ni5IiX8RUw570ADr/kUXKsQCCPnCL9SKFgjU/LGoPqFq7Z2s19cxWsCb5pWCKoOMkmrsfh/UXnmtxCDPDKkLx7hnczbR7YzjnP8QoQrGOI1xwopAmOAMVaubSe0uHguYmilRsMrrgioQTjaRQFjK1AOmGB69RVPYzAEvjPtWteRh4SoH0x/n1rHVuKLitY6wFzkZ6cijHUsetKG29clfpSgfe+bPNK5aQ0L2703aAevHNS9sce1GAcjPJFK4WGDoTn9aCSeSKeAQuB+dGBg/Wi47DSByQCM803PAp4QZ4GAKQggdcUrjURAOCPzFCn7w4I9+9Lt4PSlC8H0pXCyGkAAgGlwcHI/GlAJyDk47U9cHgYwM0XK5RmMqSeMe1IB7/SpFXKcEgdz7VIqqSxyQRz60rjUSEIS2T1o2Z9DUowuR19MHilBw4OD7nbmlcfKQhQMgc4IpSo4qT5dp24xx35P6U1sKGyPlxz3FO4cowofXHekCYPGCe45qUlRjAx+lMVsDKgD8eKEw5RQuFOevcUgUFSB1HUDml8zPbn1zTd6gYAyO4pishcEfKfx9uaQnPAz7Gmebng8HPQc00nqcDigQ88YGO1MPHAppI5+lN6ElTg98U0J2Fznp071Vu1IhH+yc1OOOhNR3CloHXv1poh7HPnIkbJq5AxGKrTJsmI9as2+cdPxqiEbC5A579CKXnnPQ96YvABBzwKMg55z6cVKZZsaBqFvpl99tmjZ5ER/JA+75m3C55HGTnjkYrZk1ZptGe9l026tG8j7Mk1vE3kttdCmXYk5+Qqep6elcgkgjdWZAwHJXnmuv1D+ztQk1PVpNWBjmgaW2H2lAy4bKQNBgsQCB/s8ZppWYGBrl7DfapNdQeYPOxI4Y52s3JCn05//V0rMAxn861fEtzDPr90tp9k+yRvthNvGiLt6j7vXr15rJLYJo2AjlXMbKeDjNYTgJIynPB4zXQZ659cjisi5tj5v7tGYY5x0BoQjpFPcgEfXpTuNuegqszZ7daUyDJwSfXNKw07FjeMnj600HHqBk1Dv3HJ69eaA+AfmGT6iiw1InVsA+g60m4EjBxioQwAIx07Gk8w9wM0rMfMTg85B59RTSeNucAc1Dv68/pS78A4p2DmJh90c4GaTd34qLeDmm78jpSSYcxOW25X8KN+fp7GoVfHt6U3fx1/OizDmJyR9SKVX659OnpVbzO2ePSl8w89KOUOcsB3Hf8AIUvmHJOc/XmqvmdeeelJvznmjlHzlxWBYZyAO27mmmQknJHPPSq3mdaA+aaiLnJxIcE5o38YOag3k/8A66TcaOUXOTls9aC2OB+HFQbj1o3jbzRyhzE245I703cMGo9/UGm5GOmKaiLmJ92BzjNIGGeuSfWocHNL82KFAXMSbuvPHtUcvzRsvHIxTgjjsRkelCxOSSvUcn2pqNg5jEul2yg4xkVPan0pL4E4JwSvy5AxwKW06UEmmAFRQGDDAJI/z2pFOSetPihLxg/hU/2Ngp3d+y/N2z26UKI+Yr5A6VFsBz1q4bMg8hiOny96QWb7GO3AHQn09aaiLmKq4UYAFAOB1q2LKTJXy22nhdw7HvSrZv025z0wf8/zo5QUimSACKgaURu4PGTmtNrJxgkY5xz1z/Sq9xZlJAGJzjtzRyj5hNrAEkcU4RyBA2DhsjPr6/0rcW1iaFQFxuGVJGOfXGfaoxDGoZThkjwvzj/a65FXyGfMY4jfbwCT6Yo8mQKcr9cdq1Wt7clUdyhLBVLcev8A+rHtSeX86b4lPIThDz06j86agHOZRBycDpSYJGTyK0PKQxAo+XdDkH6Dg/n+n5Ryrl2O35t+Qo2nH5f4UuUFMp8r3z9KQZ6fnVoxqFkVjuEZI3buGODjn6/zocq853qp3HG1Rxjnp+gFKwKRVGTnFIpP4e1TMQu7bgLgqQe/Hf8AT+lNl6uHG1z8pQDAGPb9OlFkCkQ54PzAfWgkqSDkGnHlGVFRgfmAOcjrx/X8qjBwefQH3zRYdxC5Gf5UbyTxikQ59fumo8Db0osK5KW4z+tJ5mBTDng7falBJ+XCnHpRYL+Y9WPp16UZGByOe9NUlRwRx2zThyG4/HriiwXY9RzjoTTgGAyV4/nSYIXk7v51NG+0AKpGevbIqkieYUQsVU9M+owKmjtW2iQjI9P8/XtTj8wyHJ/2AvRRj/P4VNbyKSFdmTsW6n6fqKqyFdjYrF8ldu8AbjhsZHPIzTzYgQF9oG0E8sqkjt/KrTxyeaTnOWHLH24J75P8qFU4jXa4YnK4kIb/AOv+PpTshXY06VEWO5ztbqSMYNWU01CBkLkjgEZGf/r9fx9aSSd+q7VyS/ACg5PPT6VOGbICqSpYZZzhRx344GCKBJsiGnRbeinBPKkKe2PX/JpV06HcWcbiR1IJIPvn6j3zS72MmYHT5flUA4Hud31/mfwmd3cBk6h9q8Y/yc9qVh3ZxWtW4jllZSuHO9cHdxk1U09S7ADnFdN4hgjutNe5WVWdOcjqR/n+VYGjSW8Tq88oTY27HrWTWprF6HW2lmfs8IYk7QWYADGfc89Ks/ZozIoGIy42578+/wCPc1SGv6SindOjNx0RvUe3+efakbxHpokQw3WFDHjyz8vp2+vr1q00RZl1bK32Mv7xWPcn8D3/AM+/WpfssIjKEfLnHzfT9MZPSsc+K7PaU3Nz/EqkHt/hUc3iy2Ytjz2P8OTRdAkzcFrauu0uvTdjJPXJ69/Tj/69ASCNB5ih2BzzwB6fpxWBH4ps40GxLgv34Xbj6f5/WiTxXYs2fs0xznepxjHtTTQrM29kYUliAcdPbp/hTGt7ZsGXazf7QPHtWIfFltkEWkpIGMb+CO4/Go/+EuVeBalQABwV59+Qf8/nS5kOzLv9q2KBi1xzk7QHwQPTOePw9famtqtuNsgvIioOBmQF+oP169//AK9YI0dAf9cxH+7ilXSIT1kk/So5machrvqlpsWI3SlVdi2zuePXFR/2pZIdq3EZBABODgHuf5/nWb/ZEH/PST8x/hR/ZNvyQ8h/4F/9ajnYchdGrWo3f6QmHB35i6cHpx7+1NfVbFY3VJgRu2rmM8rzz7VAul2w7Mf+BUv9m2vP7r/x40czDlQ3+0rZVkAlLq/Zg2R6H3/+vUY1G2Ujl2C8jHH+cVKNOsxwIc/8CNOXT7Uf8sRn3NHMw5SAapAN6kyFCRxsA6fjTDqdtjiN+OR061cFlbAHECE/SgWtuP8AlhH/AN8UXGolA6lF83yucjAz+QqMaigOfKOc84atT7Pb4OII/wDvgUqxRL0RB/wDFK4cplLqQA4jbePusH+7Sf2ggYlYe+eWzWyEwAcDHrijOM4ouw5TFN8XP7uDHPA60v2q4ZQogOM56Gtr1oz6k0XY+VGL59yWJ+zN/u7WxTjcXu0gWpH/AGzNbAxjnmj2ouw5UZPnX7gjyTjHQpSpJqYJKpzyO3etPb3x+NA70XYcqKAk1gESbCCTvBIHzc9eev8A+upEudZSExqwVCc/dXP59atYNLg49aFJhyoo51Ypg3BAPYNjNCrqwJIumDdPvn/CrwU9jS8UXYcqKWNWwR9vcdsCVqYbS9kz5l456dWJ6VfAp2M0XYcqM77DcMMG8fHXBz/jTv7NkY83TH8D/jV/bwaUDg+lILIzhpSkndK5/ClGlxdDI/T2/wAKvsB3xQAepFAFFdLhB6ufxpw02BR0Y/VqucjjJpPmxRqGhW/s+2JJ2H8WNOFhbYH7ofWpy3/6qBwCe1CDQg+x244EKflTjawcfukK+u0VIpx1/WjPXH5UxDBbwA8Rp+QoKxLxtX8hT93Bz19KTdj+HNAEnp1o4pucZGaCeveixQ4UfKc0gIHTgUh6e1ArjhjtRnk0zJAOad1XOPxoBWEGecU4YyccU3kZz1pOvNAXHLkjim5x/wDrpM4GKAaQDicE8UgpM4z2NBzmgLjg3XFJ06UwHGaXOO9MEO+ppQetM3YBzSbvp+dAD+DTqiB5pwPX0oAf254FIAKbuJ/+vS7jgUBoLj2owMUm40c0BcXJx04oHekHTFIO3OaLBccT7UA4zQAMdTS7Tg/yoswuIOhzTj0zmk28UoGO3P0p2FcT8aBznmnBSe2aTB9M/SiwXEHfNAx1P1p2DtBxQB7UWC5H3IIowDUojcgnJPvQQCScY/CiwrkW31pCAcntUoXAIP6CjY2MDjPSiw7kePbNBiLnKoSPrmpSgDYAPpzTflBxuAoENwCB82R0pBjn2PSnbR0x+FG0gZIYAjI469qdguN74zQOnWpMFuSB07cUgXkgDp1pWC40EHPakHfnilVevBzTmjHckcUWC4zOF9qTv0pVGTjjnt60mQo6jPtQkFxTkZz600cEjvSknaR+NNGT04osCYmeKN3BpOccDHrTeQC2ODRYLjg3Dc4pM9cfnTQMd8Z9aQcdB9KLBcfkUbs9aaKN2T7UJCHA8gd/pShhj1pgPX1pc96dgH5OM0ozjOOKjVst/jTkzk/4UWFckGO5pcZBxTVXP1704FsHnHYVSQcwAZ4pwGePQZqRYy5+QZ3dMHpU6Qbzx0J2jn/PrQok8xXCEjvkU5UOMAZ/pVn7NtOD90/MO5x71ZW2CkuTnpyfWmohzGeEz2P5UqxHBDc57r0rQNr5oyAofsBjn8+npj1p6WjOqZXIbOC67RnsaOUXMZuwH5SOwwfWniEMD16cZ71pfY0UKAR0zndkY/z/AJNOS06hfMLPgggc9DxRygpGV5W0nJGB2/vUGNckkhc9Petf7Er4GdrDAHA9f8c0fZiYuPkIBUEDJIyfT/PFOwKRk+Qwflcke/8AnNIITtPHt71qfZxhnVwy9uO/+f5U4wIoIdcgHqD70uUfMZXkNkjOAewPXvSrCx5Ixn2q+bYcZ6qDlufzqdbcHIYEgD+Id+aLBzGSLdslWU59QaBFGR8xwfc4/rWo1tngAgthR06+v60eVIGYCHd9TjHFKw0zPNlLuwAwx1Xvu/DoaVLJnCjgZyQc/KR6Z/P9K2PtsKYaMxoB0TYCG7Hr+J/Gqxu7dmZJFyAGwxGCBnqR2PI/wqrBcz/sEm5t20lWKlc4x/8Aq4qL7NIwUbO2cnr9T6DrWnLNbjLpG3lZKjJGXPr/ACzj6d6qTT7ZAzPuO4gsec45GRzn/wDXSsFyoYG2hWTO7nHQqMHr/Om+SVV32ttPyjPXNWnk3ysVJVSC+wZUY/D6VWlmTZjhjuBLHqPakCGMjFMlNu3g7jz+NI6gAg9d3YZP1zSvMjAZzk5G4A9M/wCfy/NFcI7EOBtOMHPH+SP1pWHqM2bSc88ZNN2jB44HcH/PpSGUq5J55696iDn5snGfyoDUViOvXrx/n/PFM46Z9qUSpuYgk/T5aYWG7cRgli2OgzRoCuKOoz2FNGSTxwe1KWy2AefXNMD5Jx6cmkA/5gMjtzxTNxHU89jSZ/2eM9aQnn09BRcLD84A5pQSMjJx71Bv65P6U4MAeuKEwJ0IOBxzxzT1+bByBx64qqGHU08SdCelO4rFlG4JLBuOlWEYl/m+6Bzx1Aqgsx7nOORnn8aXzSqsM/hVJi5WaiFCoTndu4CL1qxkvI2QyAZz6Dknp+VY/nqSAGx/+uni8cDaGVue49v8/lTUkLlNuGQKMEjjLqOuM9qmE6rExMjMgLZPGDxn+lYKXQA++M+pPt/n8zTlvsKcADPO7OD/AJ+lPmQuU6QXMZCfJtjLcgcjrnsPenpOFGN8ZB+ZQg5I6559wPp+Nc2b9CpEjhnBI3f3hz39KP7TTb8rZIIwMAcD9e/+exdCUTokmjUR5fjduIYfdPQ9vp+XvTvP2kSBslV+XfzkY68n/GubGpxIkZ5DAltx7VdSO+l3PBp964zkFYXOPyoug5WbIuQ0g4j3dcjGCSc/5/ziOS4QyIWQnI2lS3HPGelYMl1NHIZJ4JgR3kVgfzpBdMScxSlSf7pOaLofKzdjug0jZIcemP50rSKgeMcMevb09+P8/Ssu2h1G/IFtZzMe4b5cnJ55qW5stTtoz58McS9ebmPPfr81LcaRcM0ShmJAA7b8D8MUpu4wgCnI7jB49/esV724AP3eeOJFxSRXEk7su+NfmIy0mPyouOxsicuuSF6gg8+v/wCqo2vpAf3cS7cD2/oaryWtwFMiXNkzdSEl3fpiqjG9BIVAR2xux+lJCsVWv1BJ3n06844pGvFdQpbPB3E8/T+gqg1/GwOLG1Ge4Vs/+hVB9o6ny4/++BUXNbGlJfo6kK5UZ4Unj2H4Zpi3wVeJMnA6N3yevr1P51R+1yjpsH0UCj7bPyA459ABSuFkXTdgsDhtwB+bPJznP+FM+0HaFUuR7A5/P8qpG4mPWRvzo+0zY/1sn/fRouCLgkkOWCvx2ppeTf8AdfHP8NUt7n+Ik/WjJIOTmi47FwO4OSnHfP8An2ppkPy524H+0Kq4POKTaxHSi4WViwz+n8xTfNxmotjemKPKcjIpBYk3g/xcemKA4GcVGI354pfLbHSi4DvMHf8AnSeaO/H0poiY0ohagAMnFOWfC7QOfX1/WjyT7UeSetACeb7UB+SaXyval8rHagLCCXGeM0vmk9QKBH704RepoBDQ5/2as22oG3BH2a1l95I91VzFjq1JtTHLfjQmFiaW7aVtwihj9o0xmohM4IJ2kqeMqDim5QZpNydBQmw0Ne18TaxaQmGC72If4fKQ/wAx7VSu9Su70lriTcfZQv8AKqm9ewpPMGOFppsWhN9plyG818jvmrMWsalCoEN/dxj0WZh/WqGSRwo/CnKJG/hP5UXDQsy6hdXB3T3U8pBzl3LVGJGJPOaTyJz2xS/ZZSOtMQvmN6n86Nx7mnrZORnNSpZMePmP4UAQhvWlDn1q4mnOckxyf981Yh0WZyAlrO30QmgDM3t/epN55rfj8M3zZI064/FGFTDwzqIH/IMlPuRTQHKG0l7K2fpQLGc5wp/KtQTOTgIzfhSiS467Hx24qC0jKFlcH+An2ApPsVxg/uzitcvcf885PpimA3OSfLkz9DQIyvslxg/uzTDBKvVCPwrX82Yfwv8AkaQ3Mg6j8xQFjI2OM5U/lTQcdq2DOAvzID+FMMsJyGjWgGjLDMAcZFOWQjvWj/ouDui/KjZZkY2YoCxniV/Xmnh35+XP4Vd8qzbgBvwpBBak4AbH1oAqB5eyH/vk04GU9I/zWrn2e0I/ipDb2g6eZ+dA7FcJcY4iFL5V1jiEfmKm+z2v91vzpyw2YHKflQC1Iltro5/dqPqakWxu26eWPxNL5Np/dagRWv8AzzJ+posxANMvT/HGP8/Sj+zrgEiS5iH40gjs8cxt+BpdloOkWfq1IPmH9npzuv4wfc//AF6QabCck6hF+Y/xp4NsDgQD86UNb8/ulFCTDQiGnWozuv4z9MU9bHTe96fwH/1qf5kI6RoPwpBOhz+6Q/UUajVhy2WkZw123HqD/hVyHSNHdd32uHHo8wWqW+PGTHGfwpN0QH3I6LMNDZj0jQ1PNzafjOD/AFq3baDpFySsL28p9EkDf1rnP3GMmNfzpQtsRgrj8aVmCsdjF4Xs1xiLpzjJrTt9JhiwEsrU4/vQqT+teeLb25HAb86mgmntY2S1vrmAE8rHIyjNKzHoekxWFsvXTbI/9sV/wq3FZ6fnnTLYfSJf8K8+h8Sa/boixaisiKekkasT9SRn9a1YPH+rxygz6dZTR/xCPcrH8cn+VHvhaJ3dvFYouI4VjHoqAfyq7HBCw+Vga4y2+JNsJCLzRpoo8feilEh/Iha1rX4geGpt3nNcWuOnmwE5/wC+d1Lml2GoR6M6NbIEcU8aeP7tUbXxP4euI/Mh1ezAPZ5RGfybFbkE6yxLJDKrxtyGU5Bpe0a3H7NFUafx93NA0/8A2GNaaTMPepPPX+7QqgvZnL/2DpqEn7LCD/uL/hS/2NYAY+yx4H+wK2Amc4FHlE9s/hVIPQx/7LtBnFtGP+A006bbYx9njx6bK2jAfTmgWrnPy07gYJ0mzIx9mhx/1zFRtoensCGtISD/ANMxXSCyb0FKLBsdPxo5hcpxsvhPSXyTZJ9QTVOXwJpEhyIXT/db/GvQRp5705dPBHOPypcyDlZ5m/w70wqQvnBuOSwP9Kqt8N7fOEuZF/4ADXrC6aD1/SnjTU5zmjnDlZ5D/wAK0iJP+lvj/rl/9ehfhmnOLx/+/f8A9evYl02MD7pNSLp0P9wUKYch46PhjGel4/8A37/+vT/+FXRHgXzj/tn/APXr2RbGEfwCpFs4h0QflRzhyni4+FsZ630mP+uf/wBenp8LIsf8fzn/ALZ//Xr2gWsePuj8qUWyc8Uc4ch42nwstyMG6kJ9kqQfCq15/wBIm/75r2IQKO1L5KDjFHOHIeQJ8K7EZ3TXB+gxU4+F2lcc3P8A30P8K9Z8pfQUvlLjpS5hcp5Snww0oAYW4P4j/CpU+G2kqTuhkYe7V6gIlx0/Sk8pTkY/SjnDkPOF8A6Kn/Lgp+rN/jQPAuij/mHr/wB9N/jXoxhGOgpv2daOcFA86PgbRcf8g9cezN/jUT+AdEYHFmV+jH+tek/Zh6YqM2i46CmphyHmD/DrRyDiOUfR/wD61VZ/hvpTAiJ50PqSG/wr1RrNcYxx7CoHslweKOcOVnkknwxtyGMd/Ipx3j4/nVCb4Z36AmG9hf8A2eR/SvZHshzkVA1ocGnzC5WeIzeBvEFuu77OHGf4CGP6VQuNI1WzIFzYSL6ZUjNe8NalelM8t19aaYJHghaNAd9vOh/3s0oayYgNNInHJdM17dNYWs5Yz2cEhPUtECay5/B2gTqwNgqE/wASOQadxHk62MMxPlTQyegztP601NMnjcSwrIpX7rRtyPpivRpvh3orqfIkuIX/ALxIb+gqjL8NirA2mpfXeCv8s000Fmczb634nsZC0erX248ATN5g/Js1oRfELxLGm15rSUj+J4cE/kQKsyeC/Elu/wDo1yk644PmDH/j1Um0jxMp2tpe9h1byM5/GlaI+aSPdFgXPSniEelWAgHFOC81imbIriLqcClEWO1WMAGnYHSgCuIuDSiIDPFThe1OC80XBMhEQpwjA9Kkx7UuMdqAuMCdcUBOKkx1ooEM2jpTggp1KKEFxu3rSjpQPeigBR0oBpPWigA60UnWlzxQAtGaTsaSgB3X2/GkBGTmmg475paSsIUHg0euKQGjpxQNC0YpBzxRmgAwDximbMinjpQKQEJjB7VG8IxwKsjvSGmgKLQAjkVE1sDmtDA9abtHanewGU1qDUJtSCcCtjaMVGYupFNNisYzWuB0yaja3YZ61tGEc1GYBg0KVgsjFMbjJGaYUcnpWw1uMEbaj+zL7flT5hKJsADmnAdaVRxSgcmpKEwOelOCgUY6+9OHApoENA/z+dFLxzR1zSABS0g9KXoKADHWjvRSZoAWijNNzxQAtHrzSZpOKAHZ4pAaaTxSA96EA7PXFGabnrSZpXAcGxnFJupm45o3cUAPDHP0o3dc9KjDd80m7NF9AJi1Ju6ios4ozmhWAm3daA1QhuDS7u1AEgal3VGG60ZGaEwQ/PNGcdKaD170ZzTQC54NIOtGaQGgBD3FJ1pexpO1ACdcjmmnvTs56UlAxu3g8U3YM9KkpuKALfrSikHelHGaBCjiik7UCgBR0NL0zSfSgdKYIQc0uaSgd6QDqQGgfWk9aAAmk780uabn8KAD1pM0c0nSgAzSE+lJ+dJmgBQaTNNFBNFgFBpAaaKX1pAJRScUmaRQufegHrSetJ60Ei5pQetNB44pcigBwNKO/NMpaAHg0u7g9Kj3e9APWqWwD89aMim5696AcUAOzxSZpuaTNADvWj1pM9eaM0DFB60hNGfpSZzQgLn8NANHODmihCD8aKBR60AA6mgd6QfjSjjNACjGDQD1pBR2PNAC59KTvikFIaAHHqab2NJ70maAF9ab60E9aSgBM9aQ9SKM9cUmaAFzTc0bvSkJ4NAB60etJnikz2pWAUd+aQnqaM8GkyaLAKDikoB4PNN+tACincYPNMz7UoPB/wAaLALnNKCOabSA8H0oWwDs0U3PWkB600A8GjdTM0meaAH7vxozjNMz6GjPWgB278qUGmZxQrUAPz+NGaZnrRmkM0R3o+lNBzmnAcD3oQB+NB780g6/Wj1HpTEO+lFNFL1BNMdhAevvS+tNzS9DikIB3pM4o/wpgPFADs0h6Gg9qb2JoACfTmkBo65ptACk9abmg0negA6ZpDSZODSjpQAZpucd6B3oP3aTATPFID70h4z9aKQBnIoz1pO340DvQAo+tGc03OMUvbNADu1JSN0o7U7AKTTfWg8CkB4poBaM8UlJQA7NAPWg8U0d6QDvak/EUgPNA70XAUH3pc+tNz/KkPWhDP/Z";
            $scope.atosImagem.imagem = "";
            $scope.tituloPagina = $scope.atdcOcorrencia.tipo + " Nº " + $scope.atdcOcorrencia.id;
            ordemServicoAPI.getAtosStatusFinalizar().success(function (data) {
                $rootScope.atosStatusFinalizar = data._embedded.atos_status;
            }).error(function (data) {
                $rootScope.fecharCarregando();
                $scope.closeModalReagendar();
            });
        }).error(function (data) {
            $rootScope.fecharCarregando();
            $scope.closeModalReagendar();
        });
    };
    var _getAtendimentoID2 = function () { 
        SQLiteAPIAtendimento.getAtendimento($scope.id_atendimento).then(function (data) {
            var Atendimento = data.rows.item(0); 
            
//            var atosAtividades = [];
//            SQLiteAPIatosAtividade.getAtosAtividades(Atendimento.atos).then(function(data){
//                for (var i = 0; i < data.rows.length; i++) {
//                    var row = data.rows.item(i);
//                    atosAtividades.push(row);
//                }
//                console.log("data.rows.length");
//                console.log(data.rows.length);
//                console.log("data");
//                console.log(data);
//                console.log("atosAtividades");
//                console.log(atosAtividades);
////                defered.resolve(_finalizar(atosAtividades,0,dataInicio));
//            }, function(err){
//                console.error(err);
//                defered.reject(err);
//            });
//            console.log(Atendimento);
            _trataAtendimento2(Atendimento);
            $rootScope.fecharCarregando();
            $scope.atosImagem = new Object();
            $scope.atosImagem.imagem = "";
            $scope.tituloPagina = Atendimento.tipo + " Nº " + Atendimento.atdcOcorrencia;
            SQLiteOrdemServico.getAtosStatusFinalizar(Atendimento.tipo).then(function (data) {
                $rootScope.atosStatusFinalizar = {};
                for (var i = 0; i < data.rows.length; i++) {
                    var row = data.rows.item(i);
                    $rootScope.atosStatusFinalizar[row.id] = row;
                }
            }, function (err) {
                $rootScope.geraLog(err, new Error());
                $rootScope.fecharCarregando();
                $scope.closeModalReagendar();
            });
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
            $scope.closeModalReagendar();
        });
    };
    
    var _trataAtendimento2 = function (data) {
        $scope.atendimento = data;
        $scope.ocorrenciaProdutos = {};
        $scope.atdcOcorrenciaInteracoes = [];
        $scope.atdcOcorrenciaAnexos = [];
        $scope.atdcOcorrenciaExpositores = [];
        $scope.atdcOcorrencia = {};
        $scope.contato = {};
        $scope.atosAtividades = {};
        $scope.atosServicos = {};
        $scope.atosImagens = {};
                
        SQLiteOrdemServico.getAtdcOcorrenciaProdutos(data.atdcOcorrencia).then(function (atdc_ocorrencia_produtos) {
            $scope.ocorrenciaProdutos = atdc_ocorrencia_produtos;
//            console.log(atdc_ocorrencia_produtos);
            return SQLiteOrdemServico.getAtosImagens(data.atos);
        }).then(function (atos_imagens) { 
            $scope.atosImagens = atos_imagens;
            return SQLiteOrdemServico.getAtosAtividades2(data.atos);
        }).then(function (atos_atividades) {
            $scope.atosAtividades = atos_atividades; 
            return SQLiteOrdemServico.getAtosServicos2(data.atos);
        }).then(function (atos_servicos) {
            $scope.atosServicos = atos_servicos; 
            return SQLiteOrdemServico.getAtdcOcorrencia(data.atdcOcorrencia);
        }).then(function (atdc_ocorrencia) {
            $scope.atdcOcorrencia = atdc_ocorrencia.rows.item(0);
            return SQLiteOrdemServico.getInteracoesOcorrencia(data.atdcOcorrencia);
        }).then(function (atdcOcorrenciaInteracoes) {
            $scope.atdcOcorrenciaInteracoes = atdcOcorrenciaInteracoes;
            return SQLiteOrdemServico.getAnexosOcorrencia(data.atdcOcorrencia);
        }).then(function (atdcOcorrenciaAnexos) {
            if(atdcOcorrenciaAnexos.length > 0){
                $scope.mostrarGrupo['anexos'] = true;
            }
            $scope.atdcOcorrenciaAnexos = atdcOcorrenciaAnexos;
            return SQLiteOrdemServico.getExpositoresOcorrencia(data.atdcOcorrencia);
        }).then(function (atdcOcorrenciaExpositores) {
            $scope.atdcOcorrenciaExpositores = atdcOcorrenciaExpositores;
            return SQLiteOrdemServico.getClienteEndereco($scope.atendimento.atdcEndereco);
        }).then(function (atdc_endereco) {
//            console.log($scope.atendimento);
            $scope.contato = atdc_endereco.rows.item(0);            
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
        
        
    };
    var _trataAtendimento = function (data) {
        $scope.atendimento = data;
        $scope.contato = data._embedded.atos._embedded.atdcOcorrencia._embedded.atdcEndereco;
        $scope.ocorrenciaProdutos = data._embedded.atos._embedded.atdcOcorrencia.atdcOcorrenciaProdutos;
        $scope.testData = $scope.atendimento.dataInicio;
        $scope.atdcOcorrencia = data._embedded.atos._embedded.atdcOcorrencia;
//            console.log($scope.atendimento);
//        console.log("ocorrenciaProdutos");
//        console.log($scope.ocorrenciaProdutos);
//        console.log(Object.keys($scope.ocorrenciaProdutos).length);
    };
    $scope.carregaImagem = function (src) {
//        console.log('carregaImagem');
        return src;
    };

    $scope.fazerCheckin = function () {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirmar Check-in',
            template: 'Realizar Check-in agora?<br/>Os produtos informados estão corretos?'
        });

        confirmPopup.then(function (res) {
            $scope.closeOpcoesAtendimento();
            if (res) {
                SQLiteAPIAtendimento.realizarCheckin($scope.atendimento).then(function(data){
                    _getAtendimentoID2();
                }, function (err) {
                    $rootScope.geraLog(err, new Error());
                });
            }
        });
    };
    $scope.confirmarAtendimento = function (id_atendimento) {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirmar atendimento',
//            template: 'Fazer Check-in agora?'
        });

        confirmPopup.then(function (res) {
            if (res) {
                $rootScope.abrirCarregando();
                ordemServicoAPI.confirmarAtendimento(id_atendimento).success(function (data) {
                    _trataAtendimento(data);
                    $rootScope.fecharCarregando();
                }).error(function (data) {
                    $rootScope.geraLog(data, new Error());
                    $rootScope.fecharCarregando();
                    $scope.closeModalReagendar();
                });
            }
        });
    };
    $scope.fazerCheckinAtividade = function (id_atividade) {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirmar Check-in',
            template: 'Fazer Check-in agora?'
        });

        confirmPopup.then(function (res) {
            if (res) {
                $rootScope.abrirCarregando();
                SQLiteAPIatosAtividade.realizarCheckinAtividade(id_atividade).then(function (data) {
                    _trataAtividade2(data);
                    $rootScope.fecharCarregando();
                }, function (data) {
                    $rootScope.geraLog(data, new Error());
                    $rootScope.fecharCarregando();
                });
            }
        });
    };

    $scope.fazerCheckinServico = function (id_servico) {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirmar Check-in',
            template: 'Fazer Check-in agora?'
        });

        confirmPopup.then(function (res) {
            if (res) {
                $rootScope.abrirCarregando();
                SQLiteAPIatosServico.realizarCheckinServico(id_servico).then(function (data) {
                    _trataServico2(data);
                    $rootScope.fecharCarregando();
                }, function (data) {
                    $rootScope.geraLog(data, new Error());
                    $rootScope.fecharCarregando();
                });
            }
        });
    };

    $scope.reagendarAtendimento = function (reagendamento) {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirmar Reagendamento',
            template: 'Reagendar?'
        });

        confirmPopup.then(function (res) {
            if (res) {
                reagendamento.id = $scope.atendimento.id;
                $rootScope.abrirCarregando();
                ordemServicoAPI.reagendarAtendimento(reagendamento).success(function (data) {
                    $rootScope.fecharCarregando();
                    _trataAtendimento(data);
                    $scope.closeModalReagendar();
                }).error(function (data) {
                    $rootScope.geraLog(data, new Error());
                    $rootScope.fecharCarregando();
                    $scope.closeModalReagendar();
                });
            }
        });
    };
    $scope.fazerCheckout = function (checkout) {
//        console.log(checkout);
        var confirmPopup = $ionicPopup.confirm({
            title: 'Confirmar Check-out',
            template: 'Fazer Check-out agora?'
        });

//        console.log('checkout.finalizarAtividades');
//        console.log(checkout.finalizarAtividades);
        confirmPopup.then(function (res) {
            if (res) {
                var timeNow = new Date();
                var dataFim = $rootScope.converteObjetoDataPost(timeNow);
                checkout.id = $scope.atendimento.id;
                checkout.atos = $scope.atendimento.atos;
                checkout.atdcOcorrencia = $scope.atendimento.atdcOcorrencia;
                checkout.dataFim = dataFim;
                checkout.itadauUsuario = $scope.atendimento.itadauUsuario;
                checkout.finalizarAtividades = checkout.finalizarAtividades.toString();
                checkout.finalizarServicos = checkout.finalizarServicos.toString();
                checkout.naoProcede = checkout.naoProcede !== undefined ? checkout.naoProcede.toString() : 'false';
                $scope.checkoutAtendimento = checkout;
                if($scope.permitirAssinaturaOcorrencia === 'f'){
                    SQLiteAPIAtendimento.realizarCheckout($scope.checkout, $scope.atendimento).then(function (data) {
                        _getAtendimentoID2();
                        $rootScope.atosAvaliacaoAtendimento = null;
                        $rootScope.fecharCarregando();
                        $scope.closeModalCheckout();
                    }, function (data) {
                        $rootScope.geraLog(data, new Error());
                        $rootScope.fecharCarregando();
                    });
                }else{
                    $rootScope.openModalAssinaturaCheckout();
                }
                
            }
        });
    };
    $scope.changeStatusCheckout = function () {
        if ($scope.checkout.atosStatus == 5) {
            if (!$scope.checkout.dataReagendamento) {
                var d = new Date();
                d.setDate(d.getDate() + 1);
                $scope.checkout.dataReagendamento = d;
                $scope.checkout.dataReagendamentoFormatada = $rootScope.converteObjetoData($scope.checkout.dataReagendamento);
            }
        }
        $scope.counter++;
    };
    $scope.finalizarAtividade = function (atividade) {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Finalizar Atividade',
            template: 'Finalizar atividade agora?'
        });

        confirmPopup.then(function (res) {
            if (res) {
                $rootScope.abrirCarregando();
                SQLiteAPIatosAtividade.finalizarAtividade(atividade).then(function (data) {
                    _trataAtividade2(data);
                    $rootScope.fecharCarregando();
                    $scope.closeModalFinalizarAtividade();
                }, function (data) {
                    $rootScope.geraLog(data, new Error());
                    $rootScope.fecharCarregando();
                    $scope.closeModalFinalizarAtividade();
                    $rootScope.showAlert(data);
                });
            }
        });
    };
    $scope.finalizarServico = function (servico) {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Finalizar Serviço',
            template: 'Finalizar serviço agora?'
        });

        confirmPopup.then(function (res) {
            if (res) {
                $rootScope.abrirCarregando();
                SQLiteAPIatosServico.finalizarServico(servico).then(function (data) {
                    _trataServico2(data);
                    $rootScope.fecharCarregando();
                    $scope.closeModalFinalizarServico();
                }, function (data) {
                    $rootScope.geraLog(data, new Error());
                    $rootScope.fecharCarregando();
                    $scope.closeModalFinalizarServico();
                });
            }
        });
    };
    $scope.editarProduto = function (produtoEditar, formulario) {
        if(formulario.$invalid){
            $rootScope.showAlert('Dados inválidos, verifique os valores informados');
        }else{
            var mensagem = 'Deseja realmente alterar o produto?';
            if (!('id' in produtoEditar)){
                mensagem = 'Deseja Adicionar o Produto?';
            }
            var confirmPopup = $ionicPopup.confirm({
                title: '',
                template: mensagem
            });
            confirmPopup.then(function (res) {
                if (res) {
                    $rootScope.abrirCarregando();
                    if (!('id' in produtoEditar)){
                        SQLiteAPIatdcOcorrenciaProduto.adicionaAtdcOcorrenciaProduto(produtoEditar).then(function (data) {
                            if(produtoEditar.AtividadeTipo){
                                var atividade = {
                                    'atos' : $scope.atendimento.atos,
                                    'atosAtividadeTipo' : angular.copy($scope.opcoesAtividade[produtoEditar.AtividadeTipo]),
                                    'atdcOcorrencia' : data.atdcOcorrencia,
                                    'atdcOcorrenciaProduto' : data,
                                    'observacao' : produtoEditar.observacaoAtividade
                                };
                                SQLiteAPIatosAtividade.adicionaAtividade(atividade).then(function (data2) {
                                    _trataOcorrenciaProduto(data);
                                    $rootScope.fecharCarregando();
                                    $scope.closeModalEditarProduto();
                                    _getAtendimentoID2();
        //                            _trataAtividade2(data2); 
                                }, function (data) {
                                    $rootScope.geraLog(data, new Error());
                                    $rootScope.fecharCarregando();
                                    $scope.closeModalEditarProduto();
                                });
                            }
                            if(produtoEditar.servicoSelecionado){
                                var servicoSelecionado = JSON.parse(produtoEditar.servicoSelecionado);
                                var servico = {
                                    'atos' : $scope.atendimento.atos,
                                    'codigo' : servicoSelecionado.servicoCodigo,
                                    'descricao' : servicoSelecionado.servicoDescricao,
                                    'valor' : servicoSelecionado.valorServico,
                                    'atdcOcorrencia' : data.atdcOcorrencia,
                                    'atdcOcorrenciaProduto' : data,
                                    'observacao' : produtoEditar.observacaoServico
                                };
                                SQLiteAPIatosServico.adicionaServico(servico).then(function (data2) {
                                    _trataOcorrenciaProduto(data);
                                    $rootScope.fecharCarregando();
                                    $scope.closeModalEditarProduto();
                                    _getAtendimentoID2();
        //                            _trataServico2(data2); 
                                }, function (data) {
                                    $rootScope.geraLog(data, new Error());
                                    $rootScope.fecharCarregando();
                                    $scope.closeModalEditarProduto();
                                });
                            }else{
                                _trataOcorrenciaProduto(data);
                                $rootScope.fecharCarregando();
                                $scope.closeModalEditarProduto();
                                _getAtendimentoID2();
                            }
                        }, function (data) {
                            $rootScope.geraLog(data, new Error());
                            $rootScope.fecharCarregando();
                            $scope.closeModalEditarProduto();
                        });
                    }else{
                        SQLiteAPIatdcOcorrenciaProduto.atualizaAtdcOcorrenciaProduto(produtoEditar.id,produtoEditar).then(function (data) {
    //                        console.log(data);
                            _trataOcorrenciaProduto(data);
                            $rootScope.fecharCarregando();
                            _getAtendimentoID2();
                            $scope.closeModalEditarProduto();
                        }, function (data) {
                            $rootScope.geraLog(data, new Error());
                            $rootScope.fecharCarregando();
                            $scope.closeModalEditarProduto();
                        });
                    }
                }
            });
        }
    };
    $scope.editarAtividade = function (atividadeEditar) {
        var mensagem = 'Deseja realmente alterar a atividade?';
        if (!('id' in atividadeEditar)){
            mensagem = 'Deseja Adicionar a atividade?';
        }
        var confirmPopup = $ionicPopup.confirm({
            title: '',
            template: mensagem
        });

        confirmPopup.then(function (res) {
            if (res) {
//                $rootScope.abrirCarregando();
                if (!('id' in atividadeEditar)){
                    SQLiteAPIatosAtividade.adicionaAtividade(atividadeEditar).then(function (data) {
                        _trataAtividade2(data); 
                        $rootScope.fecharCarregando();
                        $scope.closeModalEditarAtividade();
                    }, function (data) {
                        $rootScope.geraLog(data, new Error());
                        $rootScope.fecharCarregando();
                        $scope.closeModalEditarAtividade();
                    });
                }else{
                    SQLiteAPIatosAtividade.atualizaAtividade(atividadeEditar.id,atividadeEditar).then(function (data) {
                        _trataAtividade2(data); 
                        $rootScope.fecharCarregando();
                        $scope.closeModalEditarAtividade();
                    }, function (data) {
                        $rootScope.geraLog(data, new Error());
                        $rootScope.fecharCarregando();
                        $scope.closeModalEditarAtividade();
                    });
                }
            }
        });
    };
    var _trataAtividade = function (data) {
//        console.log($scope.atendimento._embedded.atos);
        var temp = {
            id: data.id,
            atosStatus: data._embedded.atosStatus,
            atosAtividadeTipo: data._embedded.atosAtividadeTipo,
            descricao: data.descricao,
            dataInclusao: data.dataInclusao,
            dataInicio: data.dataInicio,
            dataFim: data.dataFim,
            observacao: data.observacao,
            atdcOcorrenciaProduto: data._embedded.atdcOcorrenciaProduto,
            laudoTecnico: data.laudoTecnico
        };
        temp.atdcOcorrenciaProduto.descricao_erp = temp.atdcOcorrenciaProduto.descricaoErp;
//        console.log(temp.atdcOcorrenciaProduto);
        $scope.atendimento._embedded.atos.atosAtividades[data.id] = temp;
//        console.log($scope.atendimento._embedded.atos);
    };
    var _trataAtividade2 = function (data) {
        var temp = data;
//        console.log(temp.atdcOcorrenciaProduto);
        if(temp.atdcOcorrenciaProduto != undefined || temp.atdcOcorrenciaProduto != null){
            temp.atdcOcorrenciaProduto.descricao_erp = temp.atdcOcorrenciaProduto.descricaoErp;
        }
        $scope.atosAtividades[data.id] = temp;
    };
    
    $scope.editarServico = function (servicoEditar) {
         if(servicoEditar.codigo === null || servicoEditar.descricao === null){
            $rootScope.showAlert("Favor selecione o serviço!");
        }else{
            var mensagem = 'Deseja realmente alterar o serviço?';
            if (!('id' in servicoEditar)){
                mensagem = 'Deseja Adicionar o serviço?';
            }
            var confirmPopup = $ionicPopup.confirm({
                title: '',
                template: mensagem
            });

            confirmPopup.then(function (res) {
                if (res) {
    //                $rootScope.abrirCarregando();
                    if (!('id' in servicoEditar)){
                        SQLiteAPIatosServico.adicionaServico(servicoEditar).then(function (data) {
                            _trataServico2(data); 
                            $rootScope.fecharCarregando();
                            $scope.closeModalEditarServico();
                        }, function (data) {
                            $rootScope.geraLog(data, new Error());
                            $rootScope.fecharCarregando();
                            $scope.closeModalEditarServico();
                        });
                    }else{
                        SQLiteAPIatosServico.atualizaServico(servicoEditar.id,servicoEditar).then(function (data) {
                            _trataServico2(data); 
                            $rootScope.fecharCarregando();
                            $scope.closeModalEditarServico();
                        }, function (data) {
                            $rootScope.geraLog(data, new Error());
                            $rootScope.fecharCarregando();
                            $scope.closeModalEditarServico();
                        });
                    }
                }
            });
        }
    };
    var _trataServico2 = function (data) {
        var temp = data;
//        console.log(temp.atdcOcorrenciaProduto);
        if(temp.atdcOcorrenciaProduto != undefined || temp.atdcOcorrenciaProduto != null){
            temp.atdcOcorrenciaProduto.descricao_erp = temp.atdcOcorrenciaProduto.descricaoErp;
        }
        $scope.atosServicos[data.id] = temp;
    };

    var _trataOcorrenciaProduto = function (ocorrenciaProduto) {
        $scope.ocorrenciaProdutos[ocorrenciaProduto.id] = ocorrenciaProduto;
        $scope.produtoEditar = [];
    };

    $ionicModal.fromTemplateUrl('templates/modal-atendimento-checkout.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalCheckout = modal;

    });
    $scope.openModalCheckout = function () {
        $scope.closeOpcoesAtendimento();
        $scope.checkout = {id: $scope.id_atendimento, finalizarAtividades: false, finalizarServicos: false, naoProcede: true};
        $scope.modalCheckout.show();
        _carregaOpcoesAvaliacaoRootScope();
    };
    $scope.closeModalCheckout = function () {
        $scope.modalCheckout.hide();
    };

    var _carregaOpcoesAvaliacaoRootScope = function(){
        $rootScope.opcoesAvaliacao = {};
        var opcoes = JSON.parse($window.localStorage['opcoesAvaliacao']);
//        console.log('opcoes.length');
//        console.log(opcoes.length);
        angular.forEach(opcoes, function (value, key) {
            var indice = $rootScope.geraAleatorio(1, 10, $rootScope.opcoesAvaliacao);
            $rootScope.opcoesAvaliacao[indice] = value;
        });
//        console.log($rootScope.opcoesAvaliacao);
    };
    
    $ionicModal.fromTemplateUrl('templates/modal-atendimento-reagendar.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalReagendar = modal;

    });
    $scope.openModalReagendar = function (id_atendimento) {
        $scope.reagendamento = {id: id_atendimento, atosStatus: 5};
        $scope.modalReagendar.show();
    };
    $scope.closeModalReagendar = function () {
        $scope.modalReagendar.hide();
        $scope.reagendamento = null;
    };


    $ionicModal.fromTemplateUrl('templates/modal-atendimento-atividadefinalizar.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalFinalizarAtividade = modal;
    });
    $scope.openModalFinalizarAtividade = function (atividade) {
        $scope.atividadeFinalizar = atividade;
        $scope.modalFinalizarAtividade.show();
    };
    $scope.closeModalFinalizarAtividade = function () {
        $scope.modalFinalizarAtividade.hide();
        $scope.reagendamento = null;
    };

    $ionicModal.fromTemplateUrl('templates/modal-atendimento-servicofinalizar.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalFinalizarServico = modal;
    });
    $scope.openModalFinalizarServico = function (servico) {
        $scope.servicoFinalizar = servico;
        $scope.modalFinalizarServico.show();
    };
    $scope.closeModalFinalizarServico = function () {
        $scope.modalFinalizarServico.hide();
        $scope.reagendamento = null;
    };

    $ionicModal.fromTemplateUrl('templates/modal-atendimento-editarproduto.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalEditarProduto = modal;
    });
    
    $scope.openModalEditarProduto = function (produtoEditar) {
        var dados = { 'op' : 0 };
        $rootScope.abrirCarregando();

        $scope.opcoesTipo = {};
        $scope.opcoesAtividade = {};
        $scope.opcoesServico = {};
        $scope.opcoesServicoLinha = {};
        $scope.opcoesServicoTipo = {};
        $scope.opcoesProduto = {};
        $scope.opcoesProdutoTipo = {};
        $scope.opcoesGrupoDefeito = {};
        $scope.opcoesDefeito = {};
        $scope.opcoesDefeitoProcedimento = {};
//        console.log(produtoEditar);
        SQLiteAPIProduto.getProdutoTipos(dados).then(function (data) {
            $scope.opcoesTipo = data;
            return SQLiteOrdemServico.getAtosAtividadeTipo();
        }).then(function (data) {
            $scope.opcoesAtividade = data;
            return SQLiteAPIServico.getServicoTipos();
        }).then(function (data) {
            $scope.opcoesServicoTipo = data;
            return SQLiteAPIProdutoTipo.getTiposProduto();
        }).then(function (data) {
            $scope.opcoesProdutoTipo = data;
            if(produtoEditar !== undefined && !(produtoEditar.descricao in $scope.opcoesProdutoTipo)){
                $scope.opcoesProdutoTipo[produtoEditar.descricao] = produtoEditar.descricao;
            }
            return SQLiteAPIGrupo.getGruposAtivos();
        }).then(function (data) {
            $scope.opcoesGrupoDefeito = data; 
            if (produtoEditar === undefined) {
                $scope.closeOpcoesAtendimento();
                $scope.produtoAtividadeSelecionado = null;
                if($scope.produtoEditar.atdcOcorrencia == $scope.atdcOcorrencia.id){
                    $scope.produtoEditar = {
                        'atdcOcorrencia': $scope.produtoEditar.atdcOcorrencia,
                        'notaFiscal': $scope.produtoEditar.notaFiscal,
                        'dataCompra': $scope.produtoEditar.dataCompra,
                        'loja': $scope.produtoEditar.loja,
                    };
                    
                }else{
                    var produto = $scope.ocorrenciaProdutos[Object.keys($scope.ocorrenciaProdutos)[0]];
//                    console.log(produto);
                    $scope.produtoEditar = {
                        'atdcOcorrencia': $scope.atdcOcorrencia.id,
                        'notaFiscal': produto !== undefined ? produto.notaFiscal : '',
                        'dataCompra': produto !== undefined ? new Date(produto.dataCompra) : new Date(),
                        'loja': produto !== undefined ? produto.loja : ''
                    };
                }
            } else {
                $scope.produtoEditar = angular.copy(produtoEditar);
//                console.log($scope.produtoEditar.dataCompra);
//                $scope.produtoEditar.dataCompra = $rootScope.converteDataObjeto(produtoEditar.dataCompra);
                
                $scope.produtoEditar.dataCompra = new Date(produtoEditar.dataCompra);
                
//                console.log($scope.produtoEditar.dataCompra);

                var grupoDefeito = angular.copy($scope.produtoEditar.atdcGrupoDefeito);
                var grupoDefeitoProcedimento = angular.copy($scope.produtoEditar.atdcGrupoDefeitoProcedimento);
                if (grupoDefeito && 'atdcGrupo' in grupoDefeito) {
                    $scope.produtoEditar.grupoDefeitoSelecionado = grupoDefeito.atdcGrupo;
                }
                if (grupoDefeito && 'id' in grupoDefeito) {
                    $scope.produtoEditar.defeitoSelecionado = grupoDefeito.id;
                }
                if (grupoDefeitoProcedimento && 'id' in grupoDefeitoProcedimento) {
                    $scope.produtoEditar.defeitoProcedimentoSelecionado = grupoDefeitoProcedimento.id;
                }
                
                $scope.buscaLinha(produtoEditar).then(function (opcoesLinha) {
                    $scope.opcoesLinha = opcoesLinha;
                    return $scope.buscaFamilia(produtoEditar);
                }).then(function (opcoesFamilia) {
                    $scope.opcoesFamilia = opcoesFamilia;
                    return $scope.buscaProduto(produtoEditar);
                }).then(function (opcoesProduto) {
                    $scope.opcoesProduto = opcoesProduto;
                    return $scope.buscaDefeitos(produtoEditar.atdcGrupoDefeito.atdcGrupo);
                }).then(function (opcoesDefeito) {
                    $scope.opcoesDefeito = opcoesDefeito;
                    return $scope.buscaDefeitoProcedimentos(produtoEditar.atdcGrupoDefeito.id);
                }).then(function (opcoesDefeitoProcedimento) {
                    $scope.opcoesDefeitoProcedimento = opcoesDefeitoProcedimento;
                }, function (err) {
                    $rootScope.geraLog(err, new Error());
                });

            }
//                $scope.opcoesGrupoDefeito = data._embedded.atdc_grupo;
            $scope.modalEditarProduto.show();
            $rootScope.fecharCarregando();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $rootScope.fecharCarregando();
        });

    };
    
    $scope.closeModalEditarProduto = function () {
        $scope.modalEditarProduto.hide();
        $scope.reagendamento = null;
    };

    $ionicModal.fromTemplateUrl('templates/modal-atendimento-editaratividade.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.atividadeTipoSelecionado = null;
        $scope.produtoAtividadeSelecionado = null;
        $scope.modalEditarAtividade = modal;
    });
    
    $scope.openModalEditarAtividade = function (atividadeEditar) {
        $scope.opcoesTipo = [];
        SQLiteOrdemServico.getAtosAtividadeTipo().then(function (data) {
            $scope.closeOpcoesAtendimento();
            $scope.opcoesTipo = data;
            if (atividadeEditar === undefined) {
                $scope.produtoAtividadeSelecionado = null;
                $scope.atividadeEditar = {'atdcOcorrencia': $scope.atdcOcorrencia.id, 'atos': $scope.atendimento.atos}; 
            } else {
                $scope.atividadeEditar = angular.copy(atividadeEditar);
                $scope.atividadeTipoSelecionado = $scope.atividadeEditar.atosAtividadeTipo.id;
            }
            $scope.modalEditarAtividade.show();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    
    $scope.closeModalEditarAtividade = function () {
//        delete $scope.atividadeTipoSelecionado;
//        console.log($scope.atividadeTipoSelecionado);
//        delete $scope.atividadeEditar;
//        console.log($scope.atividadeEditar);
//        console.log($scope.produtoAtividadeSelecionado);
//        console.log($scope.atividadeTipoSelecionado);
        $scope.modalEditarAtividade.hide();
    };

    $ionicModal.fromTemplateUrl('templates/modal-atendimento-editarservico.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.servicoEditar.servicoSelecionado = null; 
        $scope.produtoServicoSelecionado = null;
        $scope.modalEditarServico = modal;
    });
    
    $scope.openModalEditarServico = function (servicoEditar) {
        $scope.opcoesServicoTipo = {};
        $scope.opcoesServico = {};
        SQLiteAPIServico.getServicoTipos().then(function (data) {
            $scope.opcoesServicoTipo = data;
            if (servicoEditar === undefined) {
                $scope.closeOpcoesAtendimento();
                $scope.produtoServicoSelecionado = null;
                $scope.servicoEditar = {'atdcOcorrencia': $scope.atdcOcorrencia.id, 'atos': $scope.atendimento.atos}; 
                $scope.modalEditarServico.show();
            } else {
                SQLiteAPIAbstract.findCampo('atdb_servico', 'servicoCodigo', servicoEditar.codigo).then(function (atdb_servico) {
                    if(atdb_servico){
                        servicoEditar.servicoTipo = atdb_servico.linhaTipo;
                        servicoEditar.servicoLinha = atdb_servico.linhaDescricao;
                        servicoEditar.servicoCodigo = atdb_servico.servicoCodigo;
                        servicoEditar.servicoSelecionado = atdb_servico;
                        return $scope.buscaLinhaServico(servicoEditar);
                    }
                    return {};
                }).then(function (opcoesServicoLinha) {
                    $scope.opcoesServicoLinha = opcoesServicoLinha;
                    return $scope.buscaServico(servicoEditar);
                }).then(function (opcoesServico) {
                    $scope.servicoEditar.servicoSelecionado = null;
                    $scope.servicoEditar.codigo = null;
                    $scope.servicoEditar.descricao = null;
                    
                    $scope.servicoEditar = angular.copy(servicoEditar);
                    
                    $scope.opcoesServico = opcoesServico;
                    
                }, function (err) {
                    $rootScope.geraLog(err, new Error());
                });
            }
            $scope.modalEditarServico.show();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    
    $scope.closeModalEditarServico = function () {
        $scope.modalEditarServico.hide();
    };
    $ionicModal.fromTemplateUrl('templates/modal-atendimento-interacao.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalInteracao = modal;
    });
    
    $scope.openModalInteracao = function (ocorrenciaInteracao) {
        
        $scope.ocorrenciaInteracao = {
            'atdcOcorrencia'    : $scope.atendimento.atdcOcorrencia,
            'itadauUsuario'     : $rootScope.usuarioLogado.id,
            'nomeUsuario'       : $rootScope.usuarioLogado.nome,
            'descricao'         : ocorrenciaInteracao !== undefined ? ocorrenciaInteracao.descricao : null
        };
        $scope.modalInteracao.show();
        $scope.closeOpcoesAtendimento();
    };
    
    $scope.closeModalInteracao = function () {
        $scope.modalInteracao.hide();
    };


    $scope.addInteracao = function (ocorrenciaInteracao) {
        var mensagem = 'Deseja adicionar a interação?';
        var confirmPopup = $ionicPopup.confirm({
            title: '',
            template: mensagem
        });

        confirmPopup.then(function (res) {
            if (res) {
                SQLiteAPIatdcOcorrenciaInteracao.adicionaInteracao(ocorrenciaInteracao).then(function (data) {
                    _trataInteracao(data); 
                    $rootScope.fecharCarregando();
                    $scope.closeModalInteracao();
                }, function (data) {
                    $rootScope.geraLog(data, new Error());
                    $rootScope.fecharCarregando();
                    $scope.closeModalInteracao();
                });
            }
        });
    };
    
    var _trataInteracao = function (data) {
        var temp = data;
//        console.log($scope.atdcOcorrenciaInteracoes);
        $scope.atdcOcorrenciaInteracoes.push(temp);
    };


    $scope.selecionaAtividadeTipo = function (atividadeTipoSelecionado) {
//        console.log($scope.opcoesTipo[atividadeTipoSelecionado]);
        $scope.atividadeEditar.atosAtividadeTipo = angular.copy($scope.opcoesTipo[atividadeTipoSelecionado]);
    };

    $scope.selecionaProdutoAtividade = function (produtoAtividadeSelecionado) {
        $scope.atividadeEditar.atdcOcorrenciaProduto = $scope.ocorrenciaProdutos[produtoAtividadeSelecionado];
    };

    $scope.selecionaProdutoServico = function (produtoServicoSelecionado) {
        $scope.servicoEditar.atdcOcorrenciaProduto = $scope.ocorrenciaProdutos[produtoServicoSelecionado];
    };
//    opcoesServicoTipo

    $scope.selecionaServicoTipo = function (servicoEditar) {
//        console.log(servicoEditar);
        $scope.buscaLinhaServico(servicoEditar).then(function (data) {
            $scope.opcoesServicoLinha = data;
            $scope.opcoesServico = {};
            $scope.servicoEditar.servicoLinha = null;
            $scope.servicoEditar.servicoSelecionado = null;
            $scope.servicoEditar.codigo = null;
            $scope.servicoEditar.descricao = null;
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    $scope.selecionaServicoLinha = function (servicoEditar) {
//        console.log('mudou selecionaLinhaServico');
//        console.log(servicoEditar);
        $scope.buscaServico(servicoEditar).then(function (data) {
            $scope.opcoesServico = data;
            $scope.servicoEditar.servicoSelecionado = null;
            $scope.servicoEditar.codigo = null;
            $scope.servicoEditar.descricao = null;
//            console.log(data);
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    
    $scope.selecionaServico = function (servicoSelecionado) {
//        console.log($scope.servicoEditar.servicoSelecionado);
//        console.log(servicoSelecionado);
//        console.log('mudou Serviço');
//        console.log(servicoSelecionado);
//        $scope.servicoEditar.servicoSelecionado = JSON.parse(servicoSelecionado);
        var p = JSON.parse(servicoSelecionado);
        $scope.servicoEditar.codigo = p.servicoCodigo;
        $scope.servicoEditar.descricao = p.servicoDescricao;
        $scope.servicoEditar.valor = p.valorServico;
    };

    $scope.selecionaServicoTipoProduto = function (produtoEditar) {
//        console.log(produtoEditar);
        $scope.buscaLinhaServico(produtoEditar).then(function (data) {
            $scope.opcoesServicoLinha = data;
            $scope.opcoesServico = {};
            $scope.produtoEditar.servicoLinha = null;
            $scope.produtoEditar.servicoSelecionado = null;
//            $scope.produtoEditar.codigoServico = null;
//            $scope.produtoEditar.descricaoServico = null;
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    $scope.selecionaServicoLinhaProduto = function (produtoEditar) {
//        console.log('mudou selecionaLinhaServico');
//        console.log(produtoEditar);
        $scope.buscaServico(produtoEditar).then(function (data) {
            $scope.opcoesServico = data;
            $scope.produtoEditar.servicoSelecionado = null;
//            $scope.produtoEditar.codigoServico = null;
//            $scope.produtoEditar.descricaoServico = null;
//            console.log(data);
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    
    $scope.selecionaServicoProduto = function (servicoSelecionado) {
//        console.log($scope.produtoEditar.servicoSelecionado);
//        console.log(servicoSelecionado);
//        console.log('mudou Serviço');
//        console.log(servicoSelecionado);
//        $scope.produtoEditar.servicoSelecionado = JSON.parse(servicoSelecionado);
//        var p = JSON.parse(servicoSelecionado);
//        $scope.produtoEditar.codigoServico = p.servicoCodigo;
//        $scope.produtoEditar.descricaoServico = p.servicoDescricao;
//        $scope.produtoEditar.valor = p.valorServico;
    };

    $scope.buscaLinhaServico = function (servicoEditar) {
        var defered = $q.defer();
        var promise = defered.promise;
        var opcoesServicoLinha = {};
        
        if(servicoEditar.servicoTipo){
//        console.log(servicoEditar.servicoTipo);
            SQLiteAPIServico.getServicoLinhas(servicoEditar.servicoTipo).then(function (data) {
                opcoesServicoLinha = data;
                defered.resolve(opcoesServicoLinha);
            }, function (err) {
                defered.reject(err);
            });
        }else{
            defered.resolve(opcoesServicoLinha);
        }
        return promise;
    };
    
    $scope.buscaServico = function (servicoEditar) {
        var defered = $q.defer();
        var promise = defered.promise;
        var opcoesServico = {};
        
        if(servicoEditar.servicoLinha){
            var dados = {
                'p1': servicoEditar.servicoTipo,
                'p2': servicoEditar.servicoLinha,
                'op': 3
            };
            SQLiteAPIServico.getServicos(dados).then(function (data) {
//                console.log('getServicos');
//                console.log(data);
                opcoesServico = data;
                defered.resolve(opcoesServico);
            }, function (err) {
                defered.reject(err);
            });
        }else{
            defered.resolve(opcoesServico);
        }
        return promise;
    };
    
    $scope.buscaLinha = function (produtoEditar) {
        var defered = $q.defer();
        var promise = defered.promise;
        var opcoesLinha = {};
        
        if(produtoEditar.tipo){
            SQLiteAPIProduto.getProdutoLinhas(produtoEditar.tipo).then(function (data) {
                opcoesLinha = data;
                defered.resolve(opcoesLinha);
            }, function (err) {
                defered.reject(err);
            });
        }else{
            defered.resolve(opcoesLinha);
        }
        return promise;
    };
    $scope.buscaFamilia = function (produtoEditar) {
        var defered = $q.defer();
        var promise = defered.promise;
        var opcoesFamilia = {};
        
        if(produtoEditar.linha){
            SQLiteAPIProduto.getProdutoFamilias(produtoEditar.tipo, produtoEditar.linha).then(function (data) {
                opcoesFamilia = data;
                defered.resolve(opcoesFamilia);
            }, function (err) {
                defered.reject(err);
            });
        }else{
            defered.resolve(opcoesFamilia);
        }
        return promise;
    };
    $scope.buscaProduto = function (produtoEditar) {
        var defered = $q.defer();
        var promise = defered.promise;
        var opcoesProduto = {};
        
        if(produtoEditar.familia){
            var dados = {
                'p1': produtoEditar.tipo,
                'p2': produtoEditar.linha,
                'p3': produtoEditar.familia,
                'op': 3
            };
            SQLiteAPIProduto.getProdutos(dados).then(function (data) {
                opcoesProduto = data;
                defered.resolve(opcoesProduto);
            }, function (err) {
                defered.reject(err);
            });
        }else{
            defered.resolve(opcoesProduto);
        }
        return promise;
    };
    
    $scope.selecionaProduto = function (produtoSelecionado) {
//        console.log($scope.produtoEditar.produtoSelecionado);
//        console.log(produtoSelecionado);
//        console.log('mudou');
//        $scope.produtoEditar.produtoSelecionado = JSON.parse(produtoSelecionado);
        var p = JSON.parse(produtoSelecionado);
        $scope.produtoEditar.codigo = p.produtoCodigo;
        $scope.produtoEditar.descricaoErp = p.produtoDescricao;
    };
    $scope.buscaDefeitos = function (grupoDefeitoSelecionado) {
        var defered = $q.defer();
        var promise = defered.promise;
        SQLiteOrdemServico.getDefeitos(grupoDefeitoSelecionado).then(function (data) {
            defered.resolve(data);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    };
    $scope.buscaDefeitoProcedimentos = function (defeito) {
        var defered = $q.defer();
        var promise = defered.promise;
        SQLiteOrdemServico.getDefeitoProcedimentos(defeito).then(function (data) {
            defered.resolve(data);
        }, function (err) {
            defered.reject(err);
        });
        return promise;
    };
    
    $scope.selecionaDefeito = function (defeitoSelecionado) {
        if(defeitoSelecionado === undefined){
            $scope.produtoEditar.atdcGrupoDefeitoProcedimento = {};
            $scope.produtoEditar.defeitoProcedimentoSelecionado = null;
        }else{
            var defeito = JSON.parse(defeitoSelecionado);
            $scope.produtoEditar.atdcGrupoDefeito = defeito;
            $scope.buscaDefeitoProcedimentos(defeito.id).then(function (data) {
                $scope.opcoesDefeitoProcedimento = data;
                $scope.produtoEditar.atdcGrupoDefeitoProcedimento = {};
                $scope.produtoEditar.defeitoProcedimentoSelecionado = null;
            }, function (err) {
                $rootScope.geraLog(err, new Error());
            });
        }
    };
    
    $scope.selecionaTipoProduto = function (produtoEditar) {
        $scope.buscaLinha(produtoEditar).then(function (data) {
            $scope.opcoesLinha = data;
            $scope.opcoesFamilia = {};
            $scope.opcoesProduto = {};
            $scope.produtoEditar.linha = null;
            $scope.produtoEditar.familia = null;
            $scope.produtoEditar.produtoSelecionado = null;
            $scope.produtoEditar.codigo = null;
            $scope.produtoEditar.descricaoErp = null;
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    $scope.selecionaLinhaProduto = function (produtoEditar) {
//        console.log('mudou selecionaLinhaProduto');
        $scope.buscaFamilia(produtoEditar).then(function (data) {
            $scope.opcoesFamilia = data;
            $scope.produtoEditar.familia = null;
            $scope.produtoEditar.produtoSelecionado = null;
            $scope.opcoesProduto = {};
            $scope.produtoEditar.codigo = null;
            $scope.produtoEditar.descricaoErp = null;
//            console.log(data);
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    $scope.selecionaFamiliaProduto = function (produtoEditar) {
        $scope.buscaProduto(produtoEditar).then(function (data) {
            $scope.opcoesProduto = data;
            $scope.produtoEditar.produtoSelecionado = null;
            $scope.produtoEditar.codigo = null;
            $scope.produtoEditar.descricaoErp = null;
//            console.log(data);
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    $scope.selecionaGrupoDefeito = function (grupoDefeito) {
//        console.log('mudou selecionaGrupoDefeito');
        $scope.buscaDefeitos(grupoDefeito).then(function (data) {
//        console.log(grupoDefeito);
//        console.log(data);
            $scope.opcoesDefeito = grupoDefeito === undefined ? {} : data;
            $scope.opcoesDefeitoProcedimento = {};
            $scope.produtoEditar.atdcGrupoDefeitoProcedimento = {};
            $scope.produtoEditar.atdcGrupoDefeito = {};
            $scope.produtoEditar.defeitoSelecionado = null ;
            $scope.produtoEditar.defeitoProcedimentoSelecionado = null;
//            console.log(data);
        }, function (err) {
            $rootScope.geraLog(err, new Error());
        });
    };
    
    $scope.selecionaProdutoProcedimento = function (defeitoProcedimento) {
        $scope.produtoEditar.atdcGrupoDefeitoProcedimento = $scope.opcoesDefeitoProcedimento[defeitoProcedimento];
//        console.log($scope.produtoEditar);
    };
    $scope.retiraProduto = function (ocorrenciaProduto) {
        
        var confirmPopup = $ionicPopup.confirm({
            title: 'Excluir',
            template: 'Deseja realmente excluir o produto?'
        });

        confirmPopup.then(function (res) {
            if (res) {
                $rootScope.abrirCarregando();
                SQLiteAPIatdcOcorrenciaProduto.deleteProduto(ocorrenciaProduto).then(function (data) {
                    delete $scope.ocorrenciaProdutos[ocorrenciaProduto.id];
                    angular.forEach(data.atividades, function (value, key) {
                        delete $scope.atosAtividades[value.id];
                    });
                    angular.forEach(data.servicos, function (value, key) {
                        delete $scope.atosServicos[value.id];
                    });
                    $rootScope.fecharCarregando();
                }, function (data) {
                    $rootScope.fecharCarregando();
                    console.log(data);
                });
            }
        });
    };
    $scope.retiraAtividade = function (atividade) {
        
        var confirmPopup = $ionicPopup.confirm({
            title: 'Excluir',
            template: 'Deseja realmente excluir a atividade?'
        });

//        console.log(atividade);
        confirmPopup.then(function (res) {
            if (res) {
                $rootScope.abrirCarregando();
                SQLiteAPIAbstract.delete('atos_atividade', atividade.id).then(function (data) {
                    delete $scope.atosAtividades[atividade.id];
                    $rootScope.fecharCarregando();
                }, function (err) {
                    $rootScope.fecharCarregando();
                    $rootScope.geraLog(err, new Error());
                });
            }
        });
    };
    $scope.retiraServico = function (servico) {
        
        var confirmPopup = $ionicPopup.confirm({
            title: 'Excluir',
            template: 'Deseja realmente excluir o servico?'
        });

//        console.log(servico);
        confirmPopup.then(function (res) {
            if (res) {
                $rootScope.abrirCarregando();
                SQLiteAPIAbstract.delete('atos_servico', servico.id).then(function (data) {
                    delete $scope.atosServicos[servico.id];
                    $rootScope.fecharCarregando();
                }, function (err) {
                    $rootScope.fecharCarregando();
                    $rootScope.geraLog(err, new Error());
                });
            }
        });
    };
    var _baixaPeca = function (baixa) {
//        alert('teste');

        var timeNow = new Date();
//    console.log(timeNow);

        baixa.atos = $scope.atendimento._embedded.atos.id;
        baixa.data = $rootScope.converteObjetoDataPost(timeNow);
        baixa.atdpMovimentacaoTipo = '2';
        $rootScope.abrirCarregando();
//        requisicao.data = timeNow.toLocaleFormat('%Y-%m-%d %H:%M:%S');
        estoqueAPI.darBaixaPecaEstoque(baixa).success(function (data) {
            $rootScope.fecharCarregando();
//            console.log(data);
            $scope.modalBaixa.hide();
//            _getPecaEstoque(baixa.atdpEstoque);
//            alert(data);
        }).error(function (data) {
            $rootScope.fecharCarregando();
//            console.log(data);
        });
    };
    $ionicModal.fromTemplateUrl('templates/modal-baixapeca.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalBaixa = modal;

    });
    $scope.openModalBaixa = function () {
        $scope.closeOpcoesAtendimento();
        $scope.baixa = {origem: 'os'};
        if ($scope.estoque === undefined) {
            $rootScope.abrirCarregando();
            estoqueAPI.getEstoque().success(function (data) {
                $scope.estoque = data._embedded.atdp_estoque;
                $rootScope.fecharCarregando();
            }).error(function (data) {
                $rootScope.fecharCarregando();
                //                console.log(data);
            });
        }

        $scope.modalBaixa.show();
    };
    $scope.closeModalBaixa = function () {
        $scope.modalBaixa.hide();
    };
    $scope.baixaPeca = function (requisicao) {
        _baixaPeca(requisicao);
    };

    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modalCheckout !== undefined && $scope.modalCheckout.isShown()) {
            event.preventDefault();
            $scope.closeModalCheckout();
        }
        if ($scope.modalReagendar !== undefined && $scope.modalReagendar.isShown()) {
            event.preventDefault();
            $scope.closeModalReagendar();
        }
        if ($scope.modalFinalizarAtividade !== undefined && $scope.modalFinalizarAtividade.isShown()) {
            event.preventDefault();
            $scope.closeModalFinalizarAtividade();
        }
        if ($scope.modalFinalizarServico !== undefined && $scope.modalFinalizarServico.isShown()) {
            event.preventDefault();
            $scope.closeModalFinalizarServico();
        }
        if ($scope.modalEditarProduto !== undefined && $scope.modalEditarProduto.isShown()) {
            event.preventDefault();
            $scope.closeModalEditarProduto();
        }
        if ($scope.modalEditarAtividade !== undefined && $scope.modalEditarAtividade.isShown()) {
            event.preventDefault();
            $scope.closeModalEditarAtividade();
        }
        if ($scope.modalEditarServico !== undefined && $scope.modalEditarServico.isShown()) {
            event.preventDefault();
            $scope.closeModalEditarServico();
        }
        if ($scope.modalInteracao !== undefined && $scope.modalInteracao.isShown()) {
            event.preventDefault();
            $scope.closeModalInteracao();
        }
        if ($scope.modalBaixa !== undefined && $scope.modalBaixa.isShown()) {
            event.preventDefault();
            $scope.closeModalBaixa();
        }
    });


    $ionicModal.fromTemplateUrl('templates/modal-addimagem.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalAddImagem = modal;

    });
    $scope.openModalAddImagem = function () {
        $scope.closeOpcoesAtendimento();
        $scope.checkout = {id: $scope.id_atendimento};
        $scope.atosImagem.imagem = undefined;
        $scope.modalAddImagem.show();
    };
    $scope.closeModalAddImagem = function () {
        $scope.modalAddImagem.hide();
        _excluiImagemTemp();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modalAddImagem && $scope.modalAddImagem.isShown()) {
            event.preventDefault();
            $scope.closeModalAddImagem();
        }
    });
    
    _excluiImagemTemp = function (){
//        console.log('_excluiImagemTemp');
        if($scope.atosImagem.imagem2 != undefined){
            $cordovaFile.checkFile($scope.atosImagem.imagem2.sourceDirectory,$scope.atosImagem.imagem2.sourceFileName).then(function (success) {
//                console.log($scope.atosImagem.imagem2.sourceDirectory + $scope.atosImagem.imagem2.sourceFileName);
                $cordovaFile.removeFile($scope.atosImagem.imagem2.sourceDirectory,$scope.atosImagem.imagem2.sourceFileName).then(function (success) {
                    $scope.atosImagem.imagem = undefined;
                }, function (error) {
                    $rootScope.geraLog(error, new Error());
                });
            }, function () {});
        }
    };

    $scope.takePicture = function (origem) {
//        console.log('takePicture');
        _excluiImagemTemp();
        var options = {
            quality: 75, 
//            destinationType: Camera.DestinationType.DATA_URL,
            destinationType: Camera.DestinationType.FILE_URI,
            sourceType: origem,
//            sourceType: Camera.PictureSourceType.CAMERA,
            allowEdit: false,
//            encodingType: Camera.EncodingType.JPEG,
//            mediaType: Camera.MediaType.PICTURE,
//            targetWidth: 300,
//            targetHeight: 300,
            popoverOptions: CameraPopoverOptions,
            saveToPhotoAlbum: true
        };

        $cordovaCamera.getPicture(options).then(function (imageData) {
              

            var sourceDirectory = imageData.substring(0, imageData.lastIndexOf('/') + 1);
            var sourceFileName = imageData.substring(imageData.lastIndexOf('/') + 1, imageData.length);

            if(origem === 0){
                
                window.FilePath.resolveNativePath(imageData, function (result) {
                    
                    sourceDirectory = result.substring(0, result.lastIndexOf('/') + 1);
                    sourceFileName = result.substring(result.lastIndexOf('/') + 1, result.length);
                    
                    var sourceDirectoryTemp = cordova.file.externalCacheDirectory;
                    var sourceFileNameTemp = "Temp_"+sourceFileName;

//                    console.log("Copying from : " + sourceDirectory + sourceFileName);
//                    console.log("Copying to : " + sourceDirectoryTemp + sourceFileNameTemp);
//                    console.log('Camera.PictureSourceType.PHOTOLIBRARY');
//                    console.log(Camera.PictureSourceType.PHOTOLIBRARY);

                    $cordovaFile.copyFile(sourceDirectory, sourceFileName, sourceDirectoryTemp, sourceFileNameTemp).then(function(success) {
        //                $scope.fileName = cordova.file.dataDirectory + sourceFileName;
                        _adicionaObjetoImagem(sourceDirectoryTemp, sourceFileNameTemp);
//                        console.log('success');
//                        console.log(success);
                    }, function(error) {
                        $rootScope.geraLog(error, new Error());
                    });
                }, function(error) {
                    $rootScope.geraLog(error, new Error());
                });
                
                
            }else{
                _adicionaObjetoImagem(sourceDirectory, sourceFileName);
            }

//            $scope.atosImagem.imagem = "data:image/jpeg;base64," + imageData;
        }, function (error) {
            $rootScope.geraLog(error, new Error());
//            console.error(error);
//            alert(err);
            // An error occured. Show a message to the user
        });
    };
    
    _adicionaObjetoImagem = function (sourceDirectory, sourceFileName) {
            
        if (!$scope.atosImagem) {
            $scope.atosImagem = new Object();
        }
        $scope.atosImagem.imagem2 = {
            sourceDirectory : sourceDirectory,
            sourceFileName  : sourceFileName
        };

        if(window.location.hostname === '192.168.1.20'){
            $cordovaFile.readAsDataURL(sourceDirectory, sourceFileName).then(function(base64) {
//                console.log('parte imagem');
//                console.log(base64.substring(0, 50));
                $scope.atosImagem.imagem = base64;
            }, function(error) {
                $rootScope.geraLog(error, new Error());

            });
        }else{
            $scope.atosImagem.imagem = sourceDirectory+sourceFileName;
//            $scope.atosImagem.imagem = imageData;
        }
    };
    
    $scope.getPhoto = function () {
        Camera.getPicture().then(function (imageURI) {
//            console.log(imageURI);
        }, function (err) {
            console.err(err);
        });
    };
    
//    $scope.addImagemOS = function (atosImagem) {
//
//        atosImagem.atos = $scope.atendimento._embedded.atos.id;
//        var timeNow = new Date();
//
//        var fd = new FormData();
//        fd.append('atos', atosImagem.atos);
//
//        fd.append('data', $rootScope.converteObjetoDataPost(timeNow));
//        fd.append('descricao', atosImagem.descricao);
//        fd.append('imagem', dataURItoBlob($scope.atosImagem.imagem), 'nome.jpg');
//
//        $rootScope.abrirCarregando();
////            console.log(atosImagem);
//        ordemServicoAPI.addImagemOS(fd).success(function (data) {
////            console.log(data);
//            $scope.closeModalAddImagem();
//            $rootScope.fecharCarregando();
//            if(!('atosImagens' in $scope.atendimento._embedded.atos.atosImagens)){
//                $scope.atendimento._embedded.atos.atosImagens = {};
//            }
//            $scope.atendimento._embedded.atos.atosImagens[data.id] = data;
//            $scope.atosImagem.descricao = null;
//            $scope.atosImagem.imagem = null;
//        }).error(function (data) {
//            $rootScope.fecharCarregando();
////            console.log(data);
//        });
//    };

    $scope.addImagemOS2 = function (atosImagem) {
        
        if(atosImagem.imagem !== undefined){
            var timeNow = new Date();

            var dados = {
                'atos' : $scope.atendimento.atos,
                'data' : $rootScope.converteObjetoDataPost(timeNow),
                'dataAlteracao' : $rootScope.converteObjetoDataPost(timeNow),
                'descricao' : atosImagem.descricao,
                'sincronizado' : 0,
                'imagem' : $scope.atosImagem.imagem2.sourceFileName,
//                'imagemData' : $scope.atosImagem.imagem
            };
            
            if(dados.atos === undefined || dados.atos < 1 || dados.atos === null){
                $rootScope.showAlert("Imagem perdeu a referencia do atendimento!");
                $rootScope.fecharCarregando();
                return;
            }
            if(dados.descricao.length < 1 || dados.descricao === null){
                $rootScope.showAlert("Favor informar uma descrição para a imagem!");
                $rootScope.fecharCarregando();
                return;
            }

            SQLiteAPIAbstract.insert('atos_imagem', dados).then(function (data) {
//                console.log("Copying from : " + $scope.atosImagem.imagem2.sourceDirectory + $scope.atosImagem.imagem2.sourceFileName);
//                console.log("Copying to : " + $rootScope.caminhoFotos + $scope.atosImagem.imagem2.sourceFileName);
                $cordovaFile.moveFile($scope.atosImagem.imagem2.sourceDirectory, $scope.atosImagem.imagem2.sourceFileName, $rootScope.caminhoFotos, dados.imagem).then(function(success) {
    //                $scope.fileName = cordova.file.dataDirectory + sourceFileName;
//                    console.log('success');
//                    console.log(success);

                    $cordovaFile.checkFile($rootScope.caminhoFotos, dados.imagem).then(function (success) {
                        if(!($scope.atosImagens)){
                            $scope.atosImagens = {};
                        }
                        data.imagemSrc = $scope.atosImagem.imagem;
                        $scope.atosImagens[data.id] = data;
                        $scope.atosImagem.descricao = null;
                        $scope.atosImagem.imagem = undefined;
                    }, function () {
                        SQLiteAPIAbstract.delete('atos_imagem', data.id).then(function (data) {}, function (err) {});
                        $rootScope.showAlert("Ocorreu um erro ao copiar a imagem, favor tentar novamente");
                    });
                    $scope.closeModalAddImagem();
                }, function(error) {
                    $rootScope.geraLog(error, new Error());
                });
                
            }, function (data) {
                $rootScope.fecharCarregando();
    //            console.log(data);
            });
        }else{
            $rootScope.showAlert("Tire uma nova foto ou selecione uma da galeria...");
        }
    };

    $scope.excluirImagemOS = function (atosImagem) {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Deseja realmente excluir a imagem?',
//            template: 'Deseja realmente excluir o produto?'
        });
        confirmPopup.then(function (res) {
            if (res) {
                SQLiteAPIAbstract.delete('atos_imagem', atosImagem).then(function (data) {
                    delete $scope.atosImagens[atosImagem];
                }, function (data) {
        //            $rootScope.fecharCarregando();
        //            console.log(data);
                });
            }
        });
    };

    $scope.showImages = function (index) {
        $scope.activeSlide = index;
        $scope.showModal('templates/image-popover.html');
    };

    $scope.showModal = function (templateUrl) {
        $ionicModal.fromTemplateUrl(templateUrl, {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modal = modal;
            $scope.modal.show();
        });
    };

    // Close the modal
    $scope.closeModal = function () {
        $scope.modal.hide();
        $scope.modal.remove();
    };    

    $rootScope.openModalAssinaturaCheckout = function () {
        
        
            $ionicModal.fromTemplateUrl('templates/modal-atendimento-assinatura.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function (modal) {
                if($rootScope.modalAssinatura !== undefined){
                    $rootScope.modalAssinatura.remove();
//                    console.log('removendo modalAssinatura');
                }
                $rootScope.modalAssinatura = modal;
                
//                console.log('modal');
//                console.log(modal); 
                
                screen.lockOrientation('landscape');
                $scope.closeOpcoesAtendimento();
                
                $rootScope.signaturePad = undefined;
                $rootScope.modalAssinatura.show();
                setTimeout(function() {
//                    console.log('#signatureCanvas');
//                    console.log(document.getElementById('signatureCanvas'));
                    $rootScope.getAlturaLargura();
//                    if($rootScope.signaturePad === undefined){
                        var canvas = document.getElementById('signatureCanvas');
                        $rootScope.signaturePad = new SignaturePad(canvas);
//                    }
                }, 1000);

            }); 
        
    };
    $rootScope.closeModalAssinaturaCheckout = function () {
        screen.unlockOrientation();
        if($rootScope.signaturePad !== undefined){
            $rootScope.signaturePad.clear();
            $rootScope.signaturePad = undefined;
        }
        $rootScope.modalAssinatura.hide();
        $rootScope.modalAssinatura.remove();
        $rootScope.atosAvaliacaoAtendimento = null;
        $scope.closeModalCheckout();
    };        
    $rootScope.limpaAssinatura = function() {
        $rootScope.signaturePad.clear();
//        $rootScope.atosAvaliacaoAtendimento = null;
    };
    $rootScope.selecionaAvaliacao = function(avaliacao) {
        $scope.atendimento.atosAvaliacao = avaliacao.id;
        $rootScope.atosAvaliacaoAtendimento = avaliacao.id;
    };
    $rootScope.finalizaCheckout = function() {
//        console.log($scope.atendimento);        
        if($rootScope.atosAvaliacaoAtendimento === null || $rootScope.atosAvaliacaoAtendimento === undefined){
            $rootScope.showAlert('Por favor avalie o atendimento!');
        }else
        if($rootScope.signaturePad.isEmpty()){
            $rootScope.showAlert('Assinatura invalida');
        }else{
            var sigImg = $rootScope.signaturePad.toDataURL();
            $scope.atendimento.assinaturaDigital = sigImg;
            $rootScope.closeModalAssinaturaCheckout();
            $rootScope.abrirCarregando(); 
    //        console.log($scope.checkout); 
    //        console.log("$scope.atendimento");
    //        console.log($scope.atendimento);
            SQLiteAPIAtendimento.realizarCheckout($scope.checkout, $scope.atendimento).then(function (data) {
    //                    console.log("$scope.atendimento");
    //                    console.log($scope.atendimento);
                _getAtendimentoID2();
                $rootScope.atosAvaliacaoAtendimento = null;
                $rootScope.fecharCarregando();
    //                    console.log(data);
                $scope.closeModalCheckout();
            }, function (data) {
                $rootScope.geraLog(data, new Error());
    //                    console.log(data);
                $rootScope.fecharCarregando();
            });
        }
    };
     
    $ionicPlatform.ready(function () {
        $scope.opcoesLinha = {};
        $scope.opcoesFamilia = {};
        $scope.opcoesProduto = {};
        if ($stateParams.id) {
            $scope.id_atendimento = $stateParams.id;
        } else {
            $scope.id_atendimento = null;
        }
        _getAtendimento();
    });
    $scope.doRefresh = function () {
        if ($stateParams.id) {
            $scope.id_atendimento = $stateParams.id;
        } else {
            $scope.id_atendimento = null;
        }
        _getAtendimento();
        $scope.$broadcast('scroll.refreshComplete');
    }; 
    
//                d.setDate(d.getDate() + 1);
    $scope.selecionaReagendamento = function () {
        var maxData = new Date($scope.atdcOcorrencia.data);
        maxData.setDate(maxData.getDate() + 30);
      ionic.Platform.ready(function(){
          var options = {
            date: $scope.checkout.dataReagendamento,
            mode: 'date', // or 'time'
            minDate: (new Date()).valueOf(),
            maxDate: maxData.valueOf(),
            allowOldDates: true,
            allowFutureDates: false,
            doneButtonLabel: 'DONE',
            doneButtonColor: '#F2F3F4',
            cancelButtonLabel: 'CANCEL',
            cancelButtonColor: '#000000',
            androidTheme: window.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_DARK
          };
          
          
            $cordovaDatePicker.show(options).then(function(date){
                $scope.checkout.dataReagendamento = date;
                $scope.checkout.dataReagendamentoFormatada = $rootScope.converteObjetoData($scope.checkout.dataReagendamento);
//                alert(date);
            });
      });
    };

});

function dataURItoBlob(dataURI) {
// convert base64/URLEncoded data component to raw binary data held in a string
    var byteString = atob(dataURI.split(',')[1]);
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]

    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++)
    {
        ia[i] = byteString.charCodeAt(i);
    }

    var bb = new Blob([ab], {"type": mimeString});
    return bb;
}