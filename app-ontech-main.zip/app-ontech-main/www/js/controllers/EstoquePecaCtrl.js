angular.module("starter").controller("EstoquePecaCtrl", function ($rootScope, $scope, $stateParams, estoqueAPI, $ionicModal, ordemServicoAPI, $filter) {
    var _getPecaEstoque = function () {
        $rootScope.abrirCarregando();
            estoqueAPI.getPecaEstoque($stateParams.id).success(function (data) {
                $scope.estoque = data;
                $scope.estoqueMovimentacao = data.atdpMovimentacoes;
                $scope.estoqueRequisicao = data.atdpRequisicoes; 
                _getOrdens();
                console.log($scope.estoqueMovimentacao);
                $rootScope.fecharCarregando();
//                $scope.requisicao = new Object();
//                var requisicao ;
//                $scope.requisicao = requisicao;
//                $scope.requisicao = new FormData();
//                $scope.requisicao.atdpEstoque = $scope.estoque.id;
            });
        };
        
    var _requisicaoPeca = function (requisicao) {
//        alert('teste');

    requisicao.atdpEstoque = $scope.estoque.id;
    var timeNow = new Date();
    requisicao.data = $rootScope.converteObjetoDataPost(timeNow);
//        requisicao.data = timeNow.toLocaleFormat('%Y-%m-%d %H:%M:%S');
        estoqueAPI.requisitarPecaEstoque(requisicao).then(function (data) {
//            console.log(data);
            $scope.modal.hide();
//            alert(data);
        });
    };
    var _baixaPeca = function (baixa) {
//        alert('teste');

    baixa.atdpEstoque = $scope.estoque.id;
    var timeNow = new Date();
//    console.log(timeNow);

    baixa.data = $rootScope.converteObjetoDataPost(timeNow);
    baixa.atdpMovimentacaoTipo = '2';
//        requisicao.data = timeNow.toLocaleFormat('%Y-%m-%d %H:%M:%S');
        estoqueAPI.darBaixaPecaEstoque(baixa).then(function (data) {
//            console.log(data);
            $scope.modalBaixa.hide();
            _getPecaEstoque(baixa.atdpEstoque);
//            alert(data);
        });
    };
    var _entradaPeca = function (entrada) {
//        alert('teste');

    entrada.atdpEstoque = $scope.estoque.id;
    var timeNow = new Date();
//    console.log(timeNow);

    entrada.data = $rootScope.converteObjetoDataPost(timeNow);
    entrada.atdpMovimentacaoTipo = '1';
//        requisicao.data = timeNow.toLocaleFormat('%Y-%m-%d %H:%M:%S');
        estoqueAPI.darEntradaPecaEstoque(entrada).then(function (data) {
            $scope.modalEntrada.hide();
            _getPecaEstoque(entrada.atdpEstoque);
            console.log(data);
            
            if(data._embedded !== undefined && data._embedded.atdpRequisicao !== undefined){
                var requisicao = data._embedded.atdpRequisicao;
                console.log('requisicao: '+requisicao);
                if(requisicao){
                    $scope.estoqueRequisicao[requisicao.id] = requisicao;
                }
            }
        });
    };

	$scope.doRefresh = function () {
		_getPecaEstoque($stateParams.id);
//                _getEstoqueMovimentacao($stateParams.id);
		$scope.$broadcast('scroll.refreshComplete');

	};

    _getPecaEstoque($stateParams.id);
        
        $ionicModal.fromTemplateUrl('templates/modal-requisitarpeca.html', {
            scope: $scope,
            animation: 'slide-in-up'
          }).then(function(modal) {
            $scope.modal = modal;
            
          });
        $scope.openModal = function(){
          $scope.modal.show();
        };
        $scope.closeModal = function(){
          $scope.modal.hide();
        };
        $scope.requisicaoPeca = function(requisicao){
          _requisicaoPeca(requisicao);
        };
        
        $ionicModal.fromTemplateUrl('templates/modal-baixapeca.html', {
            scope: $scope,
            animation: 'slide-in-up'
          }).then(function(modal) {
            $scope.modalBaixa = modal;
            
          });
        $scope.openModalBaixa = function(){
            $scope.baixa = {origem : 'estoque'};
          $scope.modalBaixa.show();
        };
        $scope.closeModalBaixa = function(){
          $scope.modalBaixa.hide();
        };
        $scope.baixaPeca = function(requisicao){ 
          _baixaPeca(requisicao);
        };
        $ionicModal.fromTemplateUrl('templates/modal-entradapeca.html', {
            scope: $scope,
            animation: 'slide-in-up'
          }).then(function(modal) {
            $scope.modalEntrada = modal;
            
          });
        $scope.openModalEntrada = function(atdpRequisicao){
          $scope.modalEntrada.show();
//          console.log(atdpRequisicao); 
          if(!$scope.entrada){
            $scope.entrada = new Object();
          }
          if(atdpRequisicao){
              $scope.entrada.atdpRequisicao = atdpRequisicao.id;
          }
        };
        $scope.closeModalEntrada = function(){
          $scope.modalEntrada.hide();
          $scope.entrada = null;
        };
        $scope.entradaPeca = function(requisicao){
          _entradaPeca(requisicao);
          $scope.entrada = null;
        };
        $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            if ($scope.modal !== undefined && $scope.modal.isShown()) {
                event.preventDefault();
                $scope.closeModal();
            }
            if ($scope.modalBaixa !== undefined && $scope.modalBaixa.isShown()) {
                event.preventDefault();
                $scope.closeModalBaixa();
            }
            if ($scope.modalEntrada !== undefined && $scope.modalEntrada.isShown()) {
                event.preventDefault();
                $scope.closeModalEntrada();
            }
        });
        
        var _getOrdens = function () {
		ordemServicoAPI.getOrdens().success(function (data) {
		$scope.ordens = data._embedded.atos;
	});};
    
    
	var _getEstoqueMovimentacao = function (atdpEstoque) {
		estoqueAPI.getEstoqueMovimentacao(atdpEstoque).success(function (data) {
		$scope.estoqueMovimentacao = data._embedded.atdp_movimentacao;
	});};


//        _getEstoqueMovimentacao($stateParams.id);
        
});