angular.module("starter").controller("ChatDetailCtrl", function ($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
});