angular.module("starter").controller("ImagensCtrl", function ($ionicPlatform, $q, $rootScope, $scope, $stateParams, ordemServicoAPI, $cordovaFile, $filter, SQLiteAPIServico,
    estoqueAPI, $ionicPopup, $ionicModal, $cordovaCamera, config, $ionicPopover, SQLiteAPIGrupo, SQLiteAPIProduto, $window, $cordovaDatePicker, SQLiteAPIatdcOcorrenciaInteracao, 
    SQLiteOrdemServico, SQLiteAPIAtendimento, SQLiteAPIatosAtividade, SQLiteAPIatosServico, SQLiteAPIAbstract, SQLiteAPIatdcOcorrenciaProduto, $timeout, $cordovaFileTransfer,
    SQLiteAPIat, SQLiteAPIatosImagem) {
    
    var _getImagens = function () {
        
        $rootScope.abrirCarregando();
        SQLiteAPIatosImagem.getAtosImagensRestantes().then(function (data) {
            $scope.atosImagens = data;
            console.log(data);
            $rootScope.fecharCarregando();
        }, function (err) {
            $rootScope.geraLog(err, new Error());
            $scope.closeModalReagendar();
        });
    };
    
    $scope.carregaImagem = function (src) {
//        console.log('carregaImagem');
        return src;
    };

    

    $ionicModal.fromTemplateUrl('templates/modal-editarimagem.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modalEditarImagem = modal;

    });
    $scope.openModalEditarImagem = function (imagem) {
        $scope.atosImagem = imagem;
        $scope.atosImagem.imagem = imagem.imagemSrc;
        $scope.modalEditarImagem.show();
    };
    $scope.closeModalEditarImagem = function () {
        $scope.modalEditarImagem.hide();
        _excluiImagemTemp();
    };
    $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        if ($scope.modalEditarImagem && $scope.modalEditarImagem.isShown()) {
            event.preventDefault();
            $scope.closeModalEditarImagem();
        }
    });
    
    _excluiImagemTemp = function (){
//        console.log('_excluiImagemTemp');
        if($scope.atosImagem.imagem2 != undefined){
            $cordovaFile.checkFile($scope.atosImagem.imagem2.sourceDirectory,$scope.atosImagem.imagem2.sourceFileName).then(function (success) {
//                console.log($scope.atosImagem.imagem2.sourceDirectory + $scope.atosImagem.imagem2.sourceFileName);
                $cordovaFile.removeFile($scope.atosImagem.imagem2.sourceDirectory,$scope.atosImagem.imagem2.sourceFileName).then(function (success) {
                    $scope.atosImagem.imagem = undefined;
                }, function (error) {
                    $rootScope.geraLog(error, new Error());
                });
            }, function () {});
        }
    };

    $scope.takePicture = function (origem) {
//        console.log('takePicture');
        _excluiImagemTemp();
        var options = {
            quality: 75, 
//            destinationType: Camera.DestinationType.DATA_URL,
            destinationType: Camera.DestinationType.FILE_URI,
            sourceType: origem,
//            sourceType: Camera.PictureSourceType.CAMERA,
            allowEdit: false,
//            encodingType: Camera.EncodingType.JPEG,
//            mediaType: Camera.MediaType.PICTURE,
//            targetWidth: 300,
//            targetHeight: 300,
            popoverOptions: CameraPopoverOptions,
            saveToPhotoAlbum: true
        };

        $cordovaCamera.getPicture(options).then(function (imageData) {
              

            var sourceDirectory = imageData.substring(0, imageData.lastIndexOf('/') + 1);
            var sourceFileName = imageData.substring(imageData.lastIndexOf('/') + 1, imageData.length);

            if(origem === 0){
                
                window.FilePath.resolveNativePath(imageData, function (result) {
                    
                    sourceDirectory = result.substring(0, result.lastIndexOf('/') + 1);
                    sourceFileName = result.substring(result.lastIndexOf('/') + 1, result.length);
                    
                    var sourceDirectoryTemp = cordova.file.externalCacheDirectory;
                    var sourceFileNameTemp = "Temp_"+sourceFileName;

//                    console.log("Copying from : " + sourceDirectory + sourceFileName);
//                    console.log("Copying to : " + sourceDirectoryTemp + sourceFileNameTemp);
//                    console.log('Camera.PictureSourceType.PHOTOLIBRARY');
//                    console.log(Camera.PictureSourceType.PHOTOLIBRARY);

                    $cordovaFile.copyFile(sourceDirectory, sourceFileName, sourceDirectoryTemp, sourceFileNameTemp).then(function(success) {
        //                $scope.fileName = cordova.file.dataDirectory + sourceFileName;
                        _adicionaObjetoImagem(sourceDirectoryTemp, sourceFileNameTemp);
//                        console.log('success');
//                        console.log(success);
                    }, function(error) {
                        $rootScope.geraLog(error, new Error());
                    });
                }, function(error) {
                    $rootScope.geraLog(error, new Error());
                });
                
                
            }else{
                _adicionaObjetoImagem(sourceDirectory, sourceFileName);
            }

//            $scope.atosImagem.imagem = "data:image/jpeg;base64," + imageData;
        }, function (error) {
            $rootScope.geraLog(error, new Error());
//            console.error(error);
//            alert(err);
            // An error occured. Show a message to the user
        });
    };
    
    _adicionaObjetoImagem = function (sourceDirectory, sourceFileName) {
            
        if (!$scope.atosImagem) {
            $scope.atosImagem = new Object();
        }
        $scope.atosImagem.imagem2 = {
            sourceDirectory : sourceDirectory,
            sourceFileName  : sourceFileName
        };

        if(window.location.hostname === '192.168.1.20'){
            $cordovaFile.readAsDataURL(sourceDirectory, sourceFileName).then(function(base64) {
//                console.log('parte imagem');
//                console.log(base64.substring(0, 50));
                $scope.atosImagem.imagem = base64;
            }, function(error) {
                $rootScope.geraLog(error, new Error());

            });
        }else{
            $scope.atosImagem.imagem = sourceDirectory+sourceFileName;
//            $scope.atosImagem.imagem = imageData;
        }
    };
    
    
//    $scope.editarImagemOS = function (atosImagem) {
//
//        atosImagem.atos = $scope.atendimento._embedded.atos.id;
//        var timeNow = new Date();
//
//        var fd = new FormData();
//        fd.append('atos', atosImagem.atos);
//
//        fd.append('data', $rootScope.converteObjetoDataPost(timeNow));
//        fd.append('descricao', atosImagem.descricao);
//        fd.append('imagem', dataURItoBlob($scope.atosImagem.imagem), 'nome.jpg');
//
//        $rootScope.abrirCarregando();
////            console.log(atosImagem);
//        ordemServicoAPI.editarImagemOS(fd).success(function (data) {
////            console.log(data);
//            $scope.closeModalEditarImagem();
//            $rootScope.fecharCarregando();
//            if(!('atosImagens' in $scope.atendimento._embedded.atos.atosImagens)){
//                $scope.atendimento._embedded.atos.atosImagens = {};
//            }
//            $scope.atendimento._embedded.atos.atosImagens[data.id] = data;
//            $scope.atosImagem.descricao = null;
//            $scope.atosImagem.imagem = null;
//        }).error(function (data) {
//            $rootScope.fecharCarregando();
////            console.log(data);
//        });
//    };

    $scope.editarImagemOS2 = function (atosImagem) {
        let imgTemp2 = null;
        if(atosImagem.imagem !== undefined){
            var timeNow = new Date();
            if(!('imagem2' in $scope.atosImagem)){
                let imgTemp = atosImagem.imagem;
                imgTemp2 = imgTemp.substring(imgTemp.lastIndexOf("/")+1);
            }

            var dados = {
                'id' : atosImagem.id,
//                'data' : $rootScope.converteObjetoDataPost(timeNow),
                'dataAlteracao' : $rootScope.converteObjetoDataPost(timeNow),
                'descricao' : atosImagem.descricao,
                'sincronizado' : 0,
                'imagem' :  imgTemp2 !== null ? imgTemp2 : $scope.atosImagem.imagem2.sourceFileName 
//                'imagemData' : $scope.atosImagem.imagem
            };
            
            
            if(dados.descricao.length < 1 || dados.descricao === null){
                $rootScope.showAlert("Favor informar uma descrição para a imagem!");
                $rootScope.fecharCarregando();
                return;
            }

            SQLiteAPIAbstract.update('atos_imagem', dados.id, dados).then(function (data) {
//                console.log("Copying from : " + $scope.atosImagem.imagem2.sourceDirectory + $scope.atosImagem.imagem2.sourceFileName);
//                console.log("Copying to : " + $rootScope.caminhoFotos + $scope.atosImagem.imagem2.sourceFileName);
                if(('atdcOcorrencia' in atosImagem)){
                    data.atdcOcorrencia = atosImagem.atdcOcorrencia;
                }
                if('imagem2' in $scope.atosImagem){
                    $cordovaFile.moveFile($scope.atosImagem.imagem2.sourceDirectory, $scope.atosImagem.imagem2.sourceFileName, $rootScope.caminhoFotos, dados.imagem).then(function(success) {
        //                $scope.fileName = cordova.file.dataDirectory + sourceFileName;
    //                    console.log('success');
    //                    console.log(success);

                        $cordovaFile.checkFile($rootScope.caminhoFotos, dados.imagem).then(function (success) {
                            if(!($scope.atosImagens)){
                                $scope.atosImagens = {};
                            }
                            data.imagemSrc = $scope.atosImagem.imagem;
                            $scope.atosImagens[data.id] = data;
                            $scope.atosImagem.descricao = null;
                            $scope.atosImagem.imagem = undefined;
                        }, function () {
                            SQLiteAPIAbstract.delete('atos_imagem', data.id).then(function (data) {}, function (err) {});
                            $rootScope.showAlert("Ocorreu um erro ao copiar a imagem, favor tentar novamente");
                        });
                        $scope.closeModalEditarImagem();
                    }, function(error) {
                        $rootScope.geraLog(error, new Error());
                    });
                }else{
                    data.imagemSrc = atosImagem.imagem;
                    $scope.atosImagens[data.id] = data;
                    $scope.atosImagem.descricao = null;
                    $scope.atosImagem.imagem = undefined;
                    $scope.closeModalEditarImagem();
                }
                
            }, function (data) {
                $rootScope.fecharCarregando();
    //            console.log(data);
            });
        }else{
            $rootScope.showAlert("Tire uma nova foto ou selecione uma da galeria...");
        }
    };

    $scope.excluirImagemOS = function (atosImagem) {
        var confirmPopup = $ionicPopup.confirm({
            title: 'Deseja realmente excluir a imagem?',
//            template: 'Deseja realmente excluir o produto?'
        });
        confirmPopup.then(function (res) {
            if (res) {
                SQLiteAPIAbstract.delete('atos_imagem', atosImagem).then(function (data) {
                    delete $scope.atosImagens[atosImagem];
                }, function (data) {
        //            $rootScope.fecharCarregando();
        //            console.log(data);
                });
            }
        });
    };

    $scope.showImages = function (index) {
        $scope.activeSlide = index;
        $scope.showModal('templates/image-popover.html');
    };

    $scope.showModal = function (templateUrl) {
        $ionicModal.fromTemplateUrl(templateUrl, {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modal = modal;
            $scope.modal.show();
        });
    };

    // Close the modal
    $scope.closeModal = function () {
        $scope.modal.hide();
        $scope.modal.remove();
    };    

     
    $ionicPlatform.ready(function () {
        $scope.opcoesLinha = {};
        $scope.opcoesFamilia = {};
        $scope.opcoesProduto = {};
        if ($stateParams.id) {
            $scope.id_atendimento = $stateParams.id;
        } else {
            $scope.id_atendimento = null;
        }
        _getImagens();
    });
    $scope.doRefresh = function () {
        if ($stateParams.id) {
            $scope.id_atendimento = $stateParams.id;
        } else {
            $scope.id_atendimento = null;
        }
        _getImagens();
        $scope.$broadcast('scroll.refreshComplete');
    }; 
    

});

function dataURItoBlob(dataURI) {
// convert base64/URLEncoded data component to raw binary data held in a string
    var byteString = atob(dataURI.split(',')[1]);
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]

    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++)
    {
        ia[i] = byteString.charCodeAt(i);
    }

    var bb = new Blob([ab], {"type": mimeString});
    return bb;
}